
#pragma once

#include "TablesConstants.h"
#include "CGroupTable.h"


//	CFitErrorDialog



const ResIDT	rPPob_NoiseDialog		= 1017;
const PaneIDT	kDeviateType			= 4;
const PaneIDT	kDeviateType_uniform		= 1;
const PaneIDT	kDeviateType_gaussian		= 3;
const PaneIDT	kDeviateType_exponential	= 2;
const PaneIDT	kDeviateType_dbl_exponential	= 4;
const PaneIDT	kDeviateType_lorentzian			= 5;
const PaneIDT	kNumberPoint			= 5;
const PaneIDT	kMatrixOutput			= 3;
const PaneIDT	kNumberSeries			= 6;
const PaneIDT	kNumberSeriesTxt		= 7;
const PaneIDT	kRedNoiseChbx			= 8;
const PaneIDT	kRedNoiseCoeff			= 9;
const PaneIDT	kRedNoiseCoeffTxt		= 50;
const PaneIDT	kMinValue				= 10;
const PaneIDT	kMaxValue				= 11;
const PaneIDT	kMeanValue				= 12;
const PaneIDT	kVarValue				= 13;
const PaneIDT	kMinInfinityValue		= 20;
const PaneIDT	kMaxInfinityValue		= 21;
const PaneIDT	kVarInfinityValue		= 23;
const MessageT	msg_CheckMatrix			= 1000;
const MessageT	msg_ChangeDeviate		= 1001;
const MessageT	msg_ChangeMin			= 1002;
const MessageT	msg_ChangeMax			= 1003;
const MessageT	msg_ChangeMean			= 1004;
const MessageT	msg_ChangeVar			= 1005;
const MessageT	msg_ChangeRedNoiseChBx	= 1010;



class CNoiseDialog : public CMyStdDialog {
private:
	double	tempMean;
	
	void	HideAndShow()
	{	if ( GetCheckBoxValue(kMatrixOutput) )
		{	GetStaticText(kNumberSeriesTxt)->Show();
			GetEditText(kNumberSeries)->Show();
		}
		else
		{	GetStaticText(kNumberSeriesTxt)->Hide();
			GetEditText(kNumberSeries)->Hide();
		}
		
		if (GetDValue( kMeanValue ) != 0)	tempMean = GetDValue( kMeanValue );
		if ( GetCheckBoxValue(kRedNoiseChbx) )
		{	GetEditText(kRedNoiseCoeff)->Show();
			GetStaticText(kRedNoiseCoeffTxt)->Show();
			SetDValue( kMeanValue, 0 );
			GetEditText(kMeanValue)->Disable();
		}
		else
		{	GetEditText(kRedNoiseCoeff)->Hide();
			GetStaticText(kRedNoiseCoeffTxt)->Hide();
			SetDValue( kMeanValue, tempMean );
			GetEditText(kMeanValue)->Enable();
		}
			
		switch ( GetPopupValue( kDeviateType ) )			//	Setup for Min & Max
		{	case kDeviateType_uniform:
				{	GetEditText(kMinValue)->Show();			GetEditText(kMaxValue)->Show();
					GetCaption(kMinInfinityValue)->Hide();	GetCaption(kMaxInfinityValue)->Hide();
				//	GetEditText(kMinValue)->Enable();
				};
				break;
			case kDeviateType_exponential:
				{	GetEditText(kMinValue)->Show();			GetEditText(kMaxValue)->Hide();
					GetCaption(kMinInfinityValue)->Hide();	GetCaption(kMaxInfinityValue)->Show();
				//	GetEditText(kMinValue)->Disable();
				//	SetDValue( kMinValue, 0 );
				};
				break;
			case kDeviateType_gaussian:
			case kDeviateType_dbl_exponential:
			case kDeviateType_lorentzian:
				{	GetEditText(kMinValue)->Hide();			GetEditText(kMaxValue)->Hide();
					GetCaption(kMinInfinityValue)->Show();	GetCaption(kMaxInfinityValue)->Show();
				};	
				break;
		}	
			
		switch ( GetPopupValue( kDeviateType ) )			//	Setup for Var
		{	case kDeviateType_uniform:
			case kDeviateType_gaussian:
			case kDeviateType_exponential:
			case kDeviateType_dbl_exponential:
				{	GetEditText(kVarValue)->Show();	GetCaption(kVarInfinityValue)->Hide();	};
				break;
			case kDeviateType_lorentzian:
				{	GetEditText(kVarValue)->Hide();	GetCaption(kVarInfinityValue)->Show();	};	
				break;
		}	
	};
	
	void	SetMinMaxFromMeanVar()
	{	double var = GetDValue( kVarValue );	double mean = GetDValue( kMeanValue );
		if (GetPopupValue( kDeviateType ) == kDeviateType_uniform)
		{	//double var = GetDValue( kVarValue );	//double min = GetDValue( kMinValue );	double max = GetDValue( kMaxValue );
			double ampl = std::sqrt( 12*var )/2;		// = (max - min)/2
			//double shift = (ampl - (min+max))/2;
			SetDValue( kMinValue, mean - ampl );
			SetDValue( kMaxValue, mean + ampl );
		}
		else if (GetPopupValue( kDeviateType ) == kDeviateType_exponential)
		{	//double var = GetDValue( kVarValue );	double mean = GetDValue( kMeanValue );
			SetDValue( kMinValue, mean - std::sqrt(var) );
		};
	};
	
public:
	//double	a, b;	//	noise = a * randomgenerated + b
						//	b = mean (gauss, dblexp, lorentz), = min (uniform, exp)
						//	a = max - min (uniform); = std::sqrt(var) (gauss, dblexp, exp), = 1 - undefined (lorentz)
	double	offset()
	{	double	b = 0;
		switch ( GetPopupValue( kDeviateType ) )			//	Setup for Var
		{	case kDeviateType_uniform:
			case kDeviateType_exponential:
				b = GetDValue( kMinValue );
				break;
			case kDeviateType_gaussian:
			case kDeviateType_dbl_exponential:
			case kDeviateType_lorentzian:
				b = GetDValue( kMeanValue );
				break;
		}
		return b;
	};
	double	coefficient()
	{	double	a = 1;
		switch ( GetPopupValue( kDeviateType ) )			//	Setup for Var
		{	case kDeviateType_uniform:
				a = ( GetDValue( kMaxValue ) - GetDValue( kMinValue ) );
				break;
			case kDeviateType_exponential:
			case kDeviateType_gaussian:
			case kDeviateType_dbl_exponential:
				a = std::sqrt( GetDValue( kVarValue ) );
				break;
		}
		return a;
	};
	
public:
	enum { class_ID = 'NoiD' };
	CNoiseDialog( LStream *inStream )	: CMyStdDialog( inStream )	{};
	~CNoiseDialog()		{};

	void	SetupDialog()
		{	tempMean = 0;
			HideAndShow();
		};
		
	virtual void	ListenToMessage( MessageT inMessage, void* )
		{	StopListening();
			switch ( inMessage ) {
				case msg_CheckMatrix:
					HideAndShow();
					break;
				case msg_ChangeDeviate:
				case msg_ChangeRedNoiseChBx:
					HideAndShow();
					SetMinMaxFromMeanVar();
					break;
				case msg_ChangeMin:
				case msg_ChangeMax:
					if (GetPopupValue( kDeviateType ) == kDeviateType_uniform)
					{	double min = GetDValue( kMinValue );	double max = GetDValue( kMaxValue );
						if (min > max)
						{	if (inMessage == msg_ChangeMax)	{	SetDValue( kMinValue, max-1 );	min = GetDValue( kMinValue );	}
							if (inMessage == msg_ChangeMin)	{	SetDValue( kMaxValue, min+1 );	max = GetDValue( kMaxValue );	}
						}
						SetDValue( kMeanValue, (min+max)/2 );
						SetDValue( kVarValue, MyMath::sqr(max-min)/12 );
					}
					else if (GetPopupValue( kDeviateType ) == kDeviateType_exponential)
					{	double min = GetDValue( kMinValue );	double var = GetDValue( kVarValue );
						SetDValue( kMeanValue, min + std::sqrt(var) );
					}
					break;
				case msg_ChangeMean:
				case msg_ChangeVar:
					SetMinMaxFromMeanVar();
					break;
			}
			StartListening();
		};
		
	virtual Boolean	ValidDialog()
		{	Boolean	ok = true;
			if ( ok && GetCheckBoxValue(kRedNoiseChbx) )
			{	double	lag1 = GetDValue( kRedNoiseCoeff );
				ok = ((lag1 >= 0) && (lag1 < 1));
				if (!ok)	MySimpleAlert( "\pThe lag-1 autocorrelation needs to be a number between 0 and 1", this );
			}
			return ok;
		};

protected:
	virtual	SInt16	rPPob()	{	return	rPPob_NoiseDialog;	};
};


		/*		case msg_ChangeMean:		//	does not change Var !!
					if (GetPopupValue( kDeviateType ) == kDeviateType_uniform)
					{	double min = GetDValue( kMinValue );	double max = GetDValue( kMaxValue );	double mean = GetDValue( kMeanValue );
						double shift = mean - (min+max)/2;
						SetDValue( kMinValue, min + shift );
						SetDValue( kMaxValue, max + shift );
					}
					else if (GetPopupValue( kDeviateType ) == kDeviateType_exponential)
					{	double var = GetDValue( kVarValue );	double mean = GetDValue( kMeanValue );
						SetDValue( kMinValue, mean - std::sqrt(var) );
					}
					break;
				case msg_ChangeVar:			//	does not change Mean !!
					if (GetPopupValue( kDeviateType ) == kDeviateType_uniform)
					{	double var = GetDValue( kVarValue );	double min = GetDValue( kMinValue );	double max = GetDValue( kMaxValue );
						double ampl = std::sqrt( 12*var );
						double shift = (ampl - (min+max))/2;
						SetDValue( kMinValue, min - shift );
						SetDValue( kMaxValue, max + shift );
					}
					else if (GetPopupValue( kDeviateType ) == kDeviateType_exponential)
					{	double var = GetDValue( kVarValue );	double mean = GetDValue( kMeanValue );
						SetDValue( kMinValue, mean - std::sqrt(var) );
					}
					break;
			*/
