
#include "CMyStdDialogs.h"
#include "plotRecord.h"
#include "CDynamicPaneTable.h"
#include "CGroupTableItem.h"
#include "CRegScaleView.h"
#include "LMultiPanelView.h"
#include "LTabsControl.h"


//	CSamplingDialog

const ResIDT	rPPob_SamplingDialog	= 1009;
const PaneIDT	kSampling_Interp_Popup	= 3;
const PaneIDT	kSampling_Funct_Popup	= 4;

const PaneIDT	k_simple_interp	= 1;
const PaneIDT	k_integ_interp	= 2;

const PaneIDT	k_staircase		= 1;
const PaneIDT	k_linear		= 2;
const PaneIDT	k_cubic_spline	= 3;

const MessageT	msg_SampTabChanged		= 3000;
const MessageT	msg_SampChkYChanged		= 3001;
const PaneIDT	kSampling_multiView		= 50;
const PaneIDT	kSampling_yscale_chkbx	= 60;




class CSamplingDialog : public CMyStdDialog {
private:
public:
	static Boolean	saved;
	static double	saved_From;
	static double	saved_To;
	static double	saved_Step;
	static STableItem1D::InterpType		saved_InterpType;
	static FourCharCode		saved_FunctionType;
	
	LMultiPanelView*		GetMultiPanelView( PaneIDT paneID )				DefineGetField( LMultiPanelView, paneID );
//	{	return	GetField<CDynamicPaneTable>(this,kUnevenScale_DynTable);	};

	STableItem1D*	selectedItem;
	bool check_All_Y_Monotonous()
		{	size_t nb	= selectedItem->TableSize();
			bool monotonous = true;
			for (size_t i=1; i<=nb; i++)
			{	double_vector* y = selectedItem->item_1D(i)->Vector();
				monotonous = monotonous && ((y->check_strict_decrease() || y->check_strict_increase()));
			};
			return monotonous;
		};
	bool resample_Y()
		{	return GetCheckBoxValue(kSampling_yscale_chkbx);	};

public:
	enum { class_ID = 'SamD' };
	
	CSamplingDialog( LStream *inStream )	: CMyStdDialog( inStream )	{};
	~CSamplingDialog()	{};
	virtual void	FinishCreateSelf()
		{	LMultiPanelView* multiPane = GetMultiPanelView( kSampling_multiView );	//GetField<LMultiPanelView>( this, kSampling_multiView );
			multiPane->AddPanel( rPPob_RegScaleView, nil, LArray::index_Last );
			multiPane->AddPanel( rPPob_UnevenScaleView, nil, LArray::index_Last );
			multiPane->CreateAllPanels();
			multiPane->SwitchToPanel(2);
			multiPane->SwitchToPanel(1);
			CMyStdDialog::FinishCreateSelf();
		};
		
	CMultiItemRegScaleView* RegScaleView()
		{	LMultiPanelView* multiPane = GetMultiPanelView( kSampling_multiView );	//GetField<LMultiPanelView>( this, kSampling_multiView );
			return	dynamic_cast<CMultiItemRegScaleView*>(multiPane->GetPanel(1));
		};
		
	CUnevenScaleView* UnevenScaleView()
		{	LMultiPanelView* multiPane = GetMultiPanelView( kSampling_multiView );	//GetField<LMultiPanelView>( this, kSampling_multiView );
			return	dynamic_cast<CUnevenScaleView*>(multiPane->GetPanel(2));
		};
		
	Boolean isRegular()
		{	LMultiPanelView* multiPane = GetMultiPanelView( kSampling_multiView );	//GetField<LMultiPanelView>( this, kSampling_multiView );
			return (multiPane->GetCurrentPanel() == RegScaleView());
		};
	virtual void	ListenToMessage( MessageT inMessage, void *ioParam )
		{	switch ( inMessage ) {
			case msg_SampChkYChanged:
				StopListening();
				if (resample_Y())
				{	SetPopupValue( kSampling_Funct_Popup, k_linear );		//	only linear interpolation allowed
					::DisableMenuItem( GetPopup( kSampling_Funct_Popup )->GetMacMenuH(), k_staircase );
					::DisableMenuItem( GetPopup( kSampling_Funct_Popup )->GetMacMenuH(), k_cubic_spline );
				}
				else
				{	::EnableMenuItem( GetPopup( kSampling_Funct_Popup )->GetMacMenuH(), k_staircase );
					::EnableMenuItem( GetPopup( kSampling_Funct_Popup )->GetMacMenuH(), k_cubic_spline );
				}
				RegScaleView()->SetupDialogScale( selectedItem, resample_Y() );		
				UnevenScaleView()->SetupYScale( resample_Y() );
				StartListening();
				break;
			default:
				LDialogBox::ListenToMessage( inMessage, ioParam );
				break;
			}
		};
		
	virtual Boolean	ValidDialog()		//	only check wether it is consistent
		{	Boolean	isOk = true;
			if (isRegular())	isOk = RegScaleView()->ValidView();
			else				isOk = UnevenScaleView()->ValidView();
			return	isOk;
		};
	
	virtual void	SetupDialog()
		{	if (saved)
			{	switch(saved_InterpType)	{
					case ResampledSeries::simple_interp:	SetPopupValue( kSampling_Interp_Popup, k_simple_interp );	break;
					case ResampledSeries::integ_interp:		SetPopupValue( kSampling_Interp_Popup, k_integ_interp );	break;
				}
				switch(saved_FunctionType)	{
					case MyMath::StairInterpFunctionCode:		SetPopupValue( kSampling_Funct_Popup, k_staircase );		break;
					case MyMath::LinearInterpFunctionCode:		SetPopupValue( kSampling_Funct_Popup, k_linear );			break;
					case MyMath::SplineInterpFunctionCode:		SetPopupValue( kSampling_Funct_Popup, k_cubic_spline );		break;
				}
				RegScaleView()->SetValues( saved_From, saved_To, saved_Step );		
			}
		};
	void	SetupDialogScale( STableItem1D*	item )
		{	selectedItem = item;
			if (check_All_Y_Monotonous())	GetCheckBox( kSampling_yscale_chkbx )->Show();
			else							GetCheckBox( kSampling_yscale_chkbx )->Hide();
			RegScaleView()->SetupDialogScale( selectedItem, resample_Y() );		
			UnevenScaleView()->SetupDialogScale( selectedItem );	//, resample_Y() );
		};

	virtual void	SaveDialog()
		{	saved 		= true;
			RegScaleView()->GetScale( saved_From, saved_To, saved_Step );	
			switch(GetPopupValue( kSampling_Interp_Popup ))	{
				case k_simple_interp:		saved_InterpType = ResampledSeries::simple_interp;	break;
				case k_integ_interp:		saved_InterpType = ResampledSeries::integ_interp;	break;
			}
			switch(GetPopupValue( kSampling_Funct_Popup ))	{
				case k_staircase:		saved_FunctionType = MyMath::StairInterpFunctionCode;		break;
				case k_linear:			saved_FunctionType = MyMath::LinearInterpFunctionCode;		break;
				case k_cubic_spline:	saved_FunctionType = MyMath::SplineInterpFunctionCode;		break;
			}
		};

	Boolean	DoResample( size_t i )
		{	if (isRegular())	return true;
			else				return UnevenScaleView()->DoResample( i );
		};
	double_vector*	x_scale()
		{	if (isRegular())	return new MyMath::double_regular_array( saved_From, saved_To, saved_Step );
			else				return new double_vector( *(UnevenScaleView()->checkedVector) );
		};
		
protected:

	virtual	SInt16	rPPob()	{	return	rPPob_SamplingDialog;	};
	
};