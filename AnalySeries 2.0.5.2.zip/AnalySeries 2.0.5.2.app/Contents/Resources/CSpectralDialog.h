
#include "myMath.h"
#include "spectral.h"
#include "CMyStdDialogs.h"
#include "TablesConstants.h"




//	CSpectralDialog

const ResIDT	rPPob_SpectralDialog			= 1014;

const PaneIDT	kSpectral_Evol_ChkBox			= 3;
const PaneIDT	kSpectral_Cross_ChkBox			= 4;
const PaneIDT	kSpectral_Param_Slider			= 5;
const PaneIDT	kSpectral_ParamPercent_ETxt		= 6;
const PaneIDT	kSpectral_ParamNumber_ETxt		= 7;
const PaneIDT	kSpectral_ConfLevel_ETxt		= 8;
const PaneIDT	kSpectral_ConfLevel_StatTxt		= 9;
const PaneIDT	kSpectral_ConfLevel_StatTxt2	= 10;
const PaneIDT	kSpectral_WindowType_Popup		= 11;
const PaneIDT	kSpectral_FreqFrom_ETxt			= 12;
const PaneIDT	kSpectral_FreqTo_ETxt			= 13;
const PaneIDT	kSpectral_FreqStep_ETxt			= 14;
const PaneIDT	kSpectral_FreqFrom_StatTxt		= 15;
const PaneIDT	kSpectral_FreqTo_StatTxt		= 16;
const PaneIDT	kSpectral_FreqStep_StatTxt		= 17;
const PaneIDT	kSpectral_StatComment_StatTxt	= 18;
const PaneIDT	kSpectral_Confidence_StatTxt	= 19;
const PaneIDT	kSpectral_Resolution_StatTxt	= 20;
const PaneIDT	kSpectral_Percent_StatTxt		= 21;
const PaneIDT	kSpectral_NbLag_StatTxt			= 22;
const PaneIDT	kSpectral_ResampleFreq_ChkBox	= 23;
const PaneIDT	kSpectral_InfSupErrors_ChkBox	= 24;
const PaneIDT	kSpectral_MTM_Amplitude_ChkBox	= 25;
const PaneIDT	kSpectral_CrossPhase_ChkBox		= 26;

const PaneIDT	kSpectral_EvolWindow_StatTxt	= 30;
const PaneIDT	kSpectral_EvolWindow_ETxt		= 31;
const PaneIDT	kSpectral_EvolStep_StatTxt		= 32;
const PaneIDT	kSpectral_EvolStep_ETxt			= 33;
const PaneIDT	kSpectral_EvolComment_StatTxt	= 34;

const PaneIDT	kSpectral_LinTrend_ChkBox	= 40;
const PaneIDT	kSpectral_Normalize_ChkBox	= 41;
const PaneIDT	kSpectral_Prewhite_ChkBox	= 42;
const PaneIDT	kSpectral_Prewhite_ETxt		= 43;
const PaneIDT	kSpectral_Prewhite_StatTxt	= 44;

const MessageT	msg_SpectralParamCursorChanged		= 1070;
const MessageT	msg_SpectralParamPercentChanged		= 1071;
const MessageT	msg_SpectralParamNumberChanged		= 1072;
const MessageT	msg_SpectralEvolChkBoxChanged		= 1073;
const MessageT	msg_CrossSpectrumChkBoxChanged		= 1074;
const MessageT	msg_SpectralWindowPopupChanged		= 1075;
const MessageT	msg_SpectralConfLevelChanged		= 1076;
const MessageT	msg_ResampleFreqChkBoxChanged		= 1077;
const MessageT	msg_SpectralEvolWSizeChanged		= 1078;
const MessageT	msg_SpectralEvolWNumberChanged		= 1079;
const MessageT	msg_SpectralPreWChkBoxChanged		= 1080;

const PaneIDT	k_squareWindow		= 1;
const PaneIDT	k_BartlettWindow	= 2;
const PaneIDT	k_TukeyWindow		= 3;
const PaneIDT	k_ParzenWindow		= 4;
const PaneIDT	k_WelchWindow		= 5;

//const double	Graph_paramscale[5] = { 0, 0.25, 0.5, 0.75, 1 );		//	list of special predefined values
//const double	BT_paramscale[5] 	= { 0, 0.1, 0.3, 0.5, 1 );			//	list of special predefined values

class CSpectralDialog : public CMyStdDialog {
private:
	static const size_t	paramscale_length;
	
	static const double	Graph_paramscale[]; 	//= { 0, 0.25, 0.5, 0.75, 1 );			//	list of special predefined values
	static const double	BT_paramscale[]; 		//= { 0, 0.1, 0.3, 0.5, 1 );			//	list of special predefined values
	static const double	ME_paramscale[]; 		//= { 0, 0.05, 0.1, 0.3, 1 );			//	list of special predefined values
	static const double	MTM_paramscale[]; 		//= { 0.0, 0.02, 0.03, 0.06, 1 );		//	list of special predefined values

	const double	overSamplFactor;
	const double*	current_paramscale;
	Boolean			linked_paramscale;			//	false for MTM (2 independent params, except when adjusted by cursor)

	STableItem1D*					inputItem;
	MyMath::double_regular_array* 	in_x;
		
	double	linear( double x, double x1, double x2, double y1, double y2 )		//	linear interpolation
		{	return	y1 + (y2-y1) * (x-x1)/(x2-x1);	}
	double	paramscale( double v, const double p0[], const double p1[] )					//	from [0, 1] to [0, 1]
		{	for (size_t i=1; i<=paramscale_length-1; i++)
				if ( (p0[i-1] <= v) && (v < p0[i]) )	return	linear( v, p0[i-1], p0[i], p1[i-1], p1[i] );
			//else if ( (p0[1]<= v) && (v < p0[2]) )	return	linear( v, p0[1], p0[2], p1[1], p1[2] );
			//else if ( (p0[2] <= v) && (v < p0[3]) )	return	linear( v, p0[2], p0[3], p1[2], p1[3] );
			//else									return	linear( v, p0[3], p0[4], p1[3], p1[4] );			//if ( (p0[3] <= v) && (v <= p0[4]) )
			return	0;
		}
	void	HideAndShowEvol()
		{	if (GetCheckBoxValue( kSpectral_Evol_ChkBox ))
			{	GetStaticText( kSpectral_EvolWindow_StatTxt )->Show();
				GetEditText( kSpectral_EvolWindow_ETxt )->Show();
				GetStaticText( kSpectral_EvolStep_StatTxt )->Show();
				GetEditText( kSpectral_EvolStep_ETxt )->Show();
				GetStaticText( kSpectral_EvolComment_StatTxt )->Show();
			}
			else
			{	GetStaticText( kSpectral_EvolWindow_StatTxt )->Hide();
				GetEditText( kSpectral_EvolWindow_ETxt )->Hide();
				GetStaticText( kSpectral_EvolStep_StatTxt )->Hide();
				GetEditText( kSpectral_EvolStep_ETxt )->Hide();
				GetStaticText( kSpectral_EvolComment_StatTxt )->Hide();
			}
		};
	void	HideAndShowResample()
		{	if (GetCheckBoxValue(kSpectral_ResampleFreq_ChkBox))
			{	GetEditText( kSpectral_FreqFrom_ETxt 	)->Show();
				GetEditText( kSpectral_FreqTo_ETxt		)->Show();
				GetEditText( kSpectral_FreqStep_ETxt	)->Show();
				GetCaption( kSpectral_FreqFrom_StatTxt 	)->Show();
				GetCaption( kSpectral_FreqTo_StatTxt 	)->Show();
				GetCaption( kSpectral_FreqStep_StatTxt 	)->Show();
			}
			else
			{	GetEditText( kSpectral_FreqFrom_ETxt 	)->Hide();
				GetEditText( kSpectral_FreqTo_ETxt		)->Hide();
				GetEditText( kSpectral_FreqStep_ETxt	)->Hide();
				GetCaption( kSpectral_FreqFrom_StatTxt 	)->Hide();
				GetCaption( kSpectral_FreqTo_StatTxt 	)->Hide();
				GetCaption( kSpectral_FreqStep_StatTxt 	)->Hide();
			}
		}
	void	SetParamScale( CommandT inCommand )
		{	switch (inCommand)
			{	case cmd_BTukey:
					current_paramscale = BT_paramscale;
					break;
				case cmd_MaxEntropy:
					current_paramscale = ME_paramscale;
					break;
				case cmd_MTM:
					current_paramscale = MTM_paramscale;
					linked_paramscale  = false;
					break;
			}
		};
	void	AdjustParamPercentFromNumber()
		{	size_t	lag = GetEditText( kSpectral_ParamNumber_ETxt )->GetValue();
			double	pc  = std::max( 0.0, std::min( 1.0, lag/(double)( linked_paramscale ? series_length() : 150 ) ));
			SetDValue( kSpectral_ParamPercent_ETxt, 100*MyMath::Arondi( pc, MyMath::round_nearest, 2 ) );
		};
	void	AdjustParamNumberFromCursor()
		{	long	sv = GetSliderValue( kSpectral_Param_Slider );
			//double	v  = (sv-1)/100.0;
			double	v  = sv/100.0;
			AdjustParam( v );
		};
	void	AdjustParamNumberFromPercent()
		{	double	pc = GetDValue( kSpectral_ParamPercent_ETxt ) * series_length() / 100.0;
			size_t	lag = std::max((size_t)2, std::min( series_length(), (size_t)MyMath::long_round( pc ) ));
			GetEditText( kSpectral_ParamNumber_ETxt )->SetValue( lag );
			
		};
	void	AdjustParamCursorFromNumber()
		{	size_t	lag = GetEditText( kSpectral_ParamNumber_ETxt )->GetValue();
			double	v  = lag/(double)( linked_paramscale ? series_length() : 150 );
			double	gc = paramscale( v, current_paramscale, Graph_paramscale );
			//long	n = 1 + MyMath::long_round(100 * gc);
			long	n = MyMath::long_round(100 * gc);
			SetSliderValue( kSpectral_Param_Slider, n );
		};
	void	AdjustParam( double v )			//	v between 0 and 1, with 0.25; 0.5; 0.75 special turning points (predefined levels)
		{	if (current_paramscale)
			{	double	pc = paramscale( v, Graph_paramscale, current_paramscale ) * ( linked_paramscale ? series_length() : 150 );					//	v * pc = simple percent value
				size_t	lag = std::max((size_t)2, std::min( series_length(), (size_t)MyMath::long_round( pc ) ));
				GetEditText( kSpectral_ParamNumber_ETxt )->SetValue( lag );
			}
		};
	void	HideAndShowParam( Boolean sh )
		{	if (sh)
			{	GetSlider( kSpectral_Param_Slider )->Show();
				GetStaticText( kSpectral_Confidence_StatTxt )->Show();
				GetStaticText( kSpectral_Resolution_StatTxt )->Show();
				GetStaticText( kSpectral_Percent_StatTxt )->Show();
				GetStaticText( kSpectral_NbLag_StatTxt )->Show();
				GetEditText( kSpectral_ParamPercent_ETxt )->Show();
				GetEditText( kSpectral_ParamNumber_ETxt )->Show();
			}
			else
			{	GetSlider( kSpectral_Param_Slider )->Hide();
				GetStaticText( kSpectral_Confidence_StatTxt )->Hide();
				GetStaticText( kSpectral_Resolution_StatTxt )->Hide();
				GetStaticText( kSpectral_Percent_StatTxt )->Hide();
				GetStaticText( kSpectral_NbLag_StatTxt )->Hide();
				GetEditText( kSpectral_ParamPercent_ETxt )->Hide();
				GetEditText( kSpectral_ParamNumber_ETxt )->Hide();
			}
		};
	void	HideAndShowConfLevel( Boolean sh )
		{	if (sh)
			{	GetEditText( kSpectral_ConfLevel_ETxt )->Show();
				GetStaticText( kSpectral_ConfLevel_StatTxt )->Show();
				GetStaticText( kSpectral_ConfLevel_StatTxt2 )->Show();
				GetStaticText( kSpectral_StatComment_StatTxt )->Show();
			}
			else
			{	GetEditText( kSpectral_ConfLevel_ETxt )->Hide();
				GetStaticText( kSpectral_ConfLevel_StatTxt )->Hide();
				GetStaticText( kSpectral_ConfLevel_StatTxt2 )->Hide();
				GetStaticText( kSpectral_StatComment_StatTxt )->Hide();
			}
		};
	void	HideAndShowPreW()
		{	if (GetCheckBoxValue( kSpectral_Prewhite_ChkBox ))
			{	GetEditText( kSpectral_Prewhite_ETxt )->Show();
				GetStaticText( kSpectral_Prewhite_StatTxt )->Show();
			}
			else
			{	GetEditText( kSpectral_Prewhite_ETxt )->Hide();
				GetStaticText( kSpectral_Prewhite_StatTxt )->Hide();
			}				
		};
	void	HideAndShowInfSupErrors( Boolean sh )
		{	if (sh)		GetCheckBox(kSpectral_InfSupErrors_ChkBox)->Show();
			else		GetCheckBox(kSpectral_InfSupErrors_ChkBox)->Hide();
		};
	void	HideAndShowMTMAmplitude( Boolean sh )
		{	if (sh)		GetCheckBox(kSpectral_MTM_Amplitude_ChkBox)->Show();
			else		GetCheckBox(kSpectral_MTM_Amplitude_ChkBox)->Hide();
		};
	void	HideAndShowCrossPhase( Boolean sh )
		{	if (sh)		GetCheckBox(kSpectral_CrossPhase_ChkBox)->Show();
			else		GetCheckBox(kSpectral_CrossPhase_ChkBox)->Hide();
		};
	void	HideAndShowWindow( Boolean sh )
		{	if (sh)		GetPopup( kSpectral_WindowType_Popup )->Show();
			else		GetPopup( kSpectral_WindowType_Popup )->Hide();
		};
	void	HideAndShowCommand( CommandT inCommand )
		{	switch (inCommand)
			{	case cmd_Periodogram:
					//HideAndShowParam( false );
					//HideAndShowConfLevel( false );
					//GetPopup( kSpectral_WindowType_Popup )->Show();
					break;
				case cmd_BTukey:
					//HideAndShowParam( true );
					//HideAndShowConfLevel( true );
					//GetPopup( kSpectral_WindowType_Popup )->Show();
					break;
				case cmd_MTM:
					GetStaticText( kSpectral_Percent_StatTxt )->SetText( LStr255("\pwidth.ndata product") );
					GetStaticText( kSpectral_NbLag_StatTxt )->SetText( LStr255("\pnb of windows") );
					//break;
				case cmd_MaxEntropy:
				default:
					//HideAndShowParam( true );
					//HideAndShowConfLevel( false );
					//GetPopup( kSpectral_WindowType_Popup )->Hide();
					SetCheckBoxValue( kSpectral_ResampleFreq_ChkBox, true );
					GetCheckBox( kSpectral_ResampleFreq_ChkBox )->Disable();
					break;
			}
			HideAndShowParam( 		 inCommand != cmd_Periodogram );
			HideAndShowWindow( 		 (inCommand == cmd_BTukey || inCommand == cmd_Periodogram) );
			HideAndShowConfLevel( 	 inCommand == cmd_BTukey );
			HideAndShowInfSupErrors( (inCommand == cmd_BTukey || inCommand == cmd_MTM) );
			HideAndShowMTMAmplitude( inCommand == cmd_MTM );
			HideAndShowResample();
		};
	void	AdjustStatistics()
		{	double	level = GetDValue( kSpectral_ConfLevel_ETxt )/100.0;
			MyMath::spectralwindowfunc*	window = GetSpectralWindow();
			size_t	lag = GetEditText( kSpectral_ParamNumber_ETxt )->GetValue();
			size_t	n = series_length();
			double	dx = in_x->step();
			ostringstream s;
			if (lag >= 2)
			{	double	m_over_n = lag/(double)n;
				double	bw = window->BandWidth( lag )/dx;
				window->SetBTStats( level, m_over_n );
				s << "The bandwidth is " << bw;
				if (GetCheckBoxValue( kSpectral_Cross_ChkBox ))
					s << "               Non-zero coherence is higher than " << window->NonZeroCoherence();
				s << "\rThe error estimation on the power spectrum is " << window->LowError()
					<< " < �Power / Power < " << window->HighError();
			}
			GetStaticText( kSpectral_StatComment_StatTxt )->SetDescriptor( LStr255(s.str().c_str()) );
			delete window;
		};
	void	SetDefaultScale()
		{	//double	rst = MyMath::Arondi( min_st, MyMath::round_nearest, 3 );	//	rounded step
			//size_t	n1 = MyMath::long_round( (min_xn - max_x1)/rst );			//	Nb of points - 1
			//double	xn = max_x1 + n1 * rst;
			Boolean	slicing = GetCheckBoxValue( kSpectral_Evol_ChkBox );
			
			//size_t	n 	= series_length();
			//double	dx 	= in_x->step();
			double	fc 	= 1/(2*in_x->step());
			double	stp = MyMath::Arondi( 2*fc/series_length()/overSamplFactor, MyMath::round_nearest, -1 );
			double	fm  = MyMath::Arondi( ( slicing ? fc : 0.4 * fc ), MyMath::round_nearest, 2 );
			//size_t	n   = 1 + MyMath::long_round( fm/stp );
			
			SetDValue( kSpectral_FreqFrom_ETxt, 0.0 );
			SetDValue( kSpectral_FreqTo_ETxt,   fm );
			SetDValue( kSpectral_FreqStep_ETxt, stp );
			//ShowEvenScale( true );
			//SetNbText();
		}
public:
	Boolean	GetFreqScale( double& from, double& to, double& step )
		{	Boolean	isOk = true;
			from	= GetDValue( kSpectral_FreqFrom_ETxt, isOk );
			to		= GetDValue( kSpectral_FreqTo_ETxt, isOk );
			step	= GetDValue( kSpectral_FreqStep_ETxt, isOk );
			return ( isOk && (step > 0) && (to > from) );
		};
	double	OverFactor()
		{	double	fc 	= 1/(2*in_x->step());
			double	stp	= GetDValue( kSpectral_FreqStep_ETxt );
			size_t	lag = GetEditText( kSpectral_ParamNumber_ETxt )->GetValue();
			size_t	n_zz = MyMath::nextPower2( lag-1 ) + 1;
			return 	overSamplFactor * fc/stp/n_zz;
		}
public:
	MyMath::spectralwindowfunc*	GetSpectralWindow()
		{	PaneIDT	windowType = GetPopupValue( kSpectral_WindowType_Popup );
			MyMath::spectralwindowfunc*	window = NULL;
			switch (windowType)
			{	case k_BartlettWindow:	window = new MyMath::Bartlett_spectralwindowfunc();		break;
				case k_TukeyWindow:		window = new MyMath::Tukey_spectralwindowfunc();		break;
				case k_ParzenWindow:	window = new MyMath::Parzen_spectralwindowfunc();		break;
				case k_WelchWindow:		window = new MyMath::Welch_spectralwindowfunc();		break;
				case k_squareWindow:
				default:				window = new MyMath::square_spectralwindowfunc();		break;
			}
			return	window;
		}
	size_t	series_length()			//	between 2 and in_x->length()
		{	Boolean	isOk  = true;
			double	wSize = GetDValue( kSpectral_EvolWindow_ETxt, isOk );
			if (GetCheckBoxValue( kSpectral_Evol_ChkBox ) && isOk)	
			{	//return std::min( (long)in_x->length(), std::max( (long)2, GetEditText( kSpectral_EvolWindow_ETxt )->GetValue() ));
				size_t wLength = 1 + MyMath::long_round( wSize/in_x->step() );
				return std::min( in_x->length(), std::max( (size_t)2, wLength ));
			}
			else	return in_x->length();
		};
	
public:
	static Boolean	saved;
//	static double	saved_Freq;
//	static double	saved_Bw;
//	static double	saved_SlopeW;
//	static Boolean	saved_Notch;
//	static SInt32	saved_FunctionType;
public:
	enum { class_ID = 'spcD' };
	
	CSpectralDialog( LStream *inStream )	: CMyStdDialog( inStream ),
		overSamplFactor( 4 ), current_paramscale(NULL), linked_paramscale(true)
		{	
		};
	~CSpectralDialog()
		{	
		};

	virtual void	ListenToMessage( MessageT inMessage, void *ioParam )
		{	switch ( inMessage ) {
				case msg_SpectralEvolChkBoxChanged:
					HideAndShowEvol();
					SetDefaultScale();
					break;
				case msg_SpectralEvolWSizeChanged:
				case msg_SpectralEvolWNumberChanged:
				{	double wSize = GetDValue( kSpectral_EvolWindow_ETxt );
					size_t wNumb = GetEditText( kSpectral_EvolStep_ETxt )->GetValue();
					size_t wLength = 1 + MyMath::long_round(wSize/in_x->step());
					double w_over_percent = (wLength * wNumb - in_x->length())/((double)(in_x->length()));
					ostringstream os;
					os << "(" << wLength << " points by window, " << MyMath::long_round(100 * w_over_percent) << "% oversampling)";
					GetStaticText( kSpectral_EvolComment_StatTxt )->SetText(LStr255(os.str().c_str()));
			
					SetDefaultScale();	}
					break;
				case msg_SpectralParamCursorChanged:
					AdjustParamNumberFromCursor();
					AdjustParamPercentFromNumber();
					AdjustStatistics();
					break;
				case msg_SpectralParamPercentChanged:
					StopListening();
					if (linked_paramscale)	AdjustParamNumberFromPercent();
					if (linked_paramscale)	AdjustParamCursorFromNumber();
					StartListening();
					AdjustStatistics();
					break;
				case msg_SpectralParamNumberChanged:
					StopListening();
					AdjustParamCursorFromNumber();
					if (linked_paramscale)	AdjustParamPercentFromNumber();
					StartListening();
					AdjustStatistics();
					break;
				case msg_SpectralWindowPopupChanged:
				case msg_SpectralConfLevelChanged:
					AdjustStatistics();
					break;
				case msg_ResampleFreqChkBoxChanged:
					HideAndShowResample();
					break;
				case msg_SpectralPreWChkBoxChanged:
					HideAndShowPreW();
					break;
				default:
					LDialogBox::ListenToMessage( inMessage, ioParam );
					break;
			}
		};
	virtual Boolean	ValidDialog()		//	only check wether it is consistent
		{	double	from, to, step;
			Boolean	isOk = GetFreqScale( from, to, step );
			if (isOk)
			{	if (step <= 0)			MySimpleAlert( "\pThe time step must be positive", this );
				else if (to <= from)	MySimpleAlert( "\pThe final time must be larger than the starting time", this );
				isOk = ( isOk && (step > 0) && (to > from) );
			}
			else	MySimpleAlert( "\pSome numerical fields are unreadable", this );
			if (isOk)
			{	GetDValue( kSpectral_EvolWindow_ETxt, isOk );
				if (!isOk)	MySimpleAlert( "\pSome numerical fields are unreadable", this );
			}
			return	isOk;
		};
	virtual void	SetupDialog()
		{	if (saved)
			{	//SetDValue( kFiltering_Frequency, saved_Freq );
				//SetDValue( kFiltering_Bandwidth, saved_Bw );
				//SetDValue( kFiltering_Slopewidth, saved_SlopeW );
				//StopListening();
				//SetCheckBoxValue( kFiltering_Notch_ChkBox, saved_Notch );
				//SetPopupValue( kFiltering_FuncPopup, saved_FunctionType );
				//StartListening();
			}
		};
	virtual void	SaveDialog()
		{	saved 		= true;
			//saved_Freq		= GetDValue( kFiltering_Frequency );
			//saved_Bw		= GetDValue( kFiltering_Bandwidth );
			//saved_SlopeW	= GetDValue( kFiltering_Slopewidth );
			//saved_Notch		= GetCheckBoxValue( kFiltering_Notch_ChkBox );
			//saved_FunctionType 	= GetPopupValue( kFiltering_FuncPopup );
		};
		
	void	SetupDialogScale( STableItem1D*	item, MyMath::double_regular_array* x, CommandT inCommand )			//	initialization is here
		{	inputItem = item;
			in_x = x;
			
			size_t n = in_x->length();
			//size_t wLength = (n > 50 ? MyMath::long_round(sqrt((double)n)) : n);				//	nb of points in each window
			size_t wLength = (n > 50 ? MyMath::long_round(50+70*(log10((double)n)-1.7)) : n);	//	nb of points in each window
			size_t wNumb = (2 * n)/wLength;														//	nb of windows
			
			double wSize = (wLength-1) * in_x->step();											//	real size of window
			//size_t wStep = (n > 50 ? wLength/2 : 0);
			double w_over_percent = (wLength * wNumb - n)/((double)n);
			
			SetDValue( kSpectral_EvolWindow_ETxt, wSize );						//	was wLength
			GetEditText( kSpectral_EvolStep_ETxt )->SetValue( wNumb );			//	was wStep
			ostringstream os;
			os << "(" << wLength << " points by window, " << MyMath::long_round(100 * w_over_percent) << "% oversampling)";
			GetStaticText( kSpectral_EvolComment_StatTxt )->SetText(LStr255(os.str().c_str()));
			
			size_t	nb = inputItem->TableSize();							//	nb of series
			SetCheckBoxValue( kSpectral_Cross_ChkBox, nb>1 );
			Boolean	crossAnalysis = (inCommand == cmd_BTukey && nb>1);
			if (crossAnalysis)	GetCheckBox(kSpectral_Cross_ChkBox)->Enable();
			else				GetCheckBox(kSpectral_Cross_ChkBox)->Disable();
			HideAndShowCrossPhase( crossAnalysis );
				
			HideAndShowCommand( inCommand );
			HideAndShowEvol();
			SetParamScale( inCommand );
			HideAndShowPreW();
		//	StopListening();
		//	AdjustParamNumberFromPercent();
		//	StartListening();
		
			AdjustParamNumberFromCursor();
			AdjustParamPercentFromNumber();
			AdjustStatistics();
			SetDefaultScale();
		};
	
protected:
	virtual	SInt16	rPPob()	{	return	rPPob_SpectralDialog;	};
	
};
