
#pragma once


#include <fstream>
#include <sstream>

#include <LFile.h>
#include <LHandleStream.h>


class	myStdCFileStream :	public LFile,
							public LHandleStream			// cf class LFileStream
{
public:
	std::iostream*		itsIOStream;
	
private:
	std::stringbuf*		its_strbuf;
	std::filebuf*		its_filebuf()	{	return iofile.rdbuf();	};
	
	std::fstream	iofile;
	Boolean			onDisk;
	
	Handle		ReadDataFork_AddNullChar();
	
	Boolean		convertSpecToPath( FSSpec * s, char * p, int pLen );
	void		convertPathToSpec( FSSpec * s, const char * p );
	void		makeFileSpecIntoDir( FSSpec &outFSSpec, const FSSpec& inDirSpec, ConstStringPtr fName );
	
	void		InitNULL()
					{	onDisk = false;
						itsIOStream		= NULL;
						its_strbuf		= NULL;
					};
	
	void	AttachStreamToFile();
	void	AttachStreamToStr();
	
public:

	myStdCFileStream()
		{	InitNULL();	};
	~myStdCFileStream()
		{	Close( false );
			if (itsIOStream)	delete itsIOStream;
			if (its_strbuf)		delete its_strbuf;
		};
		

	Boolean		isOnDisk()	{	return	onDisk;	};
	
	virtual void	SetMarker( SInt32 inOffset, EStreamFrom	inFromWhere )
	//	Place the Read/Write Marker at an offset from a specified position
	//	inFromWhere can be streamFrom_Start, streamFrom_End, or streamFrom_Marker
	{		// LStream uses positive offsets from the end to mean move
			// backwards. But, SetFPos always uses negative offsets for
			// moving backwards. To allow people to use LFileStream from
			// a LStream pointer, we need to support the PP convention
			// by switching positive offsets from the end to the negative
			// value so that SetFPos does what was intended.
			
		if ((inFromWhere == streamFrom_End) && (inOffset > 0))
		{	inOffset = -inOffset;	}

		OSErr	err = ::SetFPos(GetDataForkRefNum(), inFromWhere, inOffset);
		if (err != noErr)
			err = ::FSSetForkPosition(GetDataForkRefNum(), inFromWhere, inOffset);
		ThrowIfOSErr_(err);
	}
	
	virtual SInt32	GetMarker() const
	//	Return the Read/Write Marker position
	//	Position is a byte offset from the start of the data fork
	{	SInt32	theMarker;
		SInt64	theMarker64;
		OSErr	err = ::GetFPos(GetDataForkRefNum(), &theMarker);
		if (err != noErr)
		{	err = ::FSGetForkPosition(GetDataForkRefNum(), &theMarker64);
			theMarker = theMarker64;
		}
		ThrowIfOSErr_(err);
		return theMarker;
	}
	
	virtual void	SetLength( SInt32 inLength )
	//	Set the length, in bytes, of the data fork of a FileStream
	{	OSErr	err = ::SetEOF(GetDataForkRefNum(), inLength);
		if (err != noErr)
			err = ::FSSetForkSize(GetDataForkRefNum(), fsFromStart, inLength );
		ThrowIfOSErr_(err);
		LStream::SetLength(inLength);
	}

	virtual SInt32	GetLength() const
	//	Return the length, in bytes, of the data fork of a FileStream
	{
		SInt32	theLength;
		SInt64	longFileLength;
		OSErr	err = ::GetEOF(GetDataForkRefNum(), &theLength);
		if (err != noErr)
		{	err = ::FSGetForkSize(GetDataForkRefNum(), &longFileLength);
			theLength = longFileLength;
		}
		ThrowIfOSErr_(err);
		return theLength;
	}

	virtual ExceptionCode	PutBytes( const void *inBuffer, SInt32 &ioByteCount )
	//	Write bytes from a buffer to a DataStream
	//	Returns an error code and passes back the number of bytes actually
	//	written, which may be less than the number requested if an error occurred.
	{
		return ::FSWrite(GetDataForkRefNum(), &ioByteCount, inBuffer);
	}

	virtual ExceptionCode	GetBytes( void *outBuffer, SInt32 &ioByteCount )
	//	Read bytes from a DataStream to a buffer
	//	Returns an error code and passes back the number of bytes actually
	//	read, which may be less than the number requested if an error occurred.
	{	SInt32 	byteCount = ioByteCount;
		OSErr	err = ::FSRead(GetDataForkRefNum(), &byteCount, outBuffer);
		if (err != noErr)
		{	ByteCount actualCount;
			err = ::FSReadFork( GetDataForkRefNum(), fsFromStart, 0, ioByteCount, outBuffer, &actualCount );
				ioByteCount = actualCount;
		} else 	ioByteCount = byteCount;
		return	err;
	}

	ConstStringPtr	GetFileName()	{	return	mMacFileSpec.name;	};

	void	CreateNewDirectory( const FSSpec& inDirSpec, ConstStringPtr inDirName );

	virtual void	Open( SignedByte permission )					//	open from FSSpec
				{	OpenC( permission );		};
	
	virtual void	Buffer();

	virtual void	Close( Boolean canFail = false );
	
	virtual Handle	ReadDataFork();
	virtual SInt16	OpenDataFork( SInt16 inPrivileges );
		
	Boolean	ChooseAndOpenR()	// SFTypeList inTypeList = nil, int numTypes = 0 )
				{	return	ChooseFileAndOpen( fsRdPerm );	};	//, inTypeList, numTypes );	};
	Boolean	ChooseAndOpenRW()	// SFTypeList inTypeList = nil, int numTypes = 0 )
				{	return	ChooseFileAndOpen( fsRdWrPerm );	};	//, inTypeList, numTypes );	};
				
	void	CreateAndOpenW( OSType inCreator, OSType inFileType );
	void	CreateAndOpenWIntoDir( const FSSpec& dirSpec, ConstStringPtr fName, OSType inCreator, OSType inFileType )
				{	makeFileSpecIntoDir( mMacFileSpec, dirSpec, fName );
					CreateAndOpenW( inCreator, inFileType );
				};
	Boolean	ChooseAndOpenW( OSType inCreator, OSType inFileType, ConstStringPtr defaultName );
	
	Boolean	ChooseAndOpenR_TEXT()
				{	/*SFTypeList typeList = {'TEXT'};*/	return	ChooseAndOpenR( );	};	// typeList, 1 );	};
	Boolean	ChooseAndOpenRW_TEXT()
				{	/*SFTypeList typeList = {'TEXT'};*/	return	ChooseAndOpenRW( );	};	// typeList, 1 );	};
	
	static long		GetDirectoryID( const FSSpec& dirSpec );
	static Boolean	IsDirectory( const FSSpec& dirSpec );
	static Boolean	GetFileInDir( short index, short vRefNum, long dirID, FSSpec& outSpec, OSType& fileType );
	
private:
	void	OpenPP( SignedByte permission );		//	PowerPlant Style..	does not set the ansiFile, etc..
	void	OpenC( SignedByte permission );			//	C Style...			set all ansi features
	
	Boolean	ChooseFileAndOpen( SignedByte permission );	//, SFTypeList inTypeList = nil, int numTypes = 0 );	//	default typeList = all files
	Boolean	PickFileName( FSSpec &outFSSpec, ConstStringPtr defaultName );
};


