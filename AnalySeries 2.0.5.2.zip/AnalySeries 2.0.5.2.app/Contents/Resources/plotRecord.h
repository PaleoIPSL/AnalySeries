
#pragma once

#ifndef PLOTRECORD_H
#define PLOTRECORD_H


#include <list>
#include <string>
#include <sstream>
#include <limits>

#include "myMath.h"

using namespace std;

class	Contour;
class	plotScale;
class	ContourGrid;
class	ContourNode;






















class	line_type {
public:
//	to be overriden = info for describing the line (color, size, ...)
	line_type()		{};
	virtual void	setIndex( int )				{};		//	line type may depend on some index value (contour index, plot index)
	virtual void	setValue( double )			{};		//	... or on some value (contour value)
	virtual void	setScale( plotScale* )	{};		//	... or on some scale (contours)
	
	virtual line_type*	copy()		{	return	NULL;	};
};


typedef enum {	center, topLeftCorner, topRightCorner, bottomLeftCorner, bottomRightCorner,
				leftSide, rightSide, topSide, bottomSide }	textPosition;

class	drawer {
public:
	typedef	void (drawer::*DrawingRoutine)(double, double);
	typedef	void (drawer::*SetLineTypeRoutine)(line_type*);
	typedef	void (drawer::*DrawingTxtRoutine)(const char*, double, double, textPosition);
	typedef	void (drawer::*DrawingResetRoutine)();
	typedef	void (drawer::*EraseRoutine)(double, double, double, double);
/*
	SetLineTypeRoutine	setline;
	DrawingRoutine		moveto;
	DrawingRoutine		lineto;
	DrawingTxtRoutine	drawText;
	DrawingResetRoutine resetDraw;
	EraseRoutine		eraseDraw;
*/
	virtual void moveto( double, double ) = 0;
	virtual void lineto( double, double ) = 0;
	virtual void setline(line_type*) = 0;
	virtual void drawText(const char*, double, double, textPosition) = 0;
	virtual void resetDraw() = 0;
	virtual void eraseDraw(double, double, double, double) = 0;
};

/*
typedef	void (*DrawingRoutine)(double, double);
typedef	void (*SetLineTypeRoutine)(line_type*);
typedef	void (*DrawingTxtRoutine)(const char*, double, double, textPosition);
typedef	void (*DrawingResetRoutine)();
typedef	void (*EraseRoutine)(double, double, double, double);
*/

class	polyLine {
protected:
	double_vector	x;
	double_vector	y;
public:
	line_type*		type;
public:
//	polyLine( line_type* t = NULL )	: type(t)	{};
	polyLine( size_t n, line_type* t = NULL ) : x(n), y(n), type(t)	{};
	polyLine( const double_vector& xx, const double_vector& yy, line_type* t = NULL )
		: x(xx), y(yy), type(t)	{};
	polyLine( Contour* ctr, line_type* t = NULL );
	virtual ~polyLine()		{};		//	if (type)	delete type;	};
	
	virtual	void	GetMinAndMax( double& minX, double& maxX, double& minY, double& maxY );
	virtual	void	Draw( drawer* draw, const plotScale& x_sc, const plotScale& y_sc, Boolean& refresh_scale );
	virtual Boolean	CheckResolution( const plotScale&, const plotScale& )		{	return false;	};
};

class	rectangleLine : public polyLine {
public:
	rectangleLine( double x0, double y0, double x1, double y1, line_type* t = NULL ) : polyLine(5,t)
		{	/*x = double_vector(5);*/	x[1] = x0;	x[2] = x1;	x[3] = x1;	x[4] = x0;	x[5] = x0;
			/*y = double_vector(5);*/	y[1] = y0;	y[2] = y0;	y[3] = y1;	y[4] = y1;	y[5] = y0;
		};
};

class	unscaledLine : public polyLine {		//	no scaling, except for point (x_pos, y_pos). The line (x(),y()) is relative to it.
protected:
	double	x_pos;
	double	y_pos;
public:
//	unscaledLine( double xp, double yp, line_type* t = NULL ) : polyLine(t), x_pos(xp), y_pos(yp)		{};
	unscaledLine( size_t n, double xp, double yp, line_type* t = NULL ) : polyLine(n,t), x_pos(xp), y_pos(yp)		{};
	unscaledLine( double xp, double yp, const double_vector& xx, const double_vector& yy, line_type* t = NULL )
		: polyLine(xx,yy,t), x_pos(xp), y_pos(yp)		{};
	virtual	void	GetMinAndMax( double& minX, double& maxX, double& minY, double& maxY );
	virtual	void	Draw( drawer* draw, const plotScale& x_sc, const plotScale& y_sc, Boolean& refresh_scale );
};

class	boxSymbol : public unscaledLine {
public:
	boxSymbol( double xp, double yp, double wdth, line_type* t = NULL ) : unscaledLine(5,xp,yp,t)
		{	double	w2 = wdth/2;
		//	x = double_vector(5);	x[1] = xp-w2;	x[2] = xp+w2;	x[3] = xp+w2;	x[4] = xp-w2;	x[5] = xp-w2;
		//	y = double_vector(5);	y[1] = yp-w2;	y[2] = yp-w2;	y[3] = yp+w2;	y[4] = yp+w2;	y[5] = yp-w2;
			/*x = double_vector(5);*/	x[1] = -w2;	x[2] = w2;	x[3] = w2;	x[4] = -w2;	x[5] = -w2;
			/*y = double_vector(5);*/	y[1] = -w2;	y[2] = -w2;	y[3] = w2;	y[4] = w2;	y[5] = -w2;
		};
};
class	ibeamSymbol : public unscaledLine {
public:
	ibeamSymbol( double xp, double yp, double hght, double wdth, line_type* t = NULL ) : unscaledLine(9,xp,yp,t)			//	ex. beam hght=12; arrow wdth=6
		{	double	h2 = hght/2;
			double	w2 = wdth/2;
		//	x = double_vector(9);	x[1] = xp-w2;		x[2] = xp;		x[3] = xp;		x[4] = xp-w2;		x[5] = xp;		x[6] = xp+w2;		x[7] = xp;		x[8] = xp;		x[9] = xp+w2;
		//	y = double_vector(9);	y[1] = yp-h2-w2;	y[2] = yp-h2;	y[3] = yp+h2;	y[4] = yp+h2+w2;	y[5] = yp+h2;	y[6] = yp+h2+w2;	y[7] = yp+h2;	y[8] = yp-h2;	y[9] = yp-h2-w2;
			/*x = double_vector(9);*/	x[1] = -w2;		x[2] = 0;	x[3] = 0;	x[4] = -w2;		x[5] = 0;	x[6] = w2;		x[7] = 0;	x[8] = 0;	x[9] = w2;
			/*y = double_vector(9);*/	y[1] = -h2-w2;	y[2] = -h2;	y[3] = h2;	y[4] = h2+w2;	y[5] = h2;	y[6] = h2+w2;	y[7] = h2;	y[8] = -h2;	y[9] = -h2-w2;
		};
};
class	vertLineSymbol : public unscaledLine {
public:
	vertLineSymbol( double xp, double yp, double hght, line_type* t = NULL ) : unscaledLine(2,xp,yp,t)			//	ex. beam hght=12; arrow wdth=6
		{	double	h2 = hght/2;
			/*x = double_vector(2);*/	x[1] = 0;	x[2] = 0;
			/*y = double_vector(2);*/	y[1] = h2;	y[2] = -h2;
		};
};
class	horizLineSymbol : public unscaledLine {
public:
	horizLineSymbol( double xp, double yp, double wdth, line_type* t = NULL ) : unscaledLine(2,xp,yp,t)			//	ex. beam hght=12; arrow wdth=6
		{	double	w2 = wdth/2;
			/*x = double_vector(2);*/	x[1] = w2;	x[2] = -w2;
			/*y = double_vector(2);*/	y[1] = 0;	y[2] = 0;
		};
};
class	crossLineSymbol : public unscaledLine {
public:
	crossLineSymbol( double xp, double yp, double hght, double wdth, line_type* t = NULL ) : unscaledLine(5,xp,yp,t)			//	ex. beam hght=12; arrow wdth=6
		{	double	h2 = hght/2;
			double	w2 = wdth/2;
			/*x = double_vector(5);*/	x[1] = w2;	x[2] = -w2;	x[3] = 0;	x[4] = 0;	x[5] = 0;
			/*y = double_vector(5);*/	y[1] = 0;	y[2] = 0;	y[3] = 0;	y[4] = h2;	y[5] = -h2;
		};
};



class	BitTable {
public:
	unsigned long	bit[32];
	ulong_matrix0	table;
	
	BitTable( size_t nnx, size_t nny ) : table( 1 + (nnx-1)/32, nny )
		{	bit[0] = 1;
			for (int i = 1; i < 32; i++)
				bit[i] = bit[i-1] << 1;
		};
	~BitTable()	{};
	void		Set( size_t i, size_t j )		{	table( i/32, j ) |= bit[i%32];		};
	void		Unset( size_t i, size_t j )		{	table( i/32, j ) &= ~(bit[i%32]);	};
	Boolean 	isSet( size_t i, size_t j )		{	return ((table(i/32,j) & bit[i%32]) != 0);		};
	void		SetAll()						{	table = ~(0L);	};
	void		UnsetAll()						{	table = 0L;		};
};



class	ContourNode {
public:
	double 			x, y;
	int				iPos, jPos;
	Boolean			isHorizontal, edgeNode;
	ContourNode*	next;
	
	ContourNode( double xx, double yy, int i, int j )
		: x(xx), y(yy), iPos(i), jPos(j), isHorizontal(true), edgeNode(true), next(NULL)	{};
	ContourNode( double xx, double yy, Boolean b )
		: x(xx), y(yy), iPos(-10), jPos(-10), isHorizontal(b), edgeNode(false), next(NULL)	{};
	ContourNode( double xx, double yy, Boolean b, int i, int j )
		: x(xx), y(yy), iPos(i), jPos(j), isHorizontal(b), edgeNode(false), next(NULL)		{};
	~ContourNode()
		{	delete	next;	};
	
	Boolean	HasEdge( int i, int j )
		{	if	( (i==iPos) && (j==jPos) ||
				( (isHorizontal) && (i==iPos+1) && (j==jPos) ) ||
				( (!isHorizontal) && (i==iPos) && (j==jPos+1) ) )	return true;
			else return false;
		};

	void			NextBox( int i, int j, int& i1, int& j1 );
	void			Unset( ContourGrid* ctrGrid );
	ContourNode* 	FindNearest( ContourNode* n1, ContourNode* n2, ContourNode* n3 );
	ContourNode*	FindNearestAndUnset( ContourNode* n1, ContourNode* n2,
							ContourNode* n3, ContourGrid* ctrGrid );
	Boolean 		isOnBoundary( ContourGrid* ctrGrid );
	Boolean 		isCloseToBoundary( ContourGrid* ctrGrid, int n );
	Boolean 		isOnGrid( ContourGrid* ctrGrid, Contour* ctr );
	void			PutOnGrid( ContourGrid* ctrGrid, Contour* ctr );
//	Boolean		FourthCorner( ContourGrid* ctrGrid, int& i, int& j );
	Boolean		isOnFlatBoundaryBox( ContourGrid* ctrGrid, ContourNode* n, Contour* ctr );

	Boolean	FirstCorner( int& i, int& j );
	Boolean	NextCorner( int& i, int& j );
	Boolean	NextGoodCorner( ContourNode* n, ContourGrid* ctrGrid, double v, int i0, int j0, int& i, int& j );
	Boolean	NextGoodCorner( ContourNode* n, ContourGrid* ctrGrid, double v, int& i, int& j );
	Boolean	NextGoodCorner( ContourGrid* ctrGrid, double v, int i0, int j0, int& i, int& j );
	Boolean	NextGoodCorner( ContourGrid* ctrGrid, double v, int& i, int& j );
};



class	Contour	{
public:
	ContourNode*	firstNode;
	ContourNode*	lastNode;
	double			value;
	Contour*		next;
	Boolean			closed;
	
	Contour( double v ) : value(v), closed(false)
				{	firstNode = lastNode = NULL;	next = NULL;	};
	~Contour()	{	delete firstNode;	delete next;	};
	
	void	Append( ContourNode* n )
			{	if (lastNode)	{	lastNode->next = n;	lastNode = n;	}
				else			{	firstNode = lastNode = n;			}
				while (lastNode->next)	lastNode = lastNode->next;
			};
	void	Append( Contour* ctr )
			{	Contour* c = this;	while (c->next)		c = c->next;
				c->next = ctr;
			};
	void	Close( ContourGrid* ctrGrid );
	int		NbNodes();
	int		NbLineNodes() 	{	return	( (closed) ? NbNodes()+1 : NbNodes() );	};
	
	void			AddCorners( ContourGrid* ctrGrid );
	void			PutOnGrid( ContourGrid* ctrGrid );
	void			RemoveFlatBoundary( ContourGrid* ctrGrid );
	void			EndOnFlatBoundary( ContourGrid* ctrGrid, ContourNode* n );
	ContourNode*	ToNearestBoundary( ContourGrid* ctrGrid, ContourNode* n );
	ContourNode*	StartOnFlatBoundary( ContourGrid* ctrGrid, ContourNode* n );
};



const double plotScale_Rel_Min = 1e-10;
const double plotScale_Abs_Min = 1e-100;

class	plotValueScale {
private:
	double_vector*			_Values;
	
	void	MakeScale( int n, double startX, double interX = 0 )
	{	nxScale = n;
		xInterval = interX;
		if (n == 1)
		{	_Values = new double_vector1(1);
			(*_Values)[1] = startX;
		}
		else
		{	_Values = new MyMath::regular_array<double,1>( startX, startX + (nxScale-1)*xInterval, nxScale );
			for (size_t i=1; i<=nxScale; i++)
				if ( fabs((*_Values)[i]) < 1e-10 * xInterval )	(*_Values)[i] = 0;
		}
	};
	
public:
	const double_vector&	Values()	{	return *_Values;	};
	unsigned long	nxScale;
	double			xInterval;
	unsigned long	maxNxScale;
	
	plotValueScale( int n )/* : xValues(_Values)*/		{	maxNxScale = n;	};
	
	
    double		xValues(size_t pos) const	{	return (*_Values)[pos];	};
	
	static double	ArondiUp( double x, double fx )
	{	if (x == 0)		return 0;
		double xx = x/fx;
		double y;
		double	tx = 10 * modf( xx/10, &y );
		
		if (tx == 1)	return		fx * (10*y + 1);
		if (tx <= 2)	return		fx * (10*y + 2);
		if (tx <= 5)	return		fx * (10*y + 5);
		else			return		fx * (10*y + 10);
	};

	static double	ArondiDown( double x, double fx )
	{	if (x == 0)		return 0;
		double xx = x/fx;
		double y;
		double	tx = 10 * modf( xx/10, &y );
		
		if (tx < 2)		return		fx * (10*y + 1);
		if (tx < 5)		return		fx * (10*y + 2);
		if (tx < 10)	return		fx * (10*y + 5);
		else			return		fx * (10*y + 10);
	};
	static double	ArondiDown( double x )
		{	return (x == 0 ? 0 : ArondiDown( x, Power10Factor(x) ));	};	
	static double	ArondiUp( double x )
		{	return (x == 0 ? 0 : ArondiUp( x, Power10Factor(x) ));		};
	static double	Power10Factor( double x )
		//{	return (x == 0 ? 0 : ((x < 0) ? -1 : 1) * pow( 10, (int)floor(log10(std::fabs(x))) ));	};
		{	return (x == 0 ? 0 : ((x < 0) ? -1 : 1) * pow( 10, floor(log10(std::fabs(x))) ));	};

/*	void	MakeScale( int n, double startX, double interX )
	{	nxScale = n;
		xInterval = interX;
		xValues = MyMath::regular_array<double,1>( startX, startX + (nxScale-1)*xInterval, nxScale );
		for (int i=1; i<=nxScale; i++)
			if ( fabs(xValues[i]) < 1e-10 * xInterval )	xValues[i] = 0;
	};
*/	void	MakeDefaultScale( double max, double min )
	{	double dv = (max - min) / maxNxScale;
		double mv = std::max(abs(max),abs(min));
		if ( (dv < plotScale_Rel_Min * mv) || (dv < plotScale_Abs_Min) )	dv = 0;
		if (dv > 0)
		{	double	inter = ArondiUp( dv );
			double	x1 = inter * ( (int)floor( min/inter ) );
			if (x1 < min)	x1 += inter;
			int		n = 1 + (int)floor( (max - x1)/inter );
			MakeScale( n, x1, inter );
		}
		else
		{	MakeScale( 1, 0.5*(min+max) );	};	//nxScale = 1;	xInterval = 0;	xValues = double_vector1(1); 	xValues[1] = 0.5*(min+max);	}
	};
};


class	plotScale {				//	default class is linear
protected:
	double	 		resol;
	double	 		minPlotX, maxPlotX;
	double	 		meanPlotX, dPlotX;

protected:
	double	 		zero;
public:
	plotValueScale	xValueScale;
	double	 		left, width;

private:
	void	SetResol()
		{	meanPlotX 	= 0.5*(minPlotX+maxPlotX);
			dPlotX 		= maxPlotX-minPlotX;
			double	dx = abs(maxPlotX - minPlotX);
			double	mx = std::max(abs(maxPlotX),abs(minPlotX));
			if ( (dx < plotScale_Rel_Min * mx) || (dx < plotScale_Abs_Min) )	dx = 0;
			if (dx == 0)	resol = 0;
			else			resol = width / dx;
		};

public:
	plotScale(): xValueScale(10),left(0),width(0)	{};
	
	double	 		Resol()	const	{	return	resol;	};
	
	void	ChangeSize( double l, double w )
		{	left = l;	width = w;	zero = l+w/2;	SetResol();	};
	void	ChangeSize( const plotScale& ps )
		{	ChangeSize( ps.left, ps.width );	};	//	reversed = ps.reversed;	};	
	
	virtual void	SetRange( double Xmin, double Xmax )
		{	minPlotX = Xmin;	maxPlotX = Xmax;	SetResol();		};
	virtual void	DefaultValueScale( double Xmin, double Xmax )
		{	xValueScale.MakeDefaultScale( std::max(Xmax, Xmin), std::min(Xmax, Xmin) );	};
	
//	virtual	plotScale*	copy()	 		const	= 0;
	virtual	Boolean	isReversed() 		const	= 0;
	virtual	double	getPos( double x ) 	const	= 0;
	
	virtual FourCharCode code()			const	= 0;	//	for I/O
};



template <bool Y_reversed> 
class	plotLinScale : public plotScale {
private:
	bool			reversed;
	
protected:
	bool 	is_reversed()	const		{	return	reversed;		};
//	void	set_reverse( bool r )		{	reversed = r;			};
	
public:
	plotLinScale(): plotScale(), reversed(Y_reversed)	{};
	virtual	plotLinScale<Y_reversed>*	copy()	const	{	return new plotLinScale(*this);	};
	
	virtual	double	getPos( double x ) const
		{	if (is_reversed())	return	zero - resol  * (x - meanPlotX);
			else				return	zero + resol  * (x - meanPlotX);
		};
	virtual	double	getScaleValue( double gx ) const
		{	if (is_reversed())	return	(zero - gx)/resol  + meanPlotX;
			else				return	(gx - zero)/resol  + meanPlotX;
		};

	void	Reverse()					{	reversed = !reversed;	};
	void	SetReverse( bool r )		{	if (Y_reversed)	reversed = !r;	else	reversed = r;	};
	virtual	Boolean	isReversed() const	{	return	(Y_reversed ? (!reversed) : reversed);			};
	
	virtual FourCharCode code()	const	{	return	'Lin ';		};
};


typedef	plotLinScale<false>		plotXScale;
typedef	plotLinScale<true>		plotYScale;

/*
class	plotYScale : public	plotScale {			//	the "natural y_scale" is reversed (increasing upwards, not downwards)
public:
	plotYScale(): plotScale()			{	SetReverse( true );				};
	virtual	plotScale*	copy()	const	{	return new plotYScale(*this);	};
	
	virtual	Boolean	isReversed() const	{	return	!(plotScale::isReversed());	};
};
*/


template <bool Y_reversed> 
class	funcScale : public	plotLinScale<Y_reversed> {				//	with a function rescaling
public:
	doubleFunction& func;
	doubleFunction& back_func;		//	the inverse !!
public:
	funcScale( doubleFunction& f, doubleFunction& bf ) : func(f), back_func(bf)		{};
	virtual	plotLinScale<Y_reversed>*	copy()	const	{	return new funcScale(*this);	};
	
	virtual void	SetRange( double Xmin, double Xmax )	{	plotLinScale<Y_reversed>::SetRange( func(Xmin), func(Xmax) );			};
	virtual	double	getPos( double x ) const				{	return	plotLinScale<Y_reversed>::getPos( func(x) );					};
	virtual	double	getScaleValue( double gx ) const		{	return	back_func( plotLinScale<Y_reversed>::getScaleValue( gx ) );		};
	
	virtual FourCharCode code()	const	{	return	'Func';		};
};


typedef	funcScale<false>	funcXScale;
typedef	funcScale<true>		funcYScale;

/*
template <bool Y_reversed> 
class	logScale : public	funcScale<Y_reversed> {
public:
	static	doubleStdFunction	log_func;
	static	doubleStdFunction 	log_back_func;
public:
	logScale<Y_reversed>() : funcScale<Y_reversed>( log_func, log_back_func ) {};
	virtual	plotLinScale<Y_reversed>*	copy()	const	{	return new logScale(*this);	};
	
	virtual FourCharCode code()	const	{	return	'Log ';		};
};
*/

class	logScaleUp : public	funcScale<true> {
public:
	static	doubleStdFunction	log_func;
	static	doubleStdFunction 	log_back_func;
public:
	logScaleUp() : funcScale<true>( log_func, log_back_func ) {};
	virtual	plotLinScale<true>*	copy()	const	{	return new logScaleUp(*this);	};	
	virtual FourCharCode code()	const	{	return	'Log ';		};
};

class	logScaleDown : public	funcScale<false> {
public:
	static	doubleStdFunction	log_func;
	static	doubleStdFunction 	log_back_func;
public:
	logScaleDown() : funcScale<false>( log_func, log_back_func ) {};
	virtual	plotLinScale<false>*	copy()	const	{	return new logScaleDown(*this);	};	
	virtual FourCharCode code()	const	{	return	'Log ';		};
};






class	polyFuncLine : public polyLine {
private:
	MyMath::identityfunc	ifunc;
	MyMath::simplefunc* 	xFunc;
	MyMath::simplefunc* 	yFunc;
	double	startT, endT;
	double	lastXRes, lastYRes;
	void	ResetXY( double xr, double yr );
	Boolean	Check( int n,	list<double>& tl, list<double>& xl, list<double>& yl,
							list<double>::iterator lt0, list<double>::iterator lx0, list<double>::iterator ly0,
							double xres, double yres );
	void	PlotN( int n );
public:
	
//	double	XFuncValue( double t )		{	return	 xFunc->ValueAt(t);	};
//	double	YFuncValue( double t )		{	return	 yFunc->ValueAt(t);	};

/*
	polyFuncLine( MyMath::simplefunc* xf, MyMath::simplefunc* yf, double st, double et, line_type* t = NULL ) : polyLine(t)
		{	xFunc = ( xf==NULL ? &ifunc : xf );	yFunc = yf;
			lastXRes = 0; 	lastYRes = 0;
			startT = st;	endT = et;
			PlotN( 101 );
		};
*/

		//	ATTENTION: it is HIGHLY desirable that input xx and yy give a 'reasonable' idea of the function.
		//	in particular, characteristics such as order of magnitude of y-min and y-max
	polyFuncLine( const double_vector& xx, const double_vector& yy, MyMath::simplefunc* yf, line_type* t = NULL ) : polyLine(xx,yy,t)
		{	xFunc = &ifunc;	yFunc = yf;
			lastXRes = 0; 	lastYRes = 0;
			startT = x[1];	endT = x[x.length()];
		};
		
	~polyFuncLine()		{	//if (xFunc != &ifunc)	delete xFunc;
							//if (yFunc != &ifunc)	delete yFunc;
						};
	
//	virtual	void	GetMinAndMax( double& minX, double& maxX, double& minY, double& maxY );
	virtual	void	Draw( drawer* draw, const plotScale& x_sc, const plotScale& y_sc, Boolean& refresh_scale )
		{	if (lastXRes == 0 || lastXRes < x_sc.Resol() || lastYRes == 0 || lastYRes < y_sc.Resol())
			{	ResetXY( x_sc.Resol(), y_sc.Resol() );
				refresh_scale = true;
			}
			polyLine::Draw( draw, x_sc, y_sc, refresh_scale );
		};
		
	virtual Boolean	CheckResolution( const plotScale& x_sc, const plotScale& y_sc )
		{	if (lastXRes == 0 || lastXRes < x_sc.Resol() || lastYRes == 0 || lastYRes < y_sc.Resol())
			{	ResetXY( x_sc.Resol(), y_sc.Resol() );
				return	true;
			}
			else return false;
		};
};


class	scaler {

private:
	plotXScale	*xScale;			//	the "privately" owned scales
	plotYScale	*yScale;
	
	void	init_null_x()		{	init_x( new plotXScale() );			};
	void	init_null_y()		{	init_y( new plotYScale() );			};
	void	init_null()			{	init_null_x();		init_null_y();	};
	
	void	init_x( plotXScale *x_sc )	{	xScale = x_sc;	xDrawScale = xScale;	};
	void	init_y( plotYScale *y_sc )	{	yScale = y_sc;	yDrawScale = yScale;	};
	
	plotXScale	*xDrawScale;		//	the drawing scales (not owned)
	plotYScale	*yDrawScale;
	
	Boolean	emptyX()	{	return (( minX == std::numeric_limits<double>::max() )
									|| ( maxX == -std::numeric_limits<double>::max() ));		};
	Boolean	emptyY()	{	return (( minY == std::numeric_limits<double>::max() )
									|| ( maxY == -std::numeric_limits<double>::max() ));		};

public:
	virtual void	SetDefaultPrivateScales()
		{	if (!emptyX())	{	SetXRange( minX, maxX );	xScale->DefaultValueScale( minX, maxX );	};
			if (!emptyY())	{	SetYRange( minY, maxY );	yScale->DefaultValueScale( minY, maxY );	};
		};
	
	
	const plotXScale*	X_True_Scale()	{	return	xScale;		};
	const plotYScale*	Y_True_Scale()	{	return	yScale;		};
	
//	const plotXScale*	X_Scale()	{	return	xDrawScale;		};
//	const plotYScale*	Y_Scale()	{	return	yDrawScale;		};
	
	plotXScale*	X_Scale()	{	return	xDrawScale;		};
	plotYScale*	Y_Scale()	{	return	yDrawScale;		};

	void	SetXScale( const plotXScale *sc, Boolean resetRange = true )
		{	if (sc!=NULL)	xDrawScale = (plotXScale*)sc;	else	xDrawScale = xScale;
			if (resetRange)	{	ResetMinAndMax();	SetXDefaults();	};
		};
	void	SetYScale( const plotYScale *sc, Boolean resetRange = true )
		{	if (sc!=NULL)	yDrawScale = (plotYScale*)sc;	else	yDrawScale = yScale;
			if (resetRange)	{	ResetMinAndMax();	SetYDefaults();	};
		};

public:
	double	 	minX, maxX, minY, maxY;		//	= min/max of x[i]/y[i]
	
	scaler()													{	init_null();	};
	scaler( const plotXScale *x_sc, const plotYScale *y_sc )
		{	if (x_sc)	init_x( x_sc->copy() );		else	init_null_x();
			if (y_sc)	init_y( y_sc->copy() );		else	init_null_y();
		};
	
	virtual ~scaler()					{	delete xScale;	delete yScale;	};
	
	virtual void	GetMinMax( double& minX, double& maxX, double& minY, double& maxY ) = 0;
	
	virtual void	ResetMinAndMax()
		{	minX = std::numeric_limits<double>::max();	//1e222;
			maxX = -std::numeric_limits<double>::max();	//-1e222;
			minY = std::numeric_limits<double>::max();	//1e222;
			maxY = -std::numeric_limits<double>::max();	//-1e222;
			GetMinMax( minX, maxX, minY, maxY );
		};

public:
	void	SetRange( double Xmin, double Xmax, double Ymin, double Ymax )
									{	SetXRange( Xmin, Xmax );	SetYRange( Ymin, Ymax );	};	
	
//	void	SetXRange( double Xmin, double Xmax )		{	xDrawScale->SetRange( Xmin, Xmax );		};
//	void	SetYRange( double Ymin, double Ymax )		{	yDrawScale->SetRange( Ymin, Ymax );		};
//	void	SetXDefaults()		{	if (!emptyX())	{	SetXRange( minX, maxX );	xDrawScale->DefaultValueScale( minX, maxX );	};	};
//	void	SetYDefaults()		{	if (!emptyY())	{	SetYRange( minY, maxY );	yDrawScale->DefaultValueScale( minY, maxY );	};	};
	
	void	SetXRange( double Xmin, double Xmax )		{	xDrawScale->SetRange( Xmin, Xmax );		xDrawScale->DefaultValueScale( Xmin, Xmax );	};
	void	SetYRange( double Ymin, double Ymax )		{	yDrawScale->SetRange( Ymin, Ymax );		yDrawScale->DefaultValueScale( Ymin, Ymax );	};	
	void	SetXDefaults()		{	if (!emptyX())	SetXRange( minX, maxX );	};
	void	SetYDefaults()		{	if (!emptyY())	SetYRange( minY, maxY );	};
	
	void	DefaultXScale()		{	if (!emptyX())	xDrawScale->DefaultValueScale( minX, maxX );		};
	void	DefaultYScale()		{	if (!emptyY())	yDrawScale->DefaultValueScale( minY, maxY );		};

	void	RefreshScales()		{	ResetMinAndMax();	SetXDefaults();		SetYDefaults();		};

	void	ReverseX()			{	xDrawScale->Reverse();		};
	void	ReverseY()			{	yDrawScale->Reverse();		};


	virtual void	SetScaleSize( const scaler& sc )
		{	xDrawScale->ChangeSize( *(sc.xDrawScale) );				yDrawScale->ChangeSize( *(sc.yDrawScale) );
		//	xDrawScale->SetReverse( sc.xDrawScale->isReversed() );	yDrawScale->SetReverse( sc.yDrawScale->isReversed() );
		};
	
	virtual void	SetScaleSize( double left_, double width_, double top_, double height_ )
		{	xDrawScale->ChangeSize( left_, width_ );
			yDrawScale->ChangeSize( top_,  height_ );
		};
	virtual	void	DrawXScale( drawer*	draw, int tiret, int offset = 0 )
	{	double	yy = yDrawScale->left + yDrawScale->width + offset;
		draw->moveto( xDrawScale->left, yy );
		draw->lineto( xDrawScale->left + xDrawScale->width, yy );
		for (size_t i=1; i<=xDrawScale->xValueScale.nxScale; i++)
		{	double	xx = xDrawScale->getPos( xDrawScale->xValueScale.xValues(i) );
			draw->moveto( xx, yy - tiret );
			draw->lineto( xx, yy + tiret );
			ostringstream s;	s << xDrawScale->xValueScale.xValues(i);
			draw->drawText( s.str().c_str(), xx, yy + tiret, topSide );
	}	}
	virtual	void	DrawYScale( drawer*	draw, int tiret, int offset = 0 )
	{	double	xx = xDrawScale->left - offset;
		draw->moveto( xx, yDrawScale->left );
		draw->lineto( xx, yDrawScale->left + yDrawScale->width );
		for (size_t i=1; i<=yDrawScale->xValueScale.nxScale; i++)
		{	double	yy = yDrawScale->getPos( yDrawScale->xValueScale.xValues(i) );
			draw->moveto( xx - tiret, yy );
			draw->lineto( xx + tiret, yy );
			ostringstream s;	s << yDrawScale->xValueScale.xValues(i);
			draw->drawText( s.str().c_str(), xx - tiret, yy, rightSide );
	}	}
	
};


class	polyLineList : public list<polyLine*>, public scaler {
public:
	line_type		*type;
	std::string		lineName;
public:
	
	polyLineList( const std::string& name, line_type	*t = NULL ) : type(t), lineName(name)	{};
	polyLineList( const std::string& name, const plotXScale *x_sc, const plotYScale *y_sc, line_type *t = NULL )
		 : scaler( x_sc, y_sc ), type(t), lineName(name)	{};
	~polyLineList()
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		delete	(*l++);
		};

//	void	Reset()
//		{	ResetMinAndMax();	SetDefaults();	/*SetXScale(NULL);	SetYScale(NULL);*/	};
//
	
	virtual void	GetMinMax( double& minX, double& maxX, double& minY, double& maxY )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(*l++)->GetMinAndMax( minX, maxX, minY, maxY );
		}
	
	void	AppendLine( polyLine* line )	{	push_back(line);	};
	void	AppendContour( Contour* ctr, line_type* t = NULL )
		{	for (Contour* curCtr = ctr; curCtr; curCtr = curCtr->next)
				if (curCtr->firstNode)	AppendLine( new polyLine( curCtr, t ) );
		};
	void	AppendAndDeleteContour( Contour* ctr, line_type* t = NULL )
		{	AppendContour( ctr, t );	delete ctr;		};
		
	virtual	Boolean	CheckResolution()
		{	Boolean	check = false;
			iterator l = begin();	const_iterator le = end();
			while (l != le)
			{	check = check || (*l)->CheckResolution( *X_Scale(), *Y_Scale() );	l++;	}		//	!! if (check) needs to evaluate 2nd member!!
			return check;
		};
		
	virtual	void	Draw( drawer* draw, Boolean& refresh_scale )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)
			{	draw->setline( (*l)->type );
				(*l++)->Draw( draw, *X_Scale(), *Y_Scale(), refresh_scale );
		}	};
	virtual	void	DrawXScale( drawer* draw, int tiret, int offstep )
		{	if (type)	draw->setline( type );
			scaler::DrawXScale( draw, tiret, offstep );
		};
	virtual	void	DrawYScale( drawer* draw, int tiret, int offstep )
		{	if (type)	draw->setline( type );
			scaler::DrawYScale( draw, tiret, offstep );
		};
		
/*	polyLine*	GetLine( size_t i )
		{	iterator l = begin();	const_iterator le = end();		size_t k = 1;
			while (l != le && k != i)		{	k++;	l++;	}
			if (l != le)	return *l;
			else			return NULL;
		};
*/
};

/*
class	lineRecord : public list<polyLineList> {
public:
	
	lineRecord()	{};
	~lineRecord()	{};
		
	virtual void	GetMinAndMax( double& minX, double& maxX, double& minY, double& maxY )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(l++)->GetMinMax( minX, maxX, minY, maxY );
		}
		
	void	AppendSimpleLine( polyLine* line, line_type	*t = NULL, plotScale *x_sc = NULL, plotScale *y_sc = NULL )
		{	polyLineList l( x_sc, y_sc, t );		l.AppendLine(line);
			//l.SetXScale( x_sc );	l.SetYScale( y_sc );
			AppendLineList(l);
		};
	void	AppendSubLine( polyLine* line )		//	Append polyLine to the last polyLineList
		{	if (size() > 0)		back().AppendLine( line );
			else				AppendSimpleLine( line );
		};
	void	AppendLineList( polyLineList& linelist )
		{	push_back(linelist);
			//back().Reset();
			back().ResetMinAndMax();	back().SetDefaults();
		};
	virtual	Boolean	CheckResolution()
		{	Boolean	check = false;
			iterator l = begin();	const_iterator le = end();
			while (l != le)
				check = check || (l++)->CheckResolution();
			return check;
		};
	
	virtual	void	Draw( drawer* draw, Boolean& refresh_scale )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(l++)->Draw( draw, refresh_scale );
		};
	virtual	void	DrawXScale( drawer* draw, int tiret, int offstep )
		{	iterator l = begin();	const_iterator le = end();
			int	off = 0;
			while (l != le)	
			{	(l++)->DrawXScale( draw, tiret, off );	off += offstep;	}
		};
	virtual	void	DrawYScale( drawer* draw, int tiret, int offstep )
		{	iterator l = begin();	const_iterator le = end();
			int	off = 0;
			while (l != le)
			{	(l++)->DrawYScale( draw, tiret, off );	off += offstep;	}
		};
	
	void	SetAllPosTo( const scaler& sc )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(l++)->SetPos(sc);
		};
	void	SetAllXScale( const plotScale *sc )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(l++)->SetXScale( sc );
		};
	void	SetAllYScale( const plotScale *sc )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(l++)->SetYScale( sc );
		};
};
*/

class	lineRecord : public list<polyLineList*> {
public:

//	std::string		lineName;
	
	lineRecord()	{};
	virtual ~lineRecord()
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		delete	(*l++);
		};
		
	virtual void	GetMinAndMax( double& minX, double& maxX, double& minY, double& maxY )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(*l++)->GetMinMax( minX, maxX, minY, maxY );
		}
		
	void	AppendSimpleLine( polyLine* line, const std::string& name, line_type	*t = NULL, plotXScale *x_sc = NULL, plotYScale *y_sc = NULL )
		{	polyLineList* l = new polyLineList( name, x_sc, y_sc, t );		l->AppendLine(line);
			//l.SetXScale( x_sc );	l.SetYScale( y_sc );
			//lineName = name;
			AppendLineList(l);
		};
	void	AppendSubLine( polyLine* line )		//	Append polyLine to the last polyLineList
		{	if (size() > 0)		back()->AppendLine( line );
			else				{	std::string s("untitled");	AppendSimpleLine( line, s );	}
		};
	void	AppendLineList( polyLineList* linelist )
		{	//linelist->Reset();
			linelist->ResetMinAndMax();
			linelist->SetXDefaults();
			linelist->SetYDefaults();
			linelist->SetDefaultPrivateScales();
			push_back(linelist);
		};
	virtual	Boolean	CheckResolution()
		{	Boolean	check = false;
			iterator l = begin();	const_iterator le = end();
			while (l != le)
			{	check = check || (*l)->CheckResolution();		l++;	}		//	if (check) need to evaluate 2nd member !!
			return check;
		};
	
	virtual	void	Draw( drawer* draw, Boolean& refresh_scale )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(*l++)->Draw( draw, refresh_scale );
		};
	virtual	void	DrawXScale( drawer* draw, int tiret, int offstep )
		{	iterator l = begin();	const_iterator le = end();
			int	off = 0;
			while (l != le)	
			{	(*l++)->DrawXScale( draw, tiret, off );	off += offstep;	}
		};
	virtual	void	DrawYScale( drawer* draw, int tiret, int offstep )
		{	iterator l = begin();	const_iterator le = end();
			int	off = 0;
			while (l != le)
			{	(*l++)->DrawYScale( draw, tiret, off );	off += offstep;	}
		};
	
	void	SetAllSizeTo( const scaler& sc )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(*l++)->SetScaleSize(sc);
		};
	void	SetAllXScale( const plotXScale *sc, Boolean resetRange = true  )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(*l++)->SetXScale( sc, resetRange );
		};
	void	SetAllYScale( const plotYScale *sc, Boolean resetRange = true )
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(*l++)->SetYScale( sc, resetRange );
		};
	void	InvertAllYScale()
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(*l++)->ReverseY();
		};
	void	InvertAllXScale()
		{	iterator l = begin();	const_iterator le = end();
			while (l != le)		(*l++)->ReverseX();
		};
		
	polyLineList*	GetLineList( size_t i )
		{	iterator l = begin();	const_iterator le = end();		size_t k = 1;
			while (l != le && k != i)		{	k++;	l++;	}
			if (l != le)	return *l;
			else			return NULL;
		};
};




class	plotRecord: public scaler {
public:
	string		plotTitle;
	string		xTitle;
	string		yTitle;
	string		xUnit;
	string		yUnit;
	string		caption;
	
	long		leftMargin, rightMargin, drawingWidth, fullWidth;
	long		topMargin, bottomMargin, drawingHeight, fullHeight;
//	long		curFrame;
//	long		lastFrame;
	
	typedef enum {	no_scale, same_scale, multiple_scale }	scale_type;
	
	scale_type	nx_sc, ny_sc;
	
		//	options
	Boolean		eraseFirst;
	Boolean		drawCaption;
	Boolean		drawBorder;
	Boolean		drawXScale;
	Boolean		drawYScale;
	long		leftMarginDefault, rightMarginDefault, topMarginDefault, bottomMarginDefault;
	
	int				tiret, xscale_step, yscale_step;

	drawer*			itsDrawer;	
	lineRecord		itsLineRecord;

	plotRecord()
		{	//curFrame = 1;
			eraseFirst = true;	drawCaption = true;	drawBorder = true;	drawXScale = true;	drawYScale = true;
			tiret = 3;
			nx_sc = same_scale;			ny_sc = same_scale;
			xscale_step = 15;			yscale_step = 30;
			leftMarginDefault = 10;		rightMarginDefault = 15;	topMarginDefault = 20;		bottomMarginDefault = 5;
			ClearNextScales();
		};
	lineRecord&		curLineRecord()		{	return itsLineRecord;		};
/*
	vector<lineRecord>	itsFrameList;
	plotRecord() : itsFrameList(1)		{	curFrame = lastFrame = 0;	tiret = 3;	nx_sc = same_scale;	ny_sc = same_scale;	xscale_step = 15;	yscale_step = 30;	};
	lineRecord&		curLineRecord()		{	return itsFrameList[curFrame];		};
	void			AddNFrame( long n )	{	lastFrame += n;	itsFrameList.resize_but_keep( lastFrame + 1 );	};
	void			SetFrame( long n )	{	if (n<=lastFrame)	curFrame = n;	};
*/
	virtual	~plotRecord()	{};
	
	
	virtual void	SetTitle( const char* s )	{	plotTitle = s;	};
	virtual void	SetxTitle( const char* s )	{	xTitle = s;		};
	virtual void	SetyTitle( const char* s )	{	yTitle = s;		};
	virtual void	SetxUnit( const char* s )	{	xUnit = s;		};
	virtual void	SetyUnit( const char* s )	{	yUnit = s;		};
	virtual void	SetCaption( const char* s )	{	caption = s;	};
	
	virtual void	SetTitle( const string& s )		{	plotTitle = s;	};
	virtual void	SetxTitle( const string& s )	{	xTitle = s;		};
	virtual void	SetyTitle( const string& s )	{	yTitle = s;		};
	virtual void	SetxUnit( const string& s )		{	xUnit = s;		};
	virtual void	SetyUnit( const string& s )		{	yUnit = s;		};
	virtual void	SetCaption( const string& s )	{	caption = s;	};
	
	virtual void	SetTitles( const char* s1, const char* s2, const char* s3, const char* s4, const char* s5 )
					{	SetTitle(s1);	SetxTitle(s2);	SetxUnit(s3);	SetyTitle(s4);	SetyUnit(s5);	};
	
	virtual void	GetMinMax( double& minX, double& maxX, double& minY, double& maxY )
		{	curLineRecord().GetMinAndMax( minX, maxX, minY, maxY );	}

	void	SetAllSizeToGlobalSize()
		{	curLineRecord().SetAllSizeTo( *this );		};
		
	void	SetSameXScale( const plotXScale* sc = NULL, Boolean resetRange = true )
		{	curLineRecord().SetAllXScale( (sc == NULL ? X_Scale() : sc), resetRange );
			SetXScale( sc, resetRange );
			nx_sc = same_scale;
			Resize();
		};
	void	SetNoXScale()
		{	curLineRecord().SetAllXScale( NULL );
			nx_sc = no_scale;
			Resize();
		};
	void	SetMultXScale()
		{	curLineRecord().SetAllXScale( NULL );
			nx_sc = multiple_scale;
			Resize();
		};
		
	void	InvertAllXScale()		{	ReverseX();		if (nx_sc != same_scale)	curLineRecord().InvertAllXScale();	};
	void	InvertAllYScale()		{	ReverseY();		if (ny_sc != same_scale)	curLineRecord().InvertAllYScale();	};
		
	void	SetSameYScale( const plotYScale* sc = NULL, Boolean resetRange = true )
		{	curLineRecord().SetAllYScale( (sc == NULL ? Y_Scale() : sc), resetRange );
			SetYScale( sc, resetRange );
			ny_sc = same_scale;
			Resize();
		};
	void	SetNoYScale()
		{	curLineRecord().SetAllYScale( NULL );
			ny_sc = no_scale;
			Resize();
		};
	void	SetMultYScale()
		{	curLineRecord().SetAllYScale( NULL );
			ny_sc = multiple_scale;
			Resize();
		};
		
	void	SetSize( long w, long h )
		{	fullWidth		= w;
			fullHeight		= h;
			Resize();
		};
	void	Resize()
		{	leftMargin 		= leftMarginDefault + yscale_step * ( ny_sc == no_scale ? 0 : ( ny_sc == same_scale ? 1 : curLineRecord().size()));
			rightMargin 	= rightMarginDefault;
			topMargin 		= topMarginDefault;
			bottomMargin 	= bottomMarginDefault + xscale_step * ( nx_sc == no_scale ? 0 : ( nx_sc == same_scale ? 1 : curLineRecord().size()));;
			drawingWidth 	= fullWidth - leftMargin - rightMargin;
			drawingHeight 	= fullHeight - topMargin - bottomMargin;
			
			SetScaleSize( leftMargin, drawingWidth, topMargin, drawingHeight );
			SetAllSizeToGlobalSize();
		};

	virtual	void	SetDrawer( drawer* draw )		{	itsDrawer = draw;	};
	virtual	void	Draw();
	
	virtual	void	AddBorder( line_type* t = NULL )
		{	std::string s("border");	curLineRecord().AppendSimpleLine( new rectangleLine( minX, minY, maxX, maxY, t ), s );	};
		
	virtual	void	DrawBorder()
	{	itsDrawer->moveto( X_Scale()->left, Y_Scale()->left );
		itsDrawer->lineto( X_Scale()->left, Y_Scale()->left + Y_Scale()->width );
		itsDrawer->lineto( X_Scale()->left + X_Scale()->width, Y_Scale()->left + Y_Scale()->width );
		itsDrawer->lineto( X_Scale()->left + X_Scale()->width, Y_Scale()->left );
		itsDrawer->lineto( X_Scale()->left, Y_Scale()->left );
	};
	virtual	void	DrawCaption()
		{	itsDrawer->drawText( caption.c_str(), X_Scale()->left + X_Scale()->width, 5, topRightCorner );	};
	virtual	void	DrawXTitle( double x, double y, textPosition posCode )
		{	itsDrawer->drawText( xTitle.c_str(), x, y, posCode );	};
	virtual	void	DrawYTitle( double x, double y, textPosition posCode )
		{	itsDrawer->drawText( yTitle.c_str(), x, y, posCode );	};
		
		
private:
	plotXScale*	next_x_scale;
	plotYScale*	next_y_scale;
	string		caption_unit;

	void	ClearNextScales()
		{	next_x_scale = NULL;
			next_y_scale = NULL;
		};
		
	void	AddPolyLine( polyLine* l, const std::string& name, line_type* t )
		{	curLineRecord().AppendSimpleLine( l, name, t, next_x_scale, next_y_scale );		//	add line with its favourite scales
			
				//	for current drawing... Un peu alambiqu� tout ca !!!
		//	if (!next_x_scale)
					SetSameXScale();				//	if no special drawing, assume (by default) same scales
		//	if (!next_y_scale)
					SetSameYScale();
			
			ClearNextScales();
			
				//	global min & max
			RefreshScales();
		};
public:
	void	SetNextScales( plotXScale *x_sc, plotYScale *y_sc )
		{	next_x_scale = x_sc;			//	will use "x_sc" for private and drawing scales of new line, but nothing for the plotRecord
			next_y_scale = y_sc;
		};

	void	RefreshScales()
		{	scaler::RefreshScales();
			ostringstream s;	s << "min = " << minY << " " << caption_unit << "; max = " << maxY << " " << caption_unit;
			SetCaption( s.str() );
		};
	void	AddSubLine( polyLine* l )
	{	curLineRecord().AppendSubLine( l );
		SetSameXScale();
		SetSameYScale();
	};
	
	polyLineList*	GetLineList( size_t i )
		{	return	curLineRecord().GetLineList( i );	}
	size_t			size()
		{	return	curLineRecord().size();	}
	
	void	AddCurve( const double_vector& xx, const double_vector& yy, std::string name, line_type* t = NULL, char* unit = "" )
	{	polyLine* newLine = new polyLine( xx, yy, t );
		caption_unit = unit;
		AddPolyLine( newLine, name, t );
	};
	
//	void	AddCurve( MyMath::simplefunc* xf, MyMath::simplefunc* yf, double st, double et, line_type* t = NULL, char* unit = "" )
//	{	polyFuncLine* newLine = new polyFuncLine( xf, yf, st, et, t );
//		AddPolyLine( newLine, unit, t );
//	};


	void	AddCurve( const double_vector& xx, const double_vector& yy, const std::string& name, MyMath::simplefunc* yf, line_type* t = NULL, char* unit = "" )
	{	MyMath::lin_interpol_y_cyclicfunc* cyclicfunc = (dynamic_cast <MyMath::lin_interpol_y_cyclicfunc*> (yf));
		if ( cyclicfunc != NULL)		//	check before lin_interpolfunc !!!
		{	MyMath::double_midpoints_array ex( xx );						//	m-1 points, [1, m]
			size_t m = ex.length() + 1;										//	m initial points
			size_t n = 3 * m - 2;											//	3m-2 points
			double_vector xx_( n );
			double_vector yy_( n );
			size_t k=1;
			for (size_t i=1; k<=n && i<=m; i++)
			{	double	y1= yy[i];
				xx_[k] = xx[i];
				yy_[k++] = y1;
				double	t0;
				if (i==m || cyclicfunc->Continuous( i, t0 ))	{}
				else
				{	Boolean	yafirst = ( abs( y1 - cyclicfunc->ya ) < abs( y1 - cyclicfunc->yb ) );
					xx_[k] = t0;		yy_[k++] = ( yafirst ? cyclicfunc->ya : cyclicfunc->yb );
					xx_[k] = t0;		yy_[k++] = ( yafirst ? cyclicfunc->yb : cyclicfunc->ya );
				}
			}
			k--;
			xx_.resize_but_keep(k);	yy_.resize_but_keep(k);
			AddCurve( xx_, yy_, name, t, unit );
			return;
		};
		MyMath::lin_interpolfunc* linfunc = (dynamic_cast <MyMath::lin_interpolfunc*> (yf));
		if ( yf == NULL || linfunc != NULL)
		{	AddCurve( xx, yy, name, t, unit );
			return;
		}
		MyMath::stair_start_interpolfunc* s_stairfunc = (dynamic_cast <MyMath::stair_start_interpolfunc*> (yf));
		if ( s_stairfunc != NULL)
		{	size_t n = 2 * xx.length() - 1;
			double_vector xx_( n );
			double_vector yy_( n );
			for (size_t k=1; k<=n; k++)
			{	xx_[k] = xx[1 + k/2];		//	x[1], x[2], x[2], x[3], ...
				yy_[k] = yy[1 + (k-1)/2];	//	y[1], y[1], y[2], y[2], ...
			}
			AddCurve( xx_, yy_, name, t, unit );
			return;
		}
		MyMath::stair_end_interpolfunc* e_stairfunc = (dynamic_cast <MyMath::stair_end_interpolfunc*> (yf));
		if ( e_stairfunc != NULL)
		{	size_t n = 2 * xx.length() - 1;
			double_vector xx_( n );
			double_vector yy_( n );
			for (size_t k=1; k<=n; k++)
			{	xx_[k] = xx[1 + (k-1)/2];	//	x[1], x[1], x[2], x[2], ...
				yy_[k] = yy[1 + k/2];		//	y[1], y[2], y[2], y[3], ...
			}
			AddCurve( xx_, yy_, name, t, unit );
			return;
		}
		MyMath::stair_interpolfunc* stairfunc = (dynamic_cast <MyMath::stair_interpolfunc*> (yf));
		if ( stairfunc != NULL)
		{	MyMath::double_extra_midpoints_array ex( xx, false );				//	m+1 points, [0, m]
			size_t n = 2 * ex.length() - 2;										//	2m points
			double_vector xx_( n );
			double_vector yy_( n );
			for (size_t k=1; k<=n; k++)
			{	xx_[k] = ex[k/2];
				yy_[k] = yy[1 + (k-1)/2];
			}
			AddCurve( xx_, yy_, name, t, unit );
			return;
		}
		polyFuncLine* newLine = new polyFuncLine( xx, yy, yf, t );
		caption_unit = unit;
		AddPolyLine( newLine, name, t );
	};

};



class	plotRecord1D: public plotRecord {
public:
	plotRecord1D() : plotRecord()	{};
	plotRecord1D( const double_vector& xx, const double_vector& yy, std::string& name, line_type* t = NULL, char* unit = "" )
		:plotRecord()
		{	AddCurve( xx, yy, name, t, unit );	};
};




class	ContourGrid {
public:
	double		maxV, minV;
	BitTable	hEdges;
	BitTable	vEdges;
	double		minDx, minDy;
	size_t		nx, ny;
	
	const double_vector0&	x;
	const double_vector0&	y;
	const double_matrix0&	value;
	
	ContourGrid( const double_vector0& xx, const double_vector0& yy, const double_matrix0& zz )
		: hEdges( xx.length()-1, yy.length() ), vEdges( xx.length(), yy.length()-1 ),
			nx(xx.length()), ny(yy.length()), x(xx), y(yy), value(zz)
		{	maxV = value.max();		minV = value.min();
			minDx = x.min_step();	minDy = y.min_step();
		};
	~ContourGrid()	{};

	Contour*	MakeContour( double v );
	Boolean		EdgeIsAlmostEqual( int i, int j, double v );
	Boolean		isNodeOnEdge( ContourNode* n, int i, int j, double v );
	
private:
//	double**		value;
	
	Boolean	bad_float( double )			{	return false;	};
	Boolean	checkContourInside( double c, double v0, double v1 )
		{	if ( bad_float( v0 ) )						return	false;
			if ( bad_float( v1 ) ) 						return	false;
			if ( (v0 - c)*(v1 - c) > 0 )				return	false;
			if ( (v0 - c) == 0  &&  (v1 - c) >= 0 )		return	false;		//	0 est 'suppose' strictement positif
			if ( (v1 - c) == 0  &&  (v0 - c) >= 0 )		return	false;		//	0 est 'suppose' strictement positif
			return true;
		};
	
	void	next( int& i, int& j );					//	retourne le couple (i,j) suivant
	Boolean nextBoundsFirst( int& i, int& j );		//	... idem mais en restant sur le bord
	
	
	void			CheckEdgesOfBox( int i, int j, Contour* ctr, Boolean onB = false );
//	void			CheckEdgesOfNextBox( ContourNode* node, int i, int j, Contour* ctr );
	void			CheckEdgesOfNextBoxes( ContourNode* node, int i, int j, Contour* ctr );
	ContourNode*	LoopOverBox( int i, int j, Contour* ctr, Boolean onB = false );
	ContourNode*	CheckEdgeRightOf( int i, int j, Contour* ctr );
	ContourNode*	CheckEdgeDownOf( int i, int j, Contour* ctr );

};


class	plotRecord2D: public plotRecord {
private:
	void	MakeCGrid( const a_double_vector1& xx, const a_double_vector1& yy, const a_double_matrix1& zz,
				double xx0, double xx1, double yy0, double yy1, double unitConv );
				
	double		minV, maxV;
	const char*	unit;
	
	ContourGrid*	cGrid;
	double_vector0	x;
	double_vector0	y;
	double_matrix0	z;

	plotXScale	zScale;

public:
	plotRecord2D( const a_double_vector1& xx, const a_double_vector1& yy, const a_double_matrix1& zz, line_type* t = NULL,
		const char* u = "", double unitConv = 1 );
	plotRecord2D( const a_double_vector1& xx, const a_double_vector1& yy, const a_double_matrix1& zz,
		double Xpmin, double Xpmax, double Ypmin, double Ypmax, line_type* t = NULL, const char* u = "", double unitConv = 1 );
	~plotRecord2D()		{	delete cGrid;	};
	
	void	GetMinAndMax()			{	minV = z.min();	maxV = z.max();	};
	void	DefaultContour()		{	zScale.SetRange( minV, maxV );	zScale.DefaultValueScale( minV, maxV );	};
	
	void	PlotContours( int nmaxcont, line_type* t );
/*	void	AddContourFrame( long iFrame, const double_vector& xx, const double_vector& yy, const double_matrix& zz, int nmaxcont, line_type* t,  double unitConv = 1 )
		{	MakeCGrid( xx, yy, zz, xx[1], xx[xx.length()], yy[1], yy[yy.length()], unitConv );
			SetFrame( iFrame );
			PlotContours( nmaxcont, t );
		};
*/
};


#endif


