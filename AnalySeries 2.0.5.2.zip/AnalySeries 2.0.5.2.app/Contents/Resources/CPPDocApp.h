// =================================================================================
//	CPPDocApp.h	 					�1996-1998 Metrowerks Inc. All rights reserved.
// =================================================================================

#pragma once

#include <LDocApplication.h>
#include <LClipboard.h>

#include "CMyStdDialogs.h"
#include "inso.h"
#include "CGroupTable.h"


const ResIDT	rPPob_Preferences				= 1090;
const ResIDT	decimal_Popup					= 3;



class CPrefs {
public:
	Boolean	decimalPoint;		//	true = point, false = comma
	
	CPrefs():decimalPoint(true) {};
};

class CPreferenceDialog : public CMyStdDialog {
public:
	enum { class_ID = 'PreD' };
	
	CPreferenceDialog( LStream *inStream )	: CMyStdDialog( inStream )	{};
	~CPreferenceDialog()		{};

	void	SetupPrefDialog( const CPrefs& p )
	{	SetPopupValue( decimal_Popup, (p.decimalPoint ? 1 : 2 ) );
	};
	void	GetPrefDialog( CPrefs& p )
	{	switch (GetPopupValue( decimal_Popup ))
		{	case 1:	p.decimalPoint = true;	break;
			case 2:	p.decimalPoint = false;	break;
		}
	};
	
protected:
	virtual	SInt16	rPPob()	{	return	rPPob_Preferences;	};	
};




class CClipboardWindow : public LWindow {
public:
	enum { class_ID = 'CLwd' };
	CClipboardWindow( LStream* inStream ) : LWindow( inStream )	{};
	
	virtual void	ClickInGoAway( const EventRecord &inMacEvent )
		{	if (::TrackGoAway(mMacWindowP, inMacEvent.where))	Hide();
		};
		
//protected:
//	virtual	SInt16	rPPob()	{	return	rPPob_ClipboardWindow;	};

};

class CMyClipboard : public LClipboard {
public:
//	int 			nb_count;
	CClipboardWindow*	scrapWindow;
	CGroupTable*		localScrap;
	CMyClipboard();
	
	Boolean		CheckClipboard();
	
protected:
	virtual void	SetDataSelf( ResType inDataType, Ptr inDataPtr, SInt32 inDataLength, Boolean inReset );
	virtual SInt32	GetDataSelf( ResType inData, Handle ioDataH );
	virtual void	ImportSelf();
	virtual void	ExportSelf();
	
//	virtual void	ExecuteSelf( MessageT inMessage, void* ioParam );
	
private:
	void			EmptyScrap();
	STableItemPtr	FirstItem();
	void			Translate();
};


class CWindowMenu	{
public:

	static	CommandT	GetLastWindowMenuCommand( CommandT aCmd, SInt16& outItem );
	static	void		InsertWorksheetWindowMenu( LWindow* win );
	static	void		InsertDrawWindowMenu( LWindow* win );
	static	void		RemoveWindowMenuBetweenCmd( LWindow* win, CommandT fromCmd, CommandT toCmd );
	static	void		InsertWindowMenu( LWindow* win, CommandT aCmd, SInt16 afterItem );
	static	WindowPtr	FindSameNameWindow( LWindow* win );
};

class CPPDocApp : public LDocApplication {
public:

//	static CalcAstro_BER78	ber78;
//	static CalcAstro_LA90	la90;
//	static CalcAstro_LA04	la04;
	static CalculInso		inso;
	CPrefs					prefs;
	
	EventModifiers			keyModifiers;
	
	CPPDocApp()			{	RegisterSomeClasses();	AddAttachment( new CMyClipboard );	};
	virtual	~CPPDocApp();
	
	virtual void	ClickMenuBar( const EventRecord&	inMacEvent );
	virtual Boolean	ObeyCommand( CommandT inCommand, void *ioParam );
	virtual void	FindCommandStatus(
								CommandT			inCommand,
								Boolean				&outEnabled,
								Boolean				&outUsesMark,
								UInt16				&outMark,
								Str255				outName);

	
protected:
	virtual void			StartUp();
	virtual void			OpenDocument( FSSpec *inMacFSSpec );
	virtual LModelObject *	MakeNewDocument();
	virtual void			ChooseDocument();
	virtual void			PrintDocument( FSSpec *inMacFSSpec );
	virtual void			ShowAboutBox();
	virtual void			DoPreferences();

	void			SetPrefs();
	void			ReadPrefs();
	
	void	RegisterSomeClasses();
};
