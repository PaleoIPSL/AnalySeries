

#pragma	once

#include <sstream>
#include <LDialogBox.h>
#include <LCommander.h>

#include <LEditText.h>
#include <LStaticText.h>
#include <LPushButton.h>
#include <LPopupButton.h>
#include <LCaption.h>
#include <LCheckBox.h>
#include <LRadioButton.h>
#include <LTextEditView.h>
#include <LScrollerView.h>
#include <LLittleArrows.h>
#include <LSlider.h>
#include <UReanimator.h>

#include "MyPString.h"
#include "CDynamicPaneTable.h"

//class	LCaption;
//class	LStaticText;
//class	LTextEditView;


#include <UModalDialogs.h>



//	CMyStdDialog


#define	DefineGetField( classname, paneID )			{	\
	classname*	theText = dynamic_cast <classname*> (FindPaneByID( paneID ));	\
	ThrowIfNil_ (theText);		\
	return	theText;			\
}
//#define	DefineGetField( classname, paneID )		{	return GetField<classname>(this,paneID);	}



//class	CDynamicPaneTable;

class CMyStdDialog : public LDialogBox {
private:
	SInt16	itsPPob;
public:
	enum { class_ID = 'StdD' };
	
	CMyStdDialog( LStream *inStream )	: LDialogBox( inStream ), itsPPob(0)	{};
	~CMyStdDialog()	{};

	virtual void				FindCommandStatus( CommandT inCommand,
									Boolean &outEnabled, Boolean&,
									UInt16&, Str255 )
			{	outEnabled = false;
				if ( inCommand == cmd_About )	outEnabled = true;
			}

	virtual Boolean	ValidDialog()	{	return true;	};
	virtual Boolean	EndDialog()
			{	if (ValidDialog())	{	SaveDialog();	return true;	}
				else return false;
			};
	virtual void	SetupDialog()	{};		//	called by FinishCreateSelf()
	virtual void	SaveDialog()	{};
	
	void	SetPPob( SInt16 ppob )	{	itsPPob = ppob;	};

	
	double	GetDValue( PaneIDT paneID )
		{	Boolean	isOk = true;	return	GetDValue( paneID, isOk );	};
	
	double	GetDValue( PaneIDT paneID, Boolean& io_isOk )
		{	return	GetDValue( GetEditText( paneID ), io_isOk );		};

	void	SetDValue( PaneIDT paneID, double inValue )
		{	SetDValue( GetEditText( paneID ), inValue );	};

	SInt32	GetPopupValue( PaneIDT paneID )						//	with LPopupButton panes
		{ 	return GetPopup( paneID )->GetValue();	}
	void	SetPopupValue( PaneIDT paneID, SInt32 inValue )		//	with LPopupButton panes
		{ 	GetPopup( paneID )->SetValue(inValue);	}
		
	Boolean	GetCheckBoxValue( PaneIDT paneID )
		{ 	return GetCheckBox( paneID )->GetValue();	}
	void	SetCheckBoxValue( PaneIDT paneID, Boolean inValue )
		{ 	GetCheckBox( paneID )->SetValue(inValue);	}
		
	Boolean	GetRadioValue( PaneIDT paneID )
		{ 	return GetRadioButton( paneID )->GetValue();	}
	void	SetRadioValue( PaneIDT paneID, Boolean inValue )
		{ 	GetRadioButton( paneID )->SetValue(inValue);	}
		
	long	GetSliderValue( PaneIDT paneID )
		{ 	return GetSlider( paneID )->GetValue();	}
	void	SetSliderValue( PaneIDT paneID, long inValue )
		{ 	GetSlider( paneID )->SetValue(inValue);	}
		
	LEditText*		GetEditText( PaneIDT paneID )		DefineGetField( LEditText, paneID );
	LStaticText*	GetStaticText( PaneIDT paneID )		DefineGetField( LStaticText, paneID );
	LPushButton*	GetPushButton( PaneIDT paneID )		DefineGetField( LPushButton, paneID );
	LPopupButton*	GetPopup( PaneIDT paneID )			DefineGetField( LPopupButton, paneID );
	LCaption*		GetCaption( PaneIDT paneID )		DefineGetField( LCaption, paneID );
	LCheckBox*		GetCheckBox( PaneIDT paneID )		DefineGetField( LCheckBox, paneID );
	LRadioButton*	GetRadioButton( PaneIDT paneID )	DefineGetField( LRadioButton, paneID );
	LTextEditView*	GetTextEditView( PaneIDT paneID )	DefineGetField( LTextEditView, paneID );
	LScrollerView*	GetScrollerView( PaneIDT paneID )	DefineGetField( LScrollerView, paneID );
	LLittleArrows*	GetLittleArrows( PaneIDT paneID )	DefineGetField( LLittleArrows, paneID );
	CDynamicPaneTable*	GetDynTable( PaneIDT paneID )	DefineGetField( CDynamicPaneTable, paneID );
	LSlider*		GetSlider( PaneIDT paneID )			DefineGetField( LSlider, paneID );

protected:
	
	virtual	SInt16	rPPob()	{	return itsPPob;	};

	virtual void	FinishCreateSelf()
	{	LDialogBox::FinishCreateSelf();
		if (rPPob() > 0)	UReanimator::LinkListenerToControls( this, this, rPPob() );
		SetupDialog();
	};
	
	double	GetDValue( LEditText *inEditText, Boolean& io_isOk )
	{	double	v = 0;
		if (io_isOk)
		{	Str255	ptxt;		inEditText->GetDescriptor(ptxt);
			char	txt[255];	TCLptocstrcpy( txt, ptxt );
		//	std::istringstream s(txt);	s >> v;
			std::istringstream s(txt);	s >> v;
			io_isOk = s.eof() && !(s.fail());
		}
		return v;
	}
	void	SetDValue( LEditText *inEditText, double inValue )
	{	std::ostringstream s;	s << inValue << '\0';
		Str255	ptxt;		TCLctopstrcpy( ptxt, s.str().c_str() );
		inEditText->SetDescriptor ( ptxt );
	}
	
};



class	StMy_DialogHandler : public StDialogHandler {
public:

	StMy_DialogHandler( ResIDT inDialogResID, LCommander* inSuper = LCommander::GetTopCommander() )
		: StDialogHandler( inDialogResID, inSuper )
		{	CMyStdDialog* theDialog = dynamic_cast<CMyStdDialog*>(GetDialog());
			theDialog->SetPPob( inDialogResID );
				//	a priori already done in CMyStdDialog::FinishCreateSelf()
				//	except if it is only a CMyStdDialog
		};

	virtual MessageT	DoMyModalDialog()
	{	CMyStdDialog* theDialog = dynamic_cast<CMyStdDialog*>(GetDialog());
		theDialog->Show();
		while ( true )
		{	MessageT	theMessage = DoDialog();
			if ( theMessage == msg_Cancel )		return	msg_Cancel;
			else if ( theMessage == msg_OK)
			{	if (theDialog->EndDialog())		return	msg_OK;		}
	}	};
	
	virtual MessageT	OkDialog()
	{	CMyStdDialog* theDialog = dynamic_cast<CMyStdDialog*>(GetDialog());
		if (theDialog->EndDialog())
				return	msg_OK;
		else	return	msg_Cancel;
	};
};





//	SimpleAlert
const PaneIDT	kOkButton						= 1;
const PaneIDT	kCancelButton					= 2;

const ResIDT	rPPob_SimpleAlert				= 1200;
const PaneIDT	kAlertText						= 2;

const ResIDT	rPPob_SimpleCancelAlert			= 1201;
const PaneIDT	kCancelAlertText				= 3;



Boolean	MakeUsFrontProcess();
//void	MySimpleAlert( const Str255 pstr, LCommander* com );
//void	MySimpleAlert( const Str255 pstr );
void	MySimpleAlert( const unsigned char* pstr, LCommander* com, ResIDT theID = rPPob_SimpleAlert );
void	MySimpleAlert( const unsigned char* pstr );



class CSimpleStdDialog : public LDialogBox, public LPeriodical {
public:
	Str255	txt;
public:
	CSimpleStdDialog( LStream *inStream ) : LDialogBox( inStream )	{};
//	CSimpleStdDialog( const Str255 pstr )		{	LString::CopyPStr( pstr, txt );	};
	CSimpleStdDialog( const unsigned char* pstr )		{	LString::CopyPStr( pstr, txt );	};

	virtual	void	SpendTime( const EventRecord& )
		{	LCommander* curTarget = LCommander::GetTarget();
			if (!curTarget)	return;
			StopIdling();
			MySimpleAlert( txt, curTarget );
			delete this;
		};
};



inline Boolean	MakeUsFrontProcess()
{	if (LCommander::GetTarget())
	{	ProcessSerialNumber curPsn;
		OSErr err = ::GetCurrentProcess( &curPsn );
		if( err ) return false;
		err = ::SetFrontProcess( &curPsn );
		if( err ) return false;
	}
	return true;
};

inline void	MySimpleAlert( const unsigned char* pstr, LCommander* com, ResIDT theID )
{	
	LCommander* tempTarget = LCommander::GetTarget();
	StDialogHandler	theHandler( theID, com );
	LWindow* theDialog = theHandler.GetDialog();
	LCaption*	theText = dynamic_cast <LCaption*> (theDialog->FindPaneByID( kAlertText ));
	theText->SetDescriptor( pstr );
	::SysBeep(1);
	while ( theHandler.DoDialog() != msg_OK ) {};
	com->SwitchTarget( tempTarget );
};


inline Boolean	MySimpleCancelAlert( const unsigned char* pstr, LCommander* com )
{	LCommander* tempTarget = com->GetTarget();
	StDialogHandler	theHandler( rPPob_SimpleCancelAlert, com );
	LWindow* theDialog = theHandler.GetDialog();
	LCaption*	theText = dynamic_cast <LCaption*> (theDialog->FindPaneByID( kCancelAlertText ));
	theText->SetDescriptor( pstr );
	::SysBeep(1);
	MessageT msg = msg_Nothing;
	while ( msg != msg_OK && msg != msg_Cancel ) 	{	msg = theHandler.DoDialog();	};
	com->SwitchTarget( tempTarget );
	return	(msg == msg_OK);
};


inline void	MySimpleAlert( const unsigned char* pstr )
{	MySimpleAlert( pstr, LCommander::GetTopCommander() );
};

inline Boolean	MySimpleCancelAlert( const unsigned char* pstr )
{	return	MySimpleCancelAlert( pstr, LCommander::GetTopCommander() );
};
