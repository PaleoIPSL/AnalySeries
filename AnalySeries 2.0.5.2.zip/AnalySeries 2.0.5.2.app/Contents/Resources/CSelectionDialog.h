
#pragma once

#include "TablesConstants.h"
//#include "CTextDocument.h"
#include "CGroupTable.h"


//	CFitErrorDialog



const ResIDT	rPPob_SelectionWindow		= 1041;
const PaneIDT	kSelectionView				= 2;


class	TestItemFunction {
protected:
	virtual Boolean	func( const STableItem* ) const = 0;
public:
	virtual Boolean	operator()( const STableItem* x )	{	return func(x);	};
    virtual ~TestItemFunction()	{};
};


class CSelectionDialog : public CMyStdDialog {
private:
	CGroupTable*	originalTable;
	
	int max0, max1, max2, max3;
	Boolean homogeneous;
	
	TestItemFunction*	test;
	
	int		currentSelection()
	{	CGroupTable*	tempTable = dynamic_cast<CGroupTable*>(FindPaneByID( kSelectionView ));
		return	tempTable->GetCurrentSelection( max0, max1, max2, max3, homogeneous, false );
	};

public:
	enum { class_ID = 'SelD' };
	CSelectionDialog( LStream *inStream )	: CMyStdDialog( inStream )	{	originalTable = nil;	};
	~CSelectionDialog()		{};
	
	static	LWindow*	GetMyWindow( LView* v )
		{	LWindow*	w = dynamic_cast<LWindow*>(v);
			while (v->GetSuperView() != nil && w == nil)	{	v = v->GetSuperView();	w = dynamic_cast<LWindow*>(v);	}
			if (w == nil )	throw	GenericError("Problem in CSelectionDialog");
			return w;
		};
	void	SetupDialog()
		{	CGroupTable*	tempTable = dynamic_cast<CGroupTable*>(FindPaneByID( kSelectionView ));
			LCommander* com = GetSuperCommander();
			while ( ((dynamic_cast<CGroupTable*>(com)) == nil) && (com != sTopCommander) )
				com = com->GetSuperCommander();
			if (com == sTopCommander )	throw	GenericError("Problem in SelectionDialog");
			originalTable = (dynamic_cast<CGroupTable*>(com));
			originalTable->CopySelectionAt( tempTable, 0, false, STableItem::copy_some, true );
		};
		
	void	SetupSelectionDialog( int m0, int m1, int m2, int m3, Boolean h, TestItemFunction* t )
		{	max0 = m0;
			max1 = m1;
			max2 = m2;
			max3 = m3;
			homogeneous = h;
			test = t;
		};
	STableItem*	AddSelectionToTableItem( STableItem* item = nil )
		{	CGroupTable*	tempTable = dynamic_cast<CGroupTable*>(FindPaneByID( kSelectionView ));
			STableCell	theCell( 0, 1 );
			STableItem* firstSelectedItem = nil; 
			while ( tempTable->GetNextSelectedCell( theCell ) )
			{	STableCell	theWideOpenCell( tempTable->GetWideOpenIndex( theCell.row ), 1 );
				STableItem* selectedItem = nil; 
				ThrowIfNot_( originalTable->GetItemFromWOCell( theWideOpenCell, selectedItem ) );
				ThrowIfNil_(selectedItem);
				if (item)	item->AddToTable( selectedItem );
				else		item = selectedItem;
				if (firstSelectedItem == nil)	firstSelectedItem = selectedItem;
			}
			return	firstSelectedItem;
		};
	virtual Boolean	ValidDialog()
		{	Boolean	ok = (currentSelection() > 0);
			if (!ok)	return false;
			CGroupTable*	tempTable = dynamic_cast<CGroupTable*>(FindPaneByID( kSelectionView ));
			STableCell		theCell( 0, 1 );
			while ( tempTable->GetNextSelectedCell( theCell ) && ok )
			{	STableCell	theWideOpenCell( tempTable->GetWideOpenIndex( theCell.row ), 1 );
				STableItem* selectedItem = nil; 
				ThrowIfNot_( originalTable->GetItemFromWOCell( theWideOpenCell, selectedItem ) );
				ThrowIfNil_(selectedItem);
				ok = (*test)( selectedItem );
			}
			return ok;
		};
	
protected:
	virtual	SInt16	rPPob()	{	return	rPPob_SelectionWindow;	};
};