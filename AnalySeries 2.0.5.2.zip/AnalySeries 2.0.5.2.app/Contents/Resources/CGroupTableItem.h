


#pragma once


#include	<Quicktime/Movies.h>

#include	"myMath.h"
#include	"plotRecord.h"
#include	"MyPString.h"
//#include 	"CDrawingView.h"
#include	"myStdCFile.h"
#include	"myNumTxtStdStream.h"

#include	<LFileStream.h>
#include	<LString.h>
#include	<LPane.h>



class	CColumnDataDialog;
class	STableItem;
class	LMoovCommander;
class	myStdCFileStream;

typedef	STableItem*	STableItemPtr;
class	STableItem0D;
class	STableItem1D;
class	STableItem2D;
class	STableItem3D;



const DataIDT	kUndefItemType		= 'Undf';
const DataIDT	kGroupItemType		= 'Grup';
const DataIDT	kNumberItemType		= 'Ser0';		//	0-dimensional
const DataIDT	kSeriesItemType		= 'Ser1';		//	1-dimensional
const DataIDT	kMapItemType		= 'Ser2';		//	2-dimensional
const DataIDT	kMovieItemType		= 'Ser3';		//	3-dimensional

const ResIDT	kGroupTextTraits	= 132;
const ResIDT	kDataTextTraits		= 131;

const ResIDT	kSeriesIconID		= 1000;
const ResIDT 	kGroupIconID		= 1001;
const ResIDT	kMovieIconID		= 1002;
const ResIDT	kMapIconID			= 1003;
const ResIDT	kNumberIconID		= 1004;
const ResIDT	kUndefIconID		= 1005;
const ResIDT	kMultSeriesIconID	= 1006;


class txt_string : public std::string	 {
public:
	txt_string()	{};
	txt_string( const char* s )			{	std::string::operator =( s ); 	};
	txt_string( const std::string& s )	{	std::string::operator =( s ); 	};
	txt_string( const LStr255& s )		{	std::string::operator =( std::string( (char*)&(s[1]), (unsigned long)(s.Length()) ) );		};
	txt_string( const Str255 s )		{	std::string::operator =( std::string( (char*)&(s[1]), (unsigned long)(s[0]) ) );			};
	txt_string( const double v )		{	ostringstream s;	s << v;	  std::string::operator =( s.str() );							};

	txt_string&	operator =( const char* s )			{	std::string::operator =( s ); return (*this);	};
	txt_string&	operator =( const std::string& s )	{	std::string::operator =( s ); return (*this);	};
	txt_string&	operator =( const LStr255& s )		{	std::string::operator =( std::string( (char*)&(s[1]), (unsigned long)(s.Length()) ) );	return (*this);	};
	txt_string&	operator =( const Str255 s )		{	std::string::operator =( std::string( (char*)&(s[1]), (unsigned long)(s[0]) ) );		return (*this);	};
	txt_string&	operator =( const double v )		{	ostringstream s;	s << v;	  std::string::operator =( s.str() );						return (*this);	};
};


class binaryStream : public LFileStream {
private:
	bool	firstCall;			//	a trick to read old (PPC) file formats... look if "Blocks" give "consistent numbers".
	bool	inBlock;
	UInt32	code;
private:
	void	ReadDoubleBlock( double* p, size_t n )
	{	if (firstCall)
		{	if (code == 0)				CheckEndian( n );		//	set inBlock to true or false...
			else if (code == 'ans0')		inBlock = true;
			else if (code == 'ans1')		inBlock = false;
			else						inBlock = false;		//	unused, just in case...
			firstCall = false;
		}
		ReadDbleBlock( inBlock, p, n );
	}
	void	CheckEndian( size_t n )			//	which format is more likely ???
	{	SInt32	mark = GetMarker();
		double_vector* v0 = new double_vector(n);	ReadDbleBlock( true, v0->firstPtr(), n );
		SetMarker( mark, streamFrom_Start );
		double_vector* v1 = new double_vector(n);	ReadDbleBlock( false, v1->firstPtr(), n );
		SetMarker( mark, streamFrom_Start );
		double	f0 = v0->sum_abs();			//	somme des valeurs absolues > 1e+100 ??
		double	f1 = v1->sum_abs();
		if ((f0 > 1e+50)&&(f0 > f1))		inBlock = false;
		else if ((f1 > 1e+50)&&(f1 > f0))	inBlock = true;
		else
		{	double	g0 = std::fabs(std::log10(f0));
			double	g1 = std::fabs(std::log10(f1));
			if ((g0 > 100)&&(g0 > g1))		inBlock = false;
			else if ((g1 > 100)&&(g1 >g0))	inBlock = true;
			else inBlock = true;								//	par d�faut (= format d'�criture...)
		}
	}
	void	ReadDbleBlock( bool inBlock, double* p, size_t n )
	{	if (inBlock)	ReadBlock( p, n*sizeof(double) );
		else			for (double* q = p; q < p+n; q++)	(*this) >> *q;
	}
	void	WriteDoubleBlock( double* p, size_t n )
	{	if (code == 0)		WriteBlock( p, n * sizeof(double) );		//	unused, old version
		else if (code == 'ans1')
			for (double* q = p; q < p+n; q++)	(*this) << *q;			//	use the type-checked io routine
	};

public:

	binaryStream( const FSSpec& inFileSpec, UInt32 c = 0 ) : LFileStream(inFileSpec)	{	firstCall = true;	code = c;	};
	STableItemPtr	ReadItem();
	void			WriteItem( STableItemPtr theItem );
	void			setCode( UInt32 c )		{	code = c;	};
	bool			hasCode()				{	return (code > 0);	};
							
	std::string		ReadString()
		{	size_t	n;	(*this) >> n;	char* s = new char[n];
			ReadBlock(s, n);
			std::string	txt(s,n);		delete s;
			return	txt;
		};
	void	WriteString( const std::string& s )
		{	(*this) << s.length();		WriteBlock( s.c_str(), s.length() );	};
		
	double_vector*	ReadVector()
		{	size_t	n;	(*this) >> n;	double_vector* v = new double_vector(n);
			//ReadBlock(v->firstPtr(), v->size()*sizeof(double));
			ReadDoubleBlock( v->firstPtr(), v->size() );
			return	v;
		};
	void	WriteVector( const double_vector& v )
		{	(*this) << v.length();
			//WriteBlock( v.firstPtr(), v.length()*sizeof(double) );	
			WriteDoubleBlock( v.firstPtr(), v.length() );	
		};

	double_matrix*	ReadMatrix()
		{	size_t	n1, n2;		(*this) >> n1 >> n2;	double_matrix* v = new double_matrix(n1,n2);
			//ReadBlock(v->firstPtr(), v->size()*sizeof(double));
			ReadDoubleBlock( v->firstPtr(), v->size() );
			return	v;
		};
	void	WriteMatrix( const double_matrix& v )
		{	(*this) << v.dim1() << v.dim2();
			//WriteBlock( v.firstPtr(), v.length()*sizeof(double) );	
			WriteDoubleBlock( v.firstPtr(), v.length() );	
		};
		
	double_3tensor*	ReadTensor()
		{	size_t	n1, n2, n3;		(*this) >> n1 >> n2 >> n3;	double_3tensor* v = new double_3tensor(n1,n2,n3);
			//ReadBlock(v->firstPtr(), v->size()*sizeof(double));
			ReadDoubleBlock( v->firstPtr(), v->size() );
			return	v;
		};
	void	WriteTensor( const double_3tensor& v )
		{	(*this) << v.dim1() << v.dim2() << v.dim3();
			//WriteBlock( v.firstPtr(), v.length()*sizeof(double) );	
			WriteDoubleBlock( v.firstPtr(), v.length() );	
		};
		
	double*	ReadDouble()					{	double* v = new double;		(*this) >> *v;		return	v;		};
	void	WriteDouble( const double* v )	{	(*this) << *v;	};
		
	DataIDT	ReadCode()						{	DataIDT	c;		(*this) >> c;		return	c;		};
	void	WriteCode( DataIDT	c )			{	(*this) << c;										};
	
	MyMath::simplefunc*		ReadFunction( STableItem1D* currentItem );
	void	WriteFunction( const MyMath::simplefunc* f );
};

class Axis {				//	a vector with a name
private:
	txt_string		axis_name;
	double_vector_ptr	x_ptr;
public:
	double_vector*	x;
	
	const std::string&	sName()	const	{	return	(const std::string&)axis_name;		};
	LStr255				Name()	const	{	return	axis_name.c_str();					};
	
	void	SetName( const LStr255& txt )	{	axis_name = txt;	};
	
	Axis( double_vector* xx, const LStr255& aName ):x_ptr(x)		{	x = xx;		axis_name = aName;	}
	Axis( double_vector* xx, const std::string& aName ):x_ptr(x)	{	x = xx;		axis_name = aName;	}
	
	typedef enum { copy_all, move_to, copy_some }	copyOption;
		
	Axis( Axis* axisPtr, copyOption duplicate ):x_ptr(x)
		{	if (duplicate == copy_all)			x = new double_vector( *(axisPtr->x) );		//	make a full copy
			else if (duplicate == move_to)		{	x = axisPtr->x;	axisPtr->x = NULL;	}	//	transfer ownership : old one is an empty shell to be deleted
			else				{	x = axisPtr->x;	 x_ptr.change_ownership( false );	}	//	empty shell : old one keeps ownership
			axis_name = axisPtr->axis_name;
		}
	~Axis()		{	/*delete x;*/	}		//	delete performed by x_ptr
		
	Axis( binaryStream& iStream ):x_ptr(x)			{	axis_name = iStream.ReadString();	x = iStream.ReadVector();	};
	virtual void	write( binaryStream& oStream )	{	oStream.WriteString( axis_name );	oStream.WriteVector( *x );	};
};






class STableItemArray {
private:
	STableItemPtr*		itemTable;			//	when opening multiple data => more than one item on output
	size_t				itemTableSize;

public:
	STableItemArray()				{	itemTable = NULL;	itemTableSize = 0;					};
	STableItemArray( size_t n )		{	itemTable = NULL;	itemTableSize = 0;	InitTable(n);	};
	virtual ~STableItemArray()				{	DeleteTable();	};
	
	size_t		TableSize()	const	{	return (itemTable ? itemTableSize : 0);		};
		
	STableItem*		item_( size_t i ) const			//	de 1 � n
		{	return	( (itemTable && i>=1 && i<=itemTableSize) ? itemTable[i-1] : NULL);		};
	STableItem*&	item_p( size_t i )		const
		{	return	itemTable[i-1];		};
		
	STableItem0D*	item_0D( size_t i )		const;
	STableItem1D*	item_1D( size_t i )		const;
	STableItem2D*	item_2D( size_t i )		const;
	STableItem3D*	item_3D( size_t i )		const;
	
	void	DeleteTableContent();
	
	virtual Boolean	CanDelete( STableItem* p )	{	return	(p!=NULL);	}		//	can delete all !!
	virtual void	InitTable( size_t n )
		{	//	DeleteTable();		//	DON'T CALL the virtual function !!!
			if (itemTable)	delete [] itemTable;
			itemTable = NULL;	itemTableSize = 0;
			if (n>0)
			{	itemTable = new STableItemPtr[n];
				itemTableSize = n;
				for (size_t i=0; i<itemTableSize; i++)	itemTable[i] = NULL;
			}
		};
	virtual size_t	FindInTable( const STableItem* newItem ) const
		{	bool	notfound = true;
			size_t	i = 0;
			while (i<itemTableSize && notfound)
			{	notfound = (newItem != itemTable[i]);	if (notfound) i++;	};
			if (notfound)	return 0;
			else			return i+1;
		}
	virtual void	AddToTable( STableItem*	newItem )
		{	if (FindInTable(newItem ) == 0)
			{	STableItemPtr*	temptable = new STableItemPtr[itemTableSize];
				for (size_t i=0; i<itemTableSize; i++)	temptable[i] = itemTable[i];
				InitTable( itemTableSize+1 );
				for (size_t i=0; i<itemTableSize-1; i++)	itemTable[i] = temptable[i];
				delete [] temptable;
				itemTable[itemTableSize-1] = newItem;
			}
		}
	virtual void	DeleteTable()
		{	if (itemTable)	delete [] itemTable;
			itemTable = NULL;	itemTableSize = 0;
		}
	virtual void	Copy( const STableItemArray& items );
	
	plotRecord*		MakePlotRecord1D( int startColor = 0, double extra_start = 0, double extra_end = 0 ) const;
	plotRecord*		MakePlotRecord( int = 0 ) const;
};

class STableItemAssociatedArray : public STableItemArray {
private:
	STableItem*		theItem;
public:
	STableItemAssociatedArray( STableItem* item ) : theItem( item )
		{	InitTable(1);	};
		
	virtual void	InitTable( size_t n )
		{	STableItemArray::InitTable( n );
			item_p(1) = theItem;
		};
	virtual void	DeleteTable()
		{	STableItemArray::DeleteTable();
			InitTable(1);
		}
	virtual Boolean	CanDelete( STableItem* p )	{	return	(p != theItem);	}		//	don't delete the associated one !! (infinite looping)
};


class STableItemInfo {
private:
	txt_string			mName;
	txt_string			mFileName;
	txt_string			mComment;
	txt_string			commandName;
	
	void	SetItemUsed( STableItem* item1, STableItem* item2, STableItem* item3, STableItem* item4 )
		{	if (item4)			itemUsed.InitTable(4);
			else if (item3)		itemUsed.InitTable(3);
			else if (item2)		itemUsed.InitTable(2);
			else if (item1)		itemUsed.InitTable(1);
			if (item1)			itemUsed.item_p(1) = item1;
			if (item2)			itemUsed.item_p(2) = item2;
			if (item3)			itemUsed.item_p(3) = item3;
			if (item4)			itemUsed.item_p(4) = item4;
		}
public:
	STableItemArray		itemUsed;
	
public:
	STableItemInfo()	{};
	STableItemInfo( const STableItemInfo& origin )
		{	itemUsed.Copy( origin.itemUsed );
			commandName = origin.commandName;
			mName 		= origin.mName;
			mFileName	= origin.mFileName;
			mComment	= origin.mComment;
		};
/*	STableItemInfo( const std::string& nam, const std::string& fileName, const std::string& com, const std::string& opName, const STableItemArray& items )
		: mName( nam ), mFileName( fileName ), mComment( com ), commandName( opName )
		{	itemUsed.Copy( items );
		};
	STableItemInfo( ConstStringPtr nam, ConstStringPtr fileName, const char* com, ConstStringPtr opName, const STableItemArray& items )
		: mName( nam ), mFileName( fileName ), mComment( com ), commandName( opName )
		{	itemUsed.Copy( items );
		};
*/	
	STableItemInfo( const txt_string nam, const txt_string fileName, const txt_string com, const txt_string opName, const STableItemArray& items )
		: mName( nam ), mFileName( fileName ), mComment( com ), commandName( opName )
		{	itemUsed.Copy( items );
		};

	STableItemInfo( const txt_string nam, const txt_string fileName, const txt_string com, const txt_string opName,
					STableItem* item1 = NULL, STableItem* item2 = NULL, STableItem* item3 = NULL, STableItem* item4 = NULL )
		: mName( nam ), mFileName( fileName ), mComment( com ), commandName( opName )
		{	SetItemUsed( item1, item2, item3, item4 );
		};
/*	STableItemInfo( const std::string& nam, const std::string& fileName, const std::string& com, const std::string& opName,
					STableItem* item1 = NULL, STableItem* item2 = NULL, STableItem* item3 = NULL, STableItem* item4 = NULL )
		: mName( nam ), mFileName( fileName ), mComment( com ), commandName( opName )
		{	SetItemUsed( item1, item2, item3, item4 );
		};
	STableItemInfo( const LStr255& nam, const LStr255& fileName, const char* com, const LStr255& opName,
					STableItem* item1 = NULL, STableItem* item2 = NULL, STableItem* item3 = NULL, STableItem* item4 = NULL )
		: mName( nam ), mFileName( fileName ), mComment( com ), commandName( opName )
		{	SetItemUsed( item1, item2, item3, item4 );
		};
*/		
	STableItemInfo( binaryStream& iStream )			{	mName = iStream.ReadString();	mFileName = iStream.ReadString();	mComment = iStream.ReadString();	commandName = iStream.ReadString();	};
	virtual void	write( binaryStream& oStream )	{	oStream.WriteString( mName );	oStream.WriteString( mFileName );	oStream.WriteString( mComment );	oStream.WriteString( commandName );	};
		
public:
	LStr255			Name()			const 	{	return	mName.c_str();			}
	LStr255			FileName()		const 	{	return	mFileName.c_str();		}
	LStr255			OpName()		const 	{	return	commandName.c_str();	}

	const std::string&	sName()			const 	{	return	(const std::string&)mName;		}
	const std::string&	sFileName()		const 	{	return	(const std::string&)mFileName;	}	
	const std::string&	CommentStr()	const	{	return	(const std::string&)mComment;	}

protected:

/*	std::string&	sName()		 	{	return	(std::string&)mName;		}
	std::string&	sFileName()	 	{	return	(std::string&)mFileName;	}	
	std::string&	CommentStr()	{	return	(std::string&)mComment;		}
*/	
	LStr255	RealFileName()
		{	LStr255			mRealFileName;		//	max 31 characters, without ':'
			//size_t			n = std::max( mFileName.length(), (size_t)31 );
			size_t			n = std::min( mFileName.length(), (size_t)31 );
			if (n == 0)		mRealFileName = "\pUntitled";
            else
            {	mRealFileName.Assign( mFileName.c_str(), n );
           		char* p1 = (char*)&(mRealFileName[1]);
                char* pn = p1+n;
               	for (char* p=p1; p<pn; p++)
                {    if(*p == ':' || *p == '/')		*p = '_';	}
            }
			return	mRealFileName;
		};
	
public:		
	void	SetName( const LStr255& inName )		{	mName =  inName;	};
	void	SetFileName( const LStr255& aName )		{	mFileName = aName;	};
	void	SetComment( const char* s, size_t n )	{	mComment = std::string( s, n );	};
	
};
	
class SelectionFlagItem	 {
private:
	SInt32		selectionFlag;
	
public:
	SelectionFlagItem()		{	selectionFlag = 0;	};
	
	void	Select( UInt32 maxDepth = 0 )
				{	UInt32	uFlag = (selectionFlag > 1 ? selectionFlag : 1);
					selectionFlag = (maxDepth > uFlag ? maxDepth : uFlag);
				};
	void	UnSelect()							{	selectionFlag = 0;		};
	void	InsideSelect( UInt32 depth )		{	selectionFlag = -depth;	};
	
	Boolean	IsNotSelected()		{	return	(selectionFlag == 0);	};
	Boolean	IsSelected()		{	return	(selectionFlag > 0);	};
	Boolean	IsInsideSelected()	{	return	(selectionFlag < 0);	};
	
	UInt32	SelectionDepthSize(){	return	(selectionFlag > 0 ? selectionFlag : 0);	};
	UInt32	SelectionDepth()	{	return	(selectionFlag < 0 ? -selectionFlag : 0);	};

};



class STableItem : public  STableItemInfo, public SelectionFlagItem	 {
public:		
	virtual	LStr255		DrawName()		{	return "\p";	}

	static STableItemPtr	ItemFromBinary( binaryStream& iStream );

private:	
	virtual void	init_Null()
	{	//selectionFlag = 0;
		hasMovieFile = false;
	};

protected:	
	void	init( const unsigned char* inValueName, const unsigned char* inFileName )
	{	init_Null();	SetName( inValueName );	SetFileName( inFileName );	};
	

	
public:
	virtual DataIDT	ItsType()		= 0;	//{	return	kUndefItemType;		};
	virtual short	GetIconID()		= 0;	//{	return	kUndefIconID;		};
	virtual short	GetTextTraits()	= 0;	//{	return 	kDataTextTraits;	};
	
	Boolean	IsGroup()				{	return	(ItsType()==kGroupItemType);	};
	Boolean	IsUndefined()			{	return	(ItsType()==kUndefItemType);	};
	
	virtual SInt32	DoubleSize()	{	return 	0;					};
	virtual double	Minimum()		{	return 	0;					};
	virtual double	Maximum()		{	return 	0;					};
	


private:				//	Item table
	STableItemAssociatedArray	item_Table;

public:
	const STableItemAssociatedArray&	the_item_Table()	{	return	item_Table;		};
	size_t			TableSize()				const {	return	item_Table.TableSize();		};
	void			DeleteTable()			{	item_Table.DeleteTable();			};
	void			InitTable( size_t n )	{	item_Table.InitTable( n );			};
	STableItem*		item_( size_t i )		const {	return	item_Table.item_( i );		};
	STableItem*&	item_p( size_t i )		const {	return	item_Table.item_p( i );		};
	
	STableItem0D*	item_0D( size_t i )		const {	return	item_Table.item_0D( i );	};
	STableItem1D*	item_1D( size_t i )		const {	return	item_Table.item_1D( i );	};
	STableItem2D*	item_2D( size_t i )		const {	return	item_Table.item_2D( i );	};
	STableItem3D*	item_3D( size_t i )		const {	return	item_Table.item_3D( i );	};

	void	AddToTable( STableItem*	newItem )	{	item_Table.AddToTable( newItem );	};

private:
	LStr255		mSelectionName;

private:
	LStr255	GroupName()
		{	LStr255	mGroupName = "\p";
			mGroupName += item_Table.item_(1)->FileName();
			if (TableSize() >= 2)
			{	mGroupName += ";";	mGroupName += item_Table.item_(2)->FileName();	}
			if (TableSize() >= 3)
			{	mGroupName += ";...";	}
			return	mGroupName;
		}
public:		
	ConstStringPtr	SelectionName()		const 				{	return	mSelectionName;		}
	void	SetSelectionName( const LStr255& inName )
		{	mSelectionName = ( inName[0] > 0 ? inName : GroupName() );	};


public:
	myStdCFileStream	mFile;
	
	STableItem() : item_Table(this)										{	init( "\pUntitled", "\pUntitled" );	};
	STableItem( ConstStringPtr inName ) : item_Table(this)				{	init( inName, inName );				};
	STableItem( const STableItemInfo& info ) : STableItemInfo(info), item_Table(this)
		{	init_Null();	};
	
	STableItem( binaryStream& iStream ) : STableItemInfo( iStream ), item_Table(this)	{};
	virtual void	write( binaryStream& oStream )			{	STableItemInfo::write( oStream );	};
	
	
    virtual ~STableItem()	{	item_Table.DeleteTableContent();
						item_Table.DeleteTable();
					};
				
//	typedef enum { copy_all, move_to, copy_some }	copyOption;
//	typedef Axis::copyOption	copyOption;
	typedef enum { copy_all=Axis::copy_all, move_to=Axis::move_to, copy_some=Axis::copy_some }	copyOption;

	
// copy constructor...		
	STableItem( STableItemPtr inItem, copyOption ) : STableItemInfo(*inItem), item_Table(this)
		{	init_Null();
		};
																										
	virtual STableItem*		Copy( copyOption duplicate )	= 0;	//{	return	new STableItem( this, duplicate );		}

public:		
	//	saving..
	void	Save()
		{	if (IsGroup())	return;
			if (mFile.ChooseAndOpenW( 'AnSe', 'TEXT', RealFileName()))		//(TableSize() > 1 ? GroupFileName() : FileName()) ))		//	GetGroupFileName() : GetFileName()) ))
			{	SaveIntoStream( *(mFile.itsIOStream) );
				mFile.Close( false );
			}
		};
	void	SaveInto( const FSSpec& dropDirSpec )
	{	if (IsGroup())
			mFile.CreateNewDirectory( dropDirSpec, RealFileName() );							//, GetFileName() );
		else
		{	mFile.CreateAndOpenWIntoDir( dropDirSpec, RealFileName(), 'AnSe', 'TEXT' );			//, GetFileName(), 'AnSe', 'TEXT' );
			SaveIntoStream( *(mFile.itsIOStream) );
			mFile.Close( false );
		}
	};
	virtual void	SaveIntoStream( ostream& , char  = '\n' )	{};
	virtual plotRecord* MakePlotRecord( int  = 0 )	{	return	NULL;	};
	virtual Boolean		isMovingView()		{	return	false;	};
	//virtual	void		MakeVideo( CMovieView* )	{};
	
public:
	FSSpec				movieFileSpec;			//	in particular for 3D data
	Boolean				hasMovieFile;
	
	void	SetMovieFile( const FSSpec* aSpec )		{	 movieFileSpec = *aSpec;	hasMovieFile = true;	}
};


class SGroupTableItem : public STableItem {
public:
	virtual DataIDT	ItsType()		{	return	kGroupItemType;		};
	virtual short	GetIconID()		{	return	kGroupIconID;		};
	virtual short	GetTextTraits()	{	return	kGroupTextTraits;	};
	
	SGroupTableItem()												{};
	SGroupTableItem( ConstStringPtr inName ) : STableItem( inName )	{};
	SGroupTableItem( SGroupTableItem* inItem, copyOption duplicate ) : STableItem( inItem, duplicate )	{};
	virtual STableItem*	Copy( copyOption duplicate )	{	return	new SGroupTableItem( this, duplicate );	}
	SGroupTableItem( binaryStream& iStream ) : STableItem( iStream )		{};
};


class STableItemTxt : public STableItem {
public:
	virtual DataIDT	ItsType()		{	return	kUndefItemType;	};
	virtual short	GetIconID()		{	return	kUndefIconID;		};
	virtual short	GetTextTraits()	{	return 	kDataTextTraits;	};
	
	STableItemTxt()													{};
	STableItemTxt( ConstStringPtr inName ) : STableItem( inName )	{};
	STableItemTxt( STableItemTxt* inItem, copyOption duplicate ) : STableItem( inItem, duplicate )	{};
	virtual STableItem*	Copy( copyOption duplicate )	{	return	new STableItemTxt( this, duplicate );	}
	STableItemTxt( binaryStream& iStream ) : STableItem( iStream )		{};
};


template <class T>
class DataItem {
private:
	T*							data;
	pointer_with_ownership<T> 	data_ptr;
protected:
	T*&		ptr_()								{	return data;	};
	DataItem() : data_ptr(data)					{	data = NULL;	};
	void	change_ownership( bool owns )		{	data_ptr.change_ownership( owns );	};
	
	DataItem( DataItem* inItem, STableItem::copyOption duplicate ) : data_ptr(data)
		{	if (duplicate == STableItem::copy_all)			{	ptr_() = new T( *(inItem->ptr_()) );					}
			else if (duplicate == STableItem::move_to)		{	ptr_() = inItem->ptr_();	inItem->ptr_() = NULL;		}
			else if (duplicate == STableItem::copy_some)	{	ptr_() = inItem->ptr_();	change_ownership( false );	}
		}
};


class STableItem0D : public STableItem, private DataItem<double> {
//private:
//	double*		data;
//	pointer_with_ownership<double> data_ptr;
	
public:
	virtual DataIDT	ItsType()		{	return	kNumberItemType;	};
	virtual short	GetIconID()		{	return	kNumberIconID;		};
	virtual short	GetTextTraits()	{	return 	kDataTextTraits;	};
	
	double*&		Number()		{	return	ptr_();				};

	virtual SInt32	DoubleSize()	{	return 1;					};
	
	virtual double	Minimum()		{	return 	*Number();			};
	virtual double	Maximum()		{	return 	*Number();			};
	
public:		
	virtual	LStr255		DrawName()		{	return	Name();	}
	
public:

	STableItem0D()													{};		//	data = NULL;	};
	STableItem0D( ConstStringPtr inName ) : STableItem( inName )	{};		//	data = NULL;	};
	
	STableItem0D( double x, const STableItemInfo& info )
		: STableItem( info )						{	Number() = new double;	*Number() = x;	};
		
	~STableItem0D()									{	/*delete data;*/	};		//	done by ~DataItem
	

// copy constructor...		
	STableItem0D( STableItem0D* inItem, copyOption duplicate )		//	if not duplicate, transfer ownership !!
		: STableItem( inItem, duplicate ), DataItem<double>( inItem, duplicate ) {};
	/*	{	if (duplicate == copy_all)			{	Number() = new double;			*Number() = *(inItem->Number());	}
			else if (duplicate == move_to)		{	Number() = inItem->Number();	inItem->Number() = NULL;			}
			else if (duplicate == copy_some)	{	Number() = inItem->Number();	change_ownership( false );			}
		}*/
	virtual STableItem*	Copy( copyOption duplicate )	{	return	new STableItem0D( this, duplicate );	}

	virtual void	SaveIntoStream( ostream& to, char cr = '\n' );
	
	STableItem0D( binaryStream& iStream ) : STableItem( iStream )		{	Number() = iStream.ReadDouble();	};
	virtual void	write( binaryStream& oStream )						{	STableItem::write( oStream );	oStream.WriteDouble( Number() );	};
};



class STableItem1D : public STableItem, private DataItem<double_vector> {

private:
	MyMath::simplefunc*	func;						//	associated (interpolation) function
													//	STableItem1D: the (xi, yi) are enough to 'fully define' the function, and it is possible
													//					to switch from one to the other
													//	FunctionItem1D: the (xi, yi) are not sufficient. Cannot change the function.
public:
	typedef	enum { simple_interp, integ_interp } 			InterpType;
	
protected:
	void	SetFunc( MyMath::simplefunc* f )
		{	if (func)	delete func;
			func = f;
		};
public:
	Axis*			x_Axis;
	
	plotXScale*		x_plotScale;							//	to be used as default plot scales
	plotYScale*		y_plotScale;
	typedef	enum { linear_scale, log_scale } scaleType;
private:
	Boolean			inverted;
	scaleType		x_scale_type;
	scaleType		y_scale_type;
	
public:
	typedef	enum { undef_ser, dist_ser, ref_ser, ptr_ser } LinageType;
	LinageType		linType;
	
	void	ToPtr()
		{	func = new MyMath::inc_lin_interpolfunc( *(x_Axis->x), *Vector() );
			linType = ptr_ser;
		};
	
	Boolean		is_inverted()		const	{	return	inverted;	};
	void		set_inverted( Boolean inv )	{	inverted = inv;		};
	
	virtual void	inherit_some_features( STableItem1D* item )
		{	set_inverted( item->is_inverted() );
			//x_scale_type =
			//y_scale_type =
		};	
	
public:
	virtual DataIDT	ItsType()		{	return	kSeriesItemType;	};
	virtual short	GetIconID()		{	if (withReplicates)		return	kMultSeriesIconID;	
										else					return	kSeriesIconID;		};
	virtual short	GetTextTraits()	{	return 	kDataTextTraits;	};
	
	double_vector*&	Vector()					{	return	ptr_();		};
//	void			SetVector(double_vector* v)	{	ptr_() = v;				};
	
	virtual SInt32	DoubleSize()	{	return Vector()->length();	};
	
	virtual double	Minimum()		{	return 	Vector()->min();	};
	virtual double	Maximum()		{	return 	Vector()->max();	};
	
	virtual	LStr255	DrawName()		{	LStr255 mDrawName = Name();	mDrawName += "/";	mDrawName += x_Axis->Name();	return	mDrawName;	}
	
	
	MyMath::simplefunc*	Function()				{	return 	func;				};
	double 				Function( double t )	{	return 	func->ValueAt(t);	};
	
	void	makeReplicatesAxis( STableItem1D* oldSeries );
	
public:
	STableItem1D*	withReplicates;

private:
	
	void	initNull1D()
	{	x_Axis = NULL;	/*data = NULL;*/	func = NULL;
		withReplicates = NULL;
		x_plotScale = NULL;		y_plotScale = NULL;
		inverted = false;
		linType = undef_ser;
	};
	UInt8	Flags()
	{	UInt8	f = 0;
		if (inverted)		f = f | 1;
		if (withReplicates)	f = f | 2;
		return	f;
	}
	Boolean	inverted_Flags( UInt8 f )		{	return f & 1;	}
	Boolean	replicates_Flags( UInt8 f )		{	return f & 2;	}

public:

	STableItem1D()													{	initNull1D();	};
	STableItem1D( ConstStringPtr inName ) : STableItem( inName )	{	initNull1D();	};
	STableItem1D( const STableItemInfo& info ) : STableItem( info )	{	initNull1D();	};

	STableItem1D( double_vector* x, double_vector* m, ConstStringPtr xName, const STableItemInfo& info )
		 : STableItem( info )
							{	initNull1D();
								x_Axis = new Axis( x, xName );
								Vector() = m;
								func = new MyMath::lin_interpolfunc( *(x_Axis->x), *Vector() );
							};
	STableItem1D( double_vector* x, double_vector* m, double_vector* rx, double_vector* ry, ConstStringPtr xName, const STableItemInfo& info )
		 : STableItem( info )						//	idem above, but possibly with replicates
							{	initNull1D();
								x_Axis = new Axis( x, xName );
								Vector() = m;
								func = new MyMath::lin_interpolfunc( *(x_Axis->x), *Vector() );
								if (rx && ry)
									withReplicates = new STableItem1D( rx, ry, xName, info );
							};
							
	STableItem1D( double_vector* x, double_vector* m, MyMath::simplefunc* yf, ConstStringPtr xName, const STableItemInfo& info )
		 : STableItem( info )
							{	initNull1D();
								x_Axis = new Axis( x, xName );
								Vector() = m;
								func = yf;
							};
							
	STableItem1D( double_vector* x, double_vector* m, MyMath::simplefunc* yf, const std::string& xName, const STableItemInfo& info )
		 : STableItem( info )
							{	initNull1D();
								x_Axis = new Axis( x, xName );
								Vector() = m;
								func = yf;
							};
							
	STableItem1D( binaryStream& iStream )
		: STableItem( iStream )
							{	initNull1D();
								UInt8	flags;
								iStream >> *((UInt8*)&linType) >> flags;
								inverted = inverted_Flags( flags );
								x_Axis = new Axis( iStream );
								Vector() = iStream.ReadVector();
								func = iStream.ReadFunction( this );
								if ( replicates_Flags( flags ) )
									withReplicates = new STableItem1D( iStream );
							};
							
	virtual void	write( binaryStream& oStream )
							{	STableItem::write( oStream );
								oStream << (UInt8)linType << Flags();		//(UInt8)inverted;
								x_Axis->write(oStream);
								oStream.WriteVector( *Vector() );
								oStream.WriteFunction( func );
								if ( withReplicates )
									withReplicates->write( oStream );
							};

	~STableItem1D()			{	delete func;	/*delete data;*/	delete x_Axis;	if (withReplicates) delete withReplicates;	};
	
// copy constructor...		
	STableItem1D( STableItem1D* inItem, copyOption duplicate )		//	if not duplicate, transfer ownership !!
		: STableItem( inItem, duplicate ), DataItem<double_vector> ( inItem, duplicate )
		{	initNull1D();
			if (inItem->x_plotScale)	x_plotScale = inItem->x_plotScale;
			if (inItem->y_plotScale)	y_plotScale = inItem->y_plotScale;
			inverted = inItem->inverted;
			linType  = inItem->linType;
			x_Axis = new Axis( inItem->x_Axis, (Axis::copyOption)duplicate );
		/*		
			if (duplicate == copy_all)			{	Vector() = new double_vector( *(inItem->Vector()) );		}
			else if (duplicate == move_to)		{	Vector() = inItem->Vector();	inItem->Vector() = NULL;	}
			else if (duplicate == copy_some)	{	Vector() = inItem->Vector();	change_ownership( false );	}
		*/	
			if (inItem->func)	func = inItem->func->copySelf( *(x_Axis->x), *(Vector()) );
			else 				func = NULL;
			if (duplicate == move_to)	inItem->func = NULL;
			if (inItem->withReplicates) withReplicates = new STableItem1D( inItem->withReplicates, duplicate );
		};
	virtual STableItem*	Copy( copyOption duplicate )	{	return	new STableItem1D( this, duplicate );	}
	
	
	virtual plotRecord*	MakePlotRecord( int startColor = 0 );

	virtual void	SaveIntoStream( ostream& to, char cr = '\n' );
};


class STableItem2D : public STableItem, private DataItem<double_matrix> {
private:
//	double_matrix*	data;
	
public:
	Axis*		x_Axis;
	Axis*		y_Axis;
	
	virtual DataIDT	ItsType()		{	return	kMapItemType;		};
	virtual short	GetIconID()		{	return	kMapIconID;			};
	virtual short	GetTextTraits()	{	return 	kDataTextTraits;	};
	
	double_matrix*&	Matrix()		{	return	ptr_();				};
	virtual SInt32	DoubleSize()	{	return 	Matrix()->length();	};
	virtual double	Minimum()		{	return 	Matrix()->min();	};
	virtual double	Maximum()		{	return 	Matrix()->max();	};
	
	virtual	LStr255	DrawName()		{	LStr255	mDrawName = Name();	mDrawName += "/(";	mDrawName += x_Axis->Name();	mDrawName += ";";	mDrawName += y_Axis->Name();	mDrawName += ")";	return	mDrawName;	}
	
private:
	void	initNull2D()		{	x_Axis = y_Axis = NULL;	/*data = NULL;*/	};
	
public:

	STableItem2D()										{	initNull2D();	};
	STableItem2D( ConstStringPtr inName ): STableItem( inName )	{	initNull2D();	};
		
	STableItem2D( double_vector* x, double_vector* y, double_matrix* m, ConstStringPtr xName, ConstStringPtr yName, const STableItemInfo& info )
		 : STableItem( info )
		{	x_Axis = new Axis( x, xName );
			y_Axis = new Axis( y, yName );
			Matrix() = m;
		};
		
	STableItem2D( binaryStream& iStream )
		: STableItem( iStream )
		{	x_Axis = new Axis( iStream );
			y_Axis = new Axis( iStream );
			Matrix() = iStream.ReadMatrix();
		};
		
	virtual void	write( binaryStream& oStream )
	{	STableItem::write( oStream );	x_Axis->write(oStream);		y_Axis->write(oStream);		oStream.WriteMatrix( *Matrix() );	};
		
	~STableItem2D()	{	/*delete data;*/	delete x_Axis;	delete y_Axis;	};

//		copy	
	STableItem2D( STableItem2D* inItem, copyOption duplicate )		//	if not duplicate, transfer ownership !!
		: STableItem( inItem, duplicate ), DataItem<double_matrix> ( inItem, duplicate )
		{	x_Axis = new Axis( inItem->x_Axis, (Axis::copyOption)duplicate );
			y_Axis = new Axis( inItem->y_Axis, (Axis::copyOption)duplicate );
		/*	if (duplicate == copy_all)			{	Matrix() = new double_matrix( *(inItem->Matrix()) );		}
			else if (duplicate == move_to)		{	Matrix() = inItem->Matrix();	inItem->Matrix() = NULL;	}
			else if (duplicate == copy_some)	{	Matrix() = inItem->Matrix();	change_ownership( false );	}*/
		};
	virtual STableItem*	Copy( copyOption duplicate )	{	return	new STableItem2D( this, duplicate );	}
	
	virtual plotRecord* MakePlotRecord( int = 0 );
		
	virtual void	SaveIntoStream( ostream& to, char cr = '\n' );


};

class STableItem3D : public STableItem, private DataItem<double_3tensor> {
private:
//	double_3tensor*	data;
	
public:
	Axis*		x_Axis;
	Axis*		y_Axis;
	Axis*		z_Axis;
	
	virtual DataIDT		ItsType()		{	return	kMovieItemType;		};
	virtual short		GetIconID()		{	return	kMovieIconID;		};
	virtual short		GetTextTraits()	{	return 	kDataTextTraits;	};
	
	virtual SInt32		DoubleSize()	{	return Tensor()->length();	};
	
	double_3tensor*&	Tensor()	{	return	ptr_();				};
	virtual double	Minimum()		{	return 	Tensor()->min();	};
	virtual double	Maximum()		{	return 	Tensor()->max();	};

	virtual	LStr255	DrawName()		{	LStr255	mDrawName = Name();	mDrawName += "/(";	mDrawName += x_Axis->Name();	mDrawName += ";";	mDrawName += y_Axis->Name();	mDrawName += ";";	mDrawName += z_Axis->Name();	mDrawName += ")";	return	mDrawName;	}
	
private:
	void	initNull3D()				{	x_Axis = y_Axis = z_Axis = NULL;	/*data = NULL;*/	};
	
public:

	STableItem3D()													{	initNull3D();	};
	STableItem3D( ConstStringPtr inName ) : STableItem( inName )	{	initNull3D();	};
		
	STableItem3D( double_vector* x, double_vector* y, double_vector* z, double_3tensor* m, ConstStringPtr xName, ConstStringPtr yName, ConstStringPtr zName, const STableItemInfo& info )
		 : STableItem( info )
		{	x_Axis = new Axis( x, xName );
			y_Axis = new Axis( y, yName );
			z_Axis = new Axis( z, zName );
			Tensor() = m;
		};
	
	STableItem3D( binaryStream& iStream )
		: STableItem( iStream )
		{	x_Axis = new Axis( iStream );
			y_Axis = new Axis( iStream );
			z_Axis = new Axis( iStream );
			Tensor() = iStream.ReadTensor();
		};
		
	virtual void	write( binaryStream& oStream )
	{	STableItem::write( oStream );	x_Axis->write(oStream);		y_Axis->write(oStream);		z_Axis->write(oStream);		oStream.WriteTensor( *Tensor() );	};
		
	~STableItem3D()			{	/*delete data;*/	delete x_Axis;	delete y_Axis;	delete z_Axis;	};
		
	virtual Boolean		isMovingView()		{	return	true;	};
	
	void	MakeMovieOnFile( SDimension16 movie_size );
	void	Add3dPlotToMedia( Media theMedia, const Rect *trackFrame );
	
	plotRecord* MakeNthPlotRecord( int i );
	
	virtual plotRecord* MakePlotRecord( int  = 0 )
		{	return MakeNthPlotRecord( 1 );
		};

//		copy	

	STableItem3D( STableItem3D* inItem, copyOption duplicate )		//	if not duplicate, transfer ownership !!
		: STableItem( inItem, duplicate ), DataItem<double_3tensor> ( inItem, duplicate )
		{	x_Axis = new Axis( inItem->x_Axis, (Axis::copyOption)duplicate );
			y_Axis = new Axis( inItem->y_Axis, (Axis::copyOption)duplicate );
			z_Axis = new Axis( inItem->z_Axis, (Axis::copyOption)duplicate );
		/*	if (duplicate == copy_all)			{	Tensor() = new double_3tensor( *(inItem->Tensor()) );		}
			else if (duplicate == move_to)		{	Tensor() = inItem->Tensor();	inItem->Tensor() = NULL;	}
			else if (duplicate == copy_some)	{	Tensor() = inItem->Tensor();	change_ownership( false );	}*/
		};
	virtual STableItem*	Copy( copyOption duplicate )	{	return	new STableItem3D( this, duplicate );	}
	
//		saving

	virtual void	SaveIntoStream( ostream& to, char cr = '\n' );

};


class FunctionItem1D : public STableItem1D {		//	defined by 2 points only (start, end) and a function
private:
	static double_vector* build_x( double x_start, double x_end )
	{	double_vector* x = new double_vector(2);
		(*x)[1] = x_start; (*x)[2] = x_end;
		return x;
	};
	static double_vector* build_y( MyMath::simplefunc* yf, double x_start, double x_end )
	{	double_vector* y = new double_vector(2);
		(*y)[1] = yf->ValueAt(x_start); (*y)[2] = yf->ValueAt(x_end);
		return y;
	};
public:
	//STableItem1D( double_vector* x, double_vector* m, MyMath::simplefunc* yf, const std::string& xName, const STableItemInfo& info )
	FunctionItem1D( double x_start, double x_end, MyMath::simplefunc* yf, ConstStringPtr xName, const STableItemInfo& info )
		 : STableItem1D( build_x( x_start, x_end ),  build_y( yf, x_start, x_end ), yf, xName, info )		{};

};


class ResampledSeries : public STableItem1D {
//public:
//	typedef	enum { simple_interp, integ_interp } 			InterpType;
	
private:
	static std::string	makeFileName( STableItem1D* item, FourCharCode func_typ )
		{	std::ostringstream 	s;
			s << MyMath::simplefunc::TypeName( func_typ );
			s << "-interp. (" << item->sName() << ")";
			return	s.str();
		};
	static std::string	makeComment( STableItem1D* item, FourCharCode func_typ, InterpType inter_typ )
		{	std::ostringstream 	s;
			s << makeFileName( item, func_typ );
			switch (inter_typ)
			{	case simple_interp:	s << "\rsimple interpolation";	break;
				case integ_interp:	s << "\rintegration interpolation: mean values between mid-points";	break;
			}
			return	s.str();
		}
		
public:
	ResampledSeries( STableItem1D* item, double_vector* newx = NULL, FourCharCode func_typ = MyMath::LinearInterpFunctionCode, InterpType inter_typ = integ_interp )
	: STableItem1D( STableItemInfo( item->sName(), makeFileName( item, func_typ ), makeComment( item, func_typ, inter_typ ), string("Resampling"), item) )
		{	if (newx == NULL)
			{	const double_vector& in_x = *(item->x_Axis->x);
				size_t	n = in_x.length();
				newx = new MyMath::double_regular_array( in_x[1], in_x[n], n );
			}
			switch (func_typ)
			{	case MyMath::StairInterpFunctionCode:			SetFunc( new MyMath::stair_interpolfunc( *(item->x_Axis->x), *(item->Vector()) ));		break;
				case MyMath::StairStartInterpFunctionCode:		SetFunc( new MyMath::stair_start_interpolfunc( *(item->x_Axis->x), *(item->Vector()) ));	break;
				case MyMath::StairEndInterpFunctionCode:		SetFunc( new MyMath::stair_end_interpolfunc( *(item->x_Axis->x), *(item->Vector()) ));	break;
				case MyMath::LinearInterpFunctionCode:			SetFunc( new MyMath::lin_interpolfunc( 	 *(item->x_Axis->x), *(item->Vector()) ));		break;
				case MyMath::SplineInterpFunctionCode:			SetFunc( new MyMath::splin_interpolfunc( *(item->x_Axis->x), *(item->Vector()) ));		break;
			}
			x_Axis = new Axis( newx, item->x_Axis->Name() );
			Vector() = new double_vector( newx->length() );
			size_t n = newx->length();
			switch (inter_typ)
			{	case simple_interp:
					for (size_t j=1; j<=n; j++)
						(*Vector())[j] = Function( (*newx)[j] );
				break;
				case integ_interp:
					MyMath::double_extra_midpoints_array	mPoints( *newx );
					for (size_t j=1; j<=n; j++)
						(*Vector())[j] = Function()->MeanBetween( mPoints[j-1], mPoints[j] );
				break;
			}
			inherit_some_features( item );
		};
};

class ResampledYSeries : public STableItem1D {
//public:
//	typedef	enum { simple_interp, integ_interp } 			InterpType;
	
private:
	static std::string	makeFileName( STableItem1D* item, FourCharCode func_typ )
		{	std::ostringstream 	s;
			s << MyMath::simplefunc::TypeName( func_typ );
			s << "-interp. (" << item->sName() << ")";
			return	s.str();
		};
	static std::string	makeComment( STableItem1D* item, FourCharCode func_typ, InterpType inter_typ )
		{	std::ostringstream 	s;
			s << makeFileName( item, func_typ );
			switch (inter_typ)
			{	case simple_interp:	s << "\rsimple interpolation";	break;
				case integ_interp:	s << "\rintegration interpolation: mean values between mid-points";	break;
			}
			return	s.str();
		}
		
public:
	ResampledYSeries( STableItem1D* item, double_vector* newy, InterpType inter_typ = integ_interp )
	: STableItem1D( STableItemInfo( item->sName(), makeFileName( item, MyMath::LinearInterpFunctionCode ), makeComment( item, MyMath::LinearInterpFunctionCode, inter_typ ), string("Resampling Y"), item) )
		{	size_t n = newy->length();
			Vector() = newy;	//	new double_vector( newx->length() );
			x_Axis = new Axis( new double_vector( n ), item->x_Axis->Name() );
			MyMath::lin_interpolfunc tempF( *(item->Vector()), *(item->x_Axis->x) );
			switch (inter_typ)
			{	case simple_interp:
					for (size_t j=1; j<=n; j++)
						(*(x_Axis->x))[j] = tempF.ValueAt( (*newy)[j] );
				break;
				case integ_interp:
					MyMath::double_extra_midpoints_array	mPoints( *newy );
					for (size_t j=1; j<=n; j++)
						(*(x_Axis->x))[j] = tempF.MeanBetween( mPoints[j-1], mPoints[j] );
				break;
			}
			SetFunc( new MyMath::lin_interpolfunc( *(x_Axis->x), *(Vector()) ));
			inherit_some_features( item );
		};
};

class FittedSeries : public STableItem1D {
private:
	static std::string	makeFileName( STableItem1D* item, FourCharCode func_typ, STableItem1D* item_err_y )
		{	std::ostringstream 	s;
			s << MyMath::simplefunc::TypeName( func_typ );
			string	errY_name;
			if (item_err_y)	errY_name += string(" � ") + item_err_y->sName();
			s << "-fit. (" << item->sName() << errY_name << ")";
			return	s.str();
		};
	static std::string	makeComment( STableItem1D* item, FourCharCode func_typ, MyMath::fit_func::fittingFlag fFlag, STableItem1D* item_err_y, double sy = MyMath::NaN() )
		{	std::ostringstream 	s;
			s << makeFileName( item, func_typ, item_err_y );
			switch (fFlag)
			{	case MyMath::fit_func::stdFit:	s << "\rMean-square fit";			break;
				case MyMath::fit_func::absFit:	s << "\rMean-abs deviation fit";	break;
			}
			if  (!MyMath::is_NaN(sy))
				s << "assuming constant errors on y ( err_y = " << sy << ")\r";
			return	s.str();
		}
		
public:
	FittedSeries( STableItem1D* item, 			//	the original series to be fitted
		double_vector* newx,					//	the new scale
		FourCharCode func_typ = MyMath::LinearInterpFunctionCode,				//	the function basis used for the fit
		MyMath::fit_func::fittingFlag fFlag = MyMath::fit_func::stdFit, 		//	default is least-square fit
		STableItem1D* item_err_y = NULL,		//	optionally, the error series on y
		double sy = MyMath::NaN()				//	optionally, the constant error on y
	)
	: STableItem1D( STableItemInfo( item->sName(), makeFileName( item, func_typ, item_err_y ), makeComment( item, func_typ, fFlag, item_err_y, sy ), string("Fitting"), item, item_err_y ) )
		{	
			double_vector*	oldx = item->x_Axis->x;
			double_vector*	oldy = item->Vector();
			double			err_y	= (MyMath::is_NaN(sy) ? 1.0 : sy);		//	to do the actual fit, use 1.0 when no error defined
			
			MyMath::simplefunc*	fitfunc;
			MyMath::fit_func*	f_func;

			switch (func_typ)
			{	case MyMath::StairInterpFunctionCode:
					{	MyMath::stair_interpol_fit_func*	afunc;
						if (item_err_y)		afunc = new MyMath::stair_interpol_fit_func(	fFlag, *newx, *oldx, *oldy, *(item_err_y->Vector()) );
						else				afunc = new MyMath::stair_interpol_fit_func(	fFlag, *newx, *oldx, *oldy, err_y );
						fitfunc = afunc;	f_func = afunc;
					}	break;
				case MyMath::LinearInterpFunctionCode:
					{	MyMath::lin_interpol_fit_func* 		afunc;
						if (item_err_y)		afunc = new MyMath::lin_interpol_fit_func(	fFlag, *newx, *oldx, *oldy, *(item_err_y->Vector()) );
						else				afunc = new MyMath::lin_interpol_fit_func(	fFlag, *newx, *oldx, *oldy, err_y );
						fitfunc = afunc;	f_func = afunc;
					}	break;
				case MyMath::SplineInterpFunctionCode:
					{	MyMath::splin_interpol_fit_func*	afunc;
						if (item_err_y)		afunc = new MyMath::splin_interpol_fit_func(	fFlag, *newx, *oldx, *oldy, *(item_err_y->Vector()) );
						else				afunc = new MyMath::splin_interpol_fit_func(	fFlag, *newx, *oldx, *oldy, err_y );
						fitfunc = afunc;	f_func = afunc;
					}	break;
			}
			SetFunc( fitfunc );
			
			x_Axis = new Axis( newx, item->x_Axis->Name() );
			size_t n = newx->length();
			Vector() = new double_vector( n );
			for (size_t j=1; j<=n; j++)
				(*Vector())[j] = fitfunc->ValueAt( (*newx)[j] );
				
			inherit_some_features( item );
		};
};


class FittedPolynomialSeries : public FunctionItem1D {
private:
	static std::string	makeFileName( STableItem1D* item, STableItem1D* item_err_y, int deg = 1 )
		{	std::ostringstream 	s;
			//	s << MyMath::simplefunc::TypeName( MyMath::PolynomialFunctionCode );
			if (deg == 1)		s << "Linear";
			else				s << "Polynomial deg. " << deg;
			string	errY_name;
			if (item_err_y)	errY_name += string(" � ") + item_err_y->sName();
			s << "-fit. (" << item->sName() << errY_name << ")";
			return	s.str();
		};
	static std::string	makeComment( STableItem1D* item, MyMath::fit_func::fittingFlag fFlag, MyMath::fit_func* f_func,
									 STableItem1D* item_err_y, double sy = MyMath::NaN(), int deg = 1,
									 STableItem1D* item_err_x = nil, double sx = MyMath::NaN() )
		{	std::ostringstream 	s;
			s << makeFileName( item, item_err_y, deg ) << "\r";
			if  (!MyMath::is_NaN(sy))
				s << "assuming constant errors on y ( err_y = " << sy << ")\r";
			if (item_err_x)
				s << "Using errors also on x-scale (" << item_err_x->sName() << ")\r";
			if (!MyMath::is_NaN(sx))
				s << "assuming constant errors on x ( err_x = " << sx << ")\r";
			switch (fFlag)
			{	case MyMath::fit_func::stdFit:	s << "Mean-square fit\r";			break;
				case MyMath::fit_func::absFit:	s << "Mean-abs deviation fit\r";	break;
			}
			MyMath::line_fit_func* lf = dynamic_cast<MyMath::line_fit_func*>(f_func);
			if (lf)		s << "(siga = " << lf->siga << "; sigb = " << lf->sigb << "; q = " << lf->q << ")\r";
			switch (fFlag)
			{	case MyMath::fit_func::stdFit:	s << "chi2 = " << f_func->chisq << "\r";	break;
				case MyMath::fit_func::absFit:	s << "sum_abs = " << f_func->chisq << "\r";	break;
			};
			MyMath::polynomfunc* pf = dynamic_cast<MyMath::polynomfunc*>(f_func);
			if (pf)
			{	s << "Fit = " << pf->Coefficient( 0 );
				for (size_t j=1; j<=deg; j++)
				{	double	cj = pf->Coefficient( j );
					if (cj>=0)	s << " +";	else s << " ";
					s << cj << " x";	if (j>1)	s << j;
				}
				s << "\r";
			}
			return	s.str();
		}
		
public:
	FittedPolynomialSeries( STableItem1D* item, MyMath::polynom_fit_func* afunc, size_t	degre, MyMath::fit_func::fittingFlag fFlag = MyMath::fit_func::stdFit,
		STableItem1D* item_err_y = NULL, double sy = MyMath::NaN() )
		
	: FunctionItem1D( (*(item->x_Axis->x))[1], (*(item->x_Axis->x))[item->x_Axis->x->length()], afunc, item->x_Axis->Name(),
		STableItemInfo( item->sName(), makeFileName( item, item_err_y, degre ), makeComment( item, fFlag, afunc, item_err_y, sy, degre ), string("Fitting"), item, item_err_y ) )
		{	inherit_some_features( item );
		};
		
		
	FittedPolynomialSeries( STableItem1D* item, MyMath::line_fit_func* lf,			//	errors on both x and y for line fitting and fFlag == MyMath::fit_func::stdFit
		STableItem1D* item_err_y = NULL, double sy = MyMath::NaN(), STableItem1D* item_err_x = NULL, double sx = MyMath::NaN() )
		
	: FunctionItem1D( (*(item->x_Axis->x))[1], (*(item->x_Axis->x))[item->x_Axis->x->length()], lf, item->x_Axis->Name(),
		STableItemInfo( item->sName(), makeFileName( item, item_err_y ), makeComment( item, MyMath::fit_func::stdFit, lf, item_err_y, sy, 1, item_err_x, sx ), string("Fitting"), item, item_err_y ) )
		{	inherit_some_features( item );
		};
};



class FilteredSeries : public STableItem1D {
private:
	static std::string	makeComment( STableItem1D* /*item*/, STableItem1D* /*filterItem*/ )
		{	std::ostringstream 	s;
			s << "Filter = ...";
			return	s.str();
		}
		
public:
	FilteredSeries( STableItem1D* item0, STableItem1D* filterItem )
	: STableItem1D( STableItemInfo( item0->sName(), item0->sName() + "-filtered", makeComment( item0, filterItem ), string("Filtering"), item0, filterItem ) )
		{	
			STableItem1D* item = item0;
			if (! item0->x_Axis->x->check_regular() )		//	if not regular, resample !!
				item = new ResampledSeries( item0 );
				
			MyMath::double_power2_array	y( *(item->Vector()), MyMath::double_power2_array::remove_mean );
			const double_vector& in_x = *(item->x_Axis->x);
			size_t	n = in_x.length();
			double	dx = in_x[2]-in_x[1];
			y.Filter( filterItem->Function(), dx );
			
			double_vector*	newx = new double_vector( in_x );
			x_Axis = new Axis( newx, item->x_Axis->Name() );
			
			Vector() = new double_vector( n );
			for (size_t j=1; j<=n; j++)		(*Vector())[j] = y(j);
			
			inherit_some_features( item );
			if (Function() == NULL)		SetFunc( new MyMath::lin_interpolfunc( *(x_Axis->x), *(Vector()) ));
			
			if (item != item0)	delete item;				//	destroy the intermediate
		};
};