

#pragma once

#include <QuickTime/ImageCodec.h>
//#include <GXTypes.h>

#include "plotRecord.h"
#include "CMyStdDialogs.h"


#include "LMoovController.h"
#include "LMoovCommander.h"
#include "CTextDocument.h"
#include "CGroupTableItem.h"
#include "TablesConstants.h"


//	DrawingWindow	

const ResIDT	rPPob_DrawingWindow				= 1500;
const PaneIDT	kDrawingView					= 1;
const PaneIDT	kMovieView						= 4;

//	CDrawingView

const PaneIDT	kDrawingView_YScalePopup		= 2;
const PaneIDT	kDrawingView_XScalePopup		= 3;
const PaneIDT	kDrawingView_y_ZoomAdjust		= 5;
const PaneIDT	kDrawingView_x_ZoomAdjust		= 6;
const PaneIDT	kDrawingView_y_ZoomCaption		= 7;
const PaneIDT	kDrawingView_x_ZoomCaption		= 8;
const PaneIDT	kDrawingView_colorPopup			= 9;

const PaneIDT	kDrawingView_message_Caption	= 10;
const PaneIDT	kDrawingView_message2_Caption	= 11;

const PaneIDT	kDrawingView_no_scale			= 1;
const PaneIDT	kDrawingView_same_scale			= 2;
const PaneIDT	kDrawingView_multiple_scale		= 3;
const PaneIDT	kDrawingView_inverted_scale		= 5;

const MessageT	msg_DrawingView_y_popupChanged	= 1000;
const MessageT	msg_DrawingView_x_popupChanged	= 1001;
const MessageT	msg_DrawingView_y_ZoomAdjust	= 1002;
const MessageT	msg_DrawingView_x_ZoomAdjust	= 1003;
const MessageT	msg_DrawingView_colorChanged	= 1005;

const ResIDT	rFirstColorIcon					= 415;


//	LinageWindow	

const ResIDT	rPPob_LinageWindow				= 1501;

const PaneIDT	kLinage_YScalePopup				= 50;

const PaneIDT	kReferenceView					= 1;
const PaneIDT	kSeriesView						= 2;
const PaneIDT	kPtrView						= 4;		//	= back/front view
const PaneIDT	kLinageOptionPopup				= 11;

const PaneIDT	kLinageOption_select_data		= 1;
const PaneIDT	kLinageOption_select_curve		= 2;
const PaneIDT	kLinageOption_not_interact		= 4;
const PaneIDT	kLinageOption_half_interact		= 5;
const PaneIDT	kLinageOption_full_interact		= 6;


const PaneIDT	kLinage_YScale_invert			= 1;
const PaneIDT	kLinage_YScale_invert_ref		= 2;
const PaneIDT	kLinage_YScale_invert_dis		= 3;

const MessageT	msg_LinageOptionsChanged		= 1010;
const MessageT	msg_LinageYScalePopupChanged	= 1011;




/*			Quickdraw predefined colors
enum {
  blackColor                    = 33,		{0,0,0}			5
  whiteColor                    = 30,		{255,255,255}
  redColor                      = 205,		{221,8,6}		0
  greenColor                    = 341,		{0,128,17}		1
  blueColor                     = 409,		{0,0,212}		2
  cyanColor                     = 273,		{2,171,234}		3
  magentaColor                  = 137,		{242,8,132}		4
  yellowColor                   = 69		{252,243,5}		6
};
*/


class	macLineType : public line_type {
public:
	typedef enum { qdColors, rgbColors, valueColors }	colorType;
	static const RGBColor	rgb_blackColor;
	static const RGBColor	rgb_whiteColor;
	static const RGBColor	rgb_redColor;
	static const RGBColor	rgb_greenColor;
	static const RGBColor	rgb_blueColor;
	static const RGBColor	rgb_cyanColor;
	static const RGBColor	rgb_magentaColor;
	static const RGBColor	rgb_yellowColor;
	static const RGBColor	qd_IndexedColors[8];
//	static RGBColor	rgbOut;
public:
	colorType	color;
	int			index;
	plotScale*	v_scale;
	RGBColor	rgb;
	
	macLineType( colorType c, int i=0, plotScale* v=NULL )
		: color(c), index(i), v_scale(v), rgb(rgb_blackColor)	{};
	virtual void	setIndex( int i )				{	index = i;		};
	virtual void	setScale( plotScale* s )		{	v_scale = s;	};
	virtual void	setRGB( RGBColor new_rgb )		{	rgb = new_rgb;	color = rgbColors;	};
	
	virtual line_type*	copy()		{	return	new macLineType( color, index, v_scale ); };
	
	int GetPenSize()
	{	if ( ( color == valueColors ) && (v_scale->xValueScale.Values()[index] == 0) )
			return 2;
		else
			return 1;
	};
	const RGBColor* GetRGBColor()
	{	if ( color == qdColors )
			return  &(qd_IndexedColors[ index % 7 ]);
		
		else if ( color == rgbColors )
			return	&rgb;
			
		else if ( color == valueColors )
		{	const	double_vector&	v = v_scale->xValueScale.Values();
			int		nv = v_scale->xValueScale.nxScale;
			double	c = 1;
		/*	
			if (v[index] == 0)	::PenSize(2,2);
			else
				::PenSize(1,1);
		*/	
			if (nv > 1 && v[1] != v[nv])	c = (v[index] - v[1])/(v[nv] - v[1]);
			
			RGBColor	rgbMin = { 0xC000, 0xC000, 0xC000 };	//	gris
			RGBColor	rgbMax = { 0x0000, 0x0000, 0x0000 };	//	noir
			rgb.red 	= (unsigned short)(rgbMin.red + c * (rgbMax.red - rgbMin.red));
			rgb.green 	= (unsigned short)(rgbMin.green + c * (rgbMax.green - rgbMin.green));
			rgb.blue 	= (unsigned short)(rgbMin.blue + c * (rgbMax.blue - rgbMin.blue));
			return &rgb;
		}
	};
};


class	STableItem;
class	STableItem3D;
class	basicDrawer;

class CMovieView : public LMoovCommander	{
public:
	Handle	mMovieHdle;
	Handle	mDataRef;
	Handle	mMovieData;
	Movie	theMovie;
	Track	theTrack;
	Media	theMedia;
    FSSpec	mySpec;
    
    Boolean			movieOnFile;
    STableItem3D*	itsItem;
	
	enum { class_ID = 'Plyx' };
	CMovieView( LStream *inStream ) : LMoovCommander( inStream )
		{	mMovieHdle = nil;	mDataRef = nil;		mMovieData = nil;	theMovie = nil;		movieOnFile = false;	itsItem = NULL;
		};
	~CMovieView()
		{	::DisposeHandle( mMovieHdle );
			::DisposeHandle( mMovieData );
			::DisposeHandle( mDataRef );
//			CTextDocument::RefreshMemView( this );
		};
	
	virtual void	ActivateSelf();
	void	AttachItem( STableItem3D* theItem )		{	itsItem = theItem;	};
	
	void	MakeVideo( STableItem3D* theItem );
	void	MakeMovieOnFile( STableItem3D* theItem );
	void	OpenMovieFile( FSSpec* spec = NULL );
	Boolean	ChooseMovieFileName( STableItem* theItem );
	
	long	AddPlotToMedia(  STableItem3D* theItem, const Rect *trackFrame );
	long	AddAnimationToMedia(  basicDrawer& draw, STableItem3D* theItem, const Rect *trackFrame );
	
private:
	
	void	AdjustSize( const Rect *trackFrame, long adjust );
};


class basicDrawer: public drawer {			//	standard QuickDraw calls

protected:
    Rect					trackFrame;
    ImageDescriptionHandle	imageDesc;
    CodecType				codecT;
    CodecQ					quality;
    
public:
	basicDrawer( const Rect *frame )
		{	trackFrame = *frame;
			codecT = kQuickDrawCodecType;
             					//	kGIFCodecType 
             					//	kJPEGCodecType
             					//	kAnimationCodecType
             					//	kQuickDrawCodecType
             					//	kMacPaintCodecType
             					//	kVectorCodecType
			quality = codecNormalQuality;
              					//	codecNormalQuality
              					//	codecLosslessQuality
              					//	codecMaxQuality
              					//	codecMinQuality
              					//	codecLowQuality
              					//	codecHighQuality
			imageDesc = nil;
		};
	virtual ~basicDrawer()
		 {   if (imageDesc)		::DisposeHandle ((Handle)imageDesc);	};
	virtual void	moveto( double x, double y )
		{	::MoveTo( MyMath::long_round(x), MyMath::long_round(y) );	};
	virtual void	lineto( double x, double y )
		{	::LineTo( MyMath::long_round(x), MyMath::long_round(y) );	};
	virtual void	eraseDraw( double x0, double y0, double x1, double y1 )
		{	Rect r = { MyMath::long_round(y0), MyMath::long_round(x0), MyMath::long_round(y1), MyMath::long_round(x1) };
			::EraseRect( &r );
		};
	virtual void	setline( line_type* lType );
	virtual void	drawText( const char* txt, double x, double y, textPosition posCode );
	virtual void	resetDraw();
	
	virtual void	init()		{};	//	= 0;
	virtual void	end()		{};	//	= 0;
	
	virtual	Handle					Data()			{	return nil;									};
	virtual	long					DataSize()		{	return ::GetHandleSize(Data());				};
	virtual	SampleDescriptionHandle	DescriptionH()	{	return (SampleDescriptionHandle)imageDesc;	};
	
	virtual void makeDescription()
	{	imageDesc = (ImageDescriptionHandle)::NewHandleClear(sizeof(ImageDescription));
		ThrowIfMemFail_( imageDesc );
		
		// fill in the fields of the image description
		(**imageDesc).idSize = sizeof(ImageDescription);
		(**imageDesc).cType = codecT;							//	to be changed
		(**imageDesc).vendor = kAppleManufacturer;
		(**imageDesc).temporalQuality = quality;
		(**imageDesc).spatialQuality = quality;
		(**imageDesc).width = trackFrame.right - trackFrame.left;
		(**imageDesc).height = trackFrame.bottom - trackFrame.top;
		(**imageDesc).hRes = 72L << 16;
		(**imageDesc).vRes = 72L << 16;
		(**imageDesc).dataSize = 0L;
		(**imageDesc).frameCount = 1;
		(**imageDesc).depth = 0;
		(**imageDesc).clutID = -1;
	};
};

class animationDrawer: public basicDrawer {	
private:
    GWorldPtr	theGWorld;
	long   		maxCompressedSize;
    Handle  	compressedData;
    Ptr     	compressedDataPtr;
    CGrafPtr	oldPort;
    GDHandle	oldGDeviceH;
    
public:
	
	virtual	Handle	Data()							{	return compressedData;			};
	virtual	long	DataSize()						{	return (**imageDesc).dataSize;	};
	
	animationDrawer( const Rect *frame ) : basicDrawer( frame )
		{	theGWorld = NULL;	compressedData = nil;
			codecT = kAnimationCodecType;
			quality = codecNormalQuality;
			make();
		};
	~animationDrawer()
	    {	::SetGWorld (oldPort, oldGDeviceH);
		    if (compressedData) ::DisposeHandle (compressedData);
		    if (theGWorld)		::DisposeGWorld (theGWorld);
		};
	void	make()
		{    ThrowIfOSErr_ ( ::NewGWorld (&theGWorld, 
			                        16,            						//	pixel depth
			                        &trackFrame, 
			                        nil, 
			                        nil, 
			                        (GWorldFlags) 0 ) );
    		PixMapHandle pPixMap = ::GetGWorldPixMap ( theGWorld );
	    	::LockPixels (pPixMap);
			ThrowIfOSErr_ ( ::GetMaxCompressionSize (pPixMap,
                                    &trackFrame, 
                                    0,									//	let ICM choose depth
                                    quality,
                                    codecT, 
                                  	(CompressorComponent) anyCodec,		// 	(CompressorComponent) bestFidelityCodec, ?
                                    &maxCompressedSize ) );
    		compressedData = ::NewHandle(maxCompressedSize);
    		ThrowIfOSErr_( ::MemError() );
		    ::MoveHHi( compressedData );
		    ::HLock( compressedData );
		    //compressedDataPtr = StripAddress( *compressedData );
		    compressedDataPtr = *compressedData;
		    imageDesc = (ImageDescriptionHandle)::NewHandle(4);
		    ThrowIfOSErr_( ::MemError() );
		    ::GetGWorld (&oldPort, &oldGDeviceH);
		    ::SetGWorld (theGWorld, nil);
		};
		
	virtual void	end()
	    {   PixMapHandle pPixMap = ::GetGWorldPixMap ( theGWorld );
	    	ThrowIfOSErr_( ::CompressImage ( pPixMap, 
	                                    &trackFrame, 
	                                    quality,
	                                    codecT,
	                                    imageDesc, 
	                                    compressedDataPtr ) );
	     };
};

class pictDrawer: public basicDrawer {
public:
	PicHandle		currentPict;
public:
	pictDrawer( const Rect *frame ) : basicDrawer( frame )
		{	currentPict = NULL;
			codecT = kQuickDrawCodecType;
			quality = codecNormalQuality;
		};
		
	virtual void	init()		// ( double x0, double y0, double x1, double y1 )
		{	//Rect r = { MyMath::long_round(y0), MyMath::long_round(x0), MyMath::long_round(y1), MyMath::long_round(x1) };
			currentPict = ::OpenPicture( &trackFrame );
		//	Rect r = { trackFrame.top, trackFrame.left, 2 * trackFrame.bottom - trackFrame.top, 2 * trackFrame.right - trackFrame.left };
		//	currentPict = ::OpenPicture( &r );
		};
	virtual void	end()
		{		// add the 'zero' atom to the vector data stream
			::ClosePicture();
			makeDescription();
		};
		
	
	virtual	Handle	Data()							{	return (Handle)currentPict;		};
};


class qtVectorDrawer: public basicDrawer {
public:
	unsigned long		point_index;
	ComponentInstance 	vectorCodec;
	Handle 				itsStreamH;
	Handle				currentPath;
	
//private:
	void EndCurrentLine()
		{	if (currentPath != NULL)
			{	ThrowIfOSErr_( ::CurveAddPathAtomToVectorStream( vectorCodec, currentPath, itsStreamH ) );
				::DisposeHandle( currentPath );
				currentPath = NULL;
			}
		};
	void StartNewLine()
		{	point_index = 0;
			ThrowIfOSErr_( ::CurveNewPath( vectorCodec, &currentPath ) );
		};
		
	Fixed qtFloatToFixed(double a)	{	return	((Fixed)((float)(a) * fixed1));	};
//#define FloatToFixed(a)      ((Fixed)((float)(a) * fixed1))
		
public:
	qtVectorDrawer( const Rect *frame ) : basicDrawer( frame )
		{	codecT = kVectorCodecType;
			quality = codecNormalQuality;
		};
	~qtVectorDrawer()
		{		// add the 'zero' atom to the vector data stream
			//ThrowIfOSErr_( ::CurveAddZeroAtomToVectorStream( vectorCodec, itsStreamH ) );
		};
	void	end()
		{		// add the 'zero' atom to the vector data stream
			ThrowIfOSErr_( ::CurveAddZeroAtomToVectorStream( vectorCodec, itsStreamH ) );
			makeDescription();
		};
	void	init()
		{	vectorCodec = NULL;	point_index = 0;	currentPath = NULL;	itsStreamH = NULL;
			//		open the vector codec component
				ThrowIfOSErr_( ::OpenADefaultComponent( decompressorComponentType, kVectorCodecType, &vectorCodec ) );
			//		create a new vector data stream
				ThrowIfOSErr_( ::CurveCreateVectorStream( vectorCodec, &itsStreamH ) );
			// set antialiasing on
			//	value = EndianU32_NtoB(kCurveAntialiasOn);
				long value = kCurveAntialiasOn;
				ThrowIfOSErr_( ::CurveAddAtomToVectorStream( vectorCodec, kCurveAntialiasControlAtom, sizeof(long), &value, itsStreamH ) );
		};
	virtual void	moveto( double x, double y )
		{	EndCurrentLine();	StartNewLine();
			gxPoint	point = { qtFloatToFixed(x),  qtFloatToFixed(y) };
			ThrowIfOSErr_( ::CurveInsertPointIntoPath( vectorCodec, &point, currentPath, 0, point_index++, true ) );
		};
	virtual void	lineto( double x, double y )
		{	gxPoint	point = { qtFloatToFixed(x),  qtFloatToFixed(y) };
			ThrowIfOSErr_( ::CurveInsertPointIntoPath( vectorCodec, &point, currentPath, 0, point_index++, true ) );
		};
	virtual void	eraseDraw( double x0, double y0, double x1, double y1 );
	virtual void	setline( line_type* lType );
	virtual void	drawText( const char* txt, double x, double y, textPosition posCode );
	virtual void	resetDraw();
	
	virtual	Handle	Data()							{	return (Handle)itsStreamH;		};
};


class CDrawWindow : public LWindow {
public:
	enum { class_ID = FOUR_CHAR_CODE('Dwin') };
	
	CDrawWindow( LStream *inStream ) : LWindow( inStream )	{};
	~CDrawWindow();
	
//	virtual	void	DoClose();
//	virtual	void	FinishCreate();
};




class	STableItemArray;


class CDrawingView : public LView, public LListener	{
public:
	plotRecord*		mPlotRecord;
    STableItemArray	itsItems;
	
	static OSErr	ChangeCIconIXColor(CIconHandle cicn, short index, RGBColor *color);

private:
	LWindow* 		itsWindow;
	size_t			cur_zoom_x;		//	= 1, 2, 4, 8, 16
	size_t			cur_zoom_y;
//	enum			{	max_zoom = 16	};
	
			//	for slower message update
	UInt32				nextTick;
	static const UInt32	TickFreq = 15;
	
	
	CMovieView*		itsMovieView()
		{	if (itsWindow)	return	dynamic_cast<CMovieView*>(itsWindow->FindPaneByID(kMovieView));
			else			return	NULL;
		};
	void	HideMovieView()		{	if (itsMovieView())	itsMovieView()->Hide();	};
	void	SetColorPopup();
	
public:
	enum { class_ID = 'Drvw' };
	
	CDrawingView( LStream *inStream ) : LView( inStream )
		{	mPlotRecord = NULL;		itsWindow = NULL;	cur_zoom_x = 1;	cur_zoom_y = 1;
			nextTick = ::TickCount() + TickFreq;
		};
	~CDrawingView()
		{	delete mPlotRecord;	};
		
	virtual void	AttachRecord( plotRecord* rec );
	virtual void	AttachItem( STableItem* theItem, int i = 0 )
		{	if (!theItem)	Hide();
			else			{	Show();	AttachItems( theItem->the_item_Table(), i );	};
		};
	virtual void	AttachItems( const STableItemArray& theItems, int i = 0 )
		{	itsItems.Copy( theItems );
			AttachRecord( theItems.MakePlotRecord(i) );
		};

	void		SetDrawingSize( Boolean refresh = true );
	
	virtual void	DrawSelf();
	virtual void	AdjustMouseSelf( Point, const EventRecord&, RgnHandle );
	virtual void	ClickSelf( const SMouseDownEvent& );
	virtual void	Click( SMouseDownEvent &inMouseDown );
	virtual void	AdaptToSuperScroll( SInt32 inHorizScroll, SInt32 inVertScroll );
	virtual void	AdjustMouse( Point inPortPt, const EventRecord& inMacEvent, RgnHandle outMouseRgn );

	virtual void	AdaptToSuperFrameSize( SInt32	inSurrWidthDelta, SInt32 inSurrHeightDelta, Boolean	inRefresh );
	
	virtual void	LinkView( LWindow* inWindow, SInt16 ppob_ID )
		{	itsWindow = inWindow;
			HideMovieView();
			UReanimator::LinkListenerToControls( this, inWindow, ppob_ID );
		};
	virtual void	ListenToMessage( MessageT inMessage, void* ioParam );


private:	
	plotRecord::scale_type	stored_y_sc;
	plotRecord::scale_type	stored_x_sc;
	Boolean		stored_reversed_x;
	Boolean		stored_reversed_y;
public:	
	void	StoreScaleSettings()
		{	if (mPlotRecord)
			{	stored_y_sc = mPlotRecord->ny_sc;
				stored_x_sc = mPlotRecord->nx_sc;
				stored_reversed_x = mPlotRecord->X_Scale()->isReversed();
				stored_reversed_y = mPlotRecord->Y_Scale()->isReversed();
			}
		};
	void	RestoreScaleSettings()
		{	if (mPlotRecord)
			{	switch ( stored_y_sc )	{
					case plotRecord::no_scale:			mPlotRecord->SetNoYScale();	break;
					case plotRecord::same_scale:		mPlotRecord->SetSameYScale();	break;
					case plotRecord::multiple_scale:	mPlotRecord->SetMultYScale();	break;
				}
				switch ( stored_x_sc )	{
					case plotRecord::no_scale:			mPlotRecord->SetNoXScale();	break;
					case plotRecord::same_scale:		mPlotRecord->SetSameXScale();	break;
					case plotRecord::multiple_scale:	mPlotRecord->SetMultXScale();	break;
				}
			}
			
			mPlotRecord->X_Scale()->SetReverse( stored_reversed_x );
			mPlotRecord->Y_Scale()->SetReverse( stored_reversed_y );
				
			Set_XScale_Marks();
			Set_YScale_Marks();
		};
	void	Set_XScale_Marks();
	void	Set_YScale_Marks();
	void	Set_Scale_Marks( LPopupButton* popup, plotRecord::scale_type t, Boolean reversed );

	LPopupButton*	GetPopup( PaneIDT paneID )
	{	LPopupButton*	popup = NULL;
		if (itsWindow)	popup = dynamic_cast <LPopupButton*> (itsWindow->FindPaneByID( paneID ));
		//ThrowIfNil_ (popup);
		return	popup;
	};

	LWindow* 		theWindow()		{	return	itsWindow;		};
	SInt32	GetPopupValue( PaneIDT paneID )						//	with LPopupButton panes
		{ 	return GetPopup( paneID )->GetValue();	}
	void	SetPopupValue( PaneIDT paneID, SInt32 inValue )		//	with LPopupButton panes
		{ 	GetPopup( paneID )->SetValue(inValue);	}
};



class CLinage;


class CLinageWindow : public CDrawWindow {
private:
	CDrawingView*	referenceView;
	CDrawingView*	distortedView;
	CDrawingView*	backgroundView;
//public:
	CLinage*		linage;
	
public:
	enum { class_ID = FOUR_CHAR_CODE('Lwin') };
	
	CLinageWindow( LStream *inStream ) : CDrawWindow( inStream )		{	linage = NULL;	};
	~CLinageWindow()	{};
	
	void	LinkLinage( CLinage* l )
		{	linage = l;
			referenceView 	= dynamic_cast<CDrawingView*>(FindPaneByID( kReferenceView ));
			distortedView	= dynamic_cast<CDrawingView*>(FindPaneByID( kSeriesView ));
			backgroundView	= dynamic_cast<CDrawingView*>(FindPaneByID( kPtrView ));
			referenceView->LinkView( this, rPPob_LinageWindow );
			distortedView->LinkView( this, rPPob_LinageWindow );
			backgroundView->LinkView( this, rPPob_LinageWindow );
		};
	void	SetUpOptionMarks();
	void	SetYScalePopup();
	
	CDrawingView*	ReferenceView()		{	return	referenceView;	};
	CDrawingView*	DistortedView()		{	return	distortedView;	};
	CDrawingView*	BackgroundView()	{	return	backgroundView;	};
	CLinage*		Linage()			{	return	linage;			};
};






