
#pragma	once

#include "myMath.h"



class FunctionTypeRecord {
private:
	unsigned long	codes[10];
public:
	FunctionTypeRecord( int fCode, int argNb=1, int unit=0, int p1=0, int p2=0, int p3=0, int p4=0, int p5=0, int p6=0, int p7=0 )
	{	codes[0] = fCode;	codes[1] = argNb;	codes[2] = unit;
		codes[3] = p1;	codes[4] = p2;	codes[5] = p3;	codes[6] = p4;	codes[7] = p5;	codes[8] = p6;	codes[9] = p7;
	}
	unsigned long	FunctionCode()			const	{	return codes[0];	};
	unsigned long	ArgNumber()				const	{	return codes[1];	};
	unsigned long	UnitCode()				const	{	return codes[2];	};
	unsigned long	ParameterCode( int i )	const	{	return codes[2+i];	};	//	i=1,...,MAX_CALC_ARG_COUNT
};

#define	MAX_CALC_ARG_COUNT	7


class	doubleFunction4 {
protected:	virtual double	func( const double, const double, const double, const double ) const = 0;
public:		virtual double	operator()( const double x1, const double x2, const double x3, const double x4 )	{	return func(x1,x2,x3,x4);	};
};

class	doubleFunction5 {
protected:	virtual double	func( const double, const double, const double, const double, const double ) const = 0;
public:		virtual double	operator()( const double x1, const double x2, const double x3, const double x4, const double x5 )	{	return func(x1,x2,x3,x4,x5);	};
};

class	doubleFunction6 {
protected:	virtual double	func( const double, const double, const double, const double, const double, const double ) const = 0;
public:		virtual double	operator()( const double x1, const double x2, const double x3, const double x4, const double x5, const double x6 )	{	return func(x1,x2,x3,x4,x5,x6);	};
};

class	doubleFunction7 {
protected:	virtual double	func( const double, const double, const double, const double, const double, const double, const double ) const = 0;
public:		virtual double	operator()( const double x1, const double x2, const double x3, const double x4, const double x5, const double x6, const double x7 )	{	return func(x1,x2,x3,x4,x5,x6,x7);	};
};



class 	Calcul;
class	doubleCalcFunction : public doubleFunction {
protected:
	typedef		double	(Calcul::*cFunc)(double);
	
	cFunc		f;
	Calcul*		calc;
	virtual double	func( const double x )	const {	return	(calc->*f)(x);	};
public:
	doubleCalcFunction( Calcul* c, cFunc f0 ):f(f0),calc(c)	{}; 
};
class	doubleCalcFunction2 : public doubleFunction2 {
protected:
	typedef		double	(Calcul::*cFunc2)(double,double);
	
	cFunc2		f;
	Calcul*		calc;
	virtual double	func( const double x, const double y )	const {	return	(calc->*f)(x,y);	};
public:
	doubleCalcFunction2( Calcul* c, cFunc2 f0 ):f(f0),calc(c)	{}; 
};
class	doubleCalcFunction3 : public doubleFunction3 {
protected:
	typedef		double	(Calcul::*cFunc3)(double,double,double);
	
	cFunc3		f;
	Calcul*		calc;
	virtual double	func( const double x, const double y, const double z )	const {	return	(calc->*f)(x,y,z);	};
public:
	doubleCalcFunction3( Calcul* c, cFunc3 f0 ):f(f0),calc(c)	{}; 
};


class Calcul	{


protected:
	doubleFunction*		CalculF1;			//	N arg functions returning double
	doubleFunction2*	CalculF2;
	doubleFunction3*	CalculF3;
	doubleFunction4*	CalculF4;
	doubleFunction5*	CalculF5;
	doubleFunction6*	CalculF6;
	doubleFunction7*	CalculF7;
	
	double	Function2( double x, double y )
	{	Check2ndVar(y);		return	(*(currentFunction()))(x);	};
	double	Function3( double x, double y, double z )
	{	Check3rdVar(z);		Check2ndVar(y);		return	(*(currentFunction()))(x);	};

	double		Func11( double x )		{	return	(*CalculF1)( x );		};
	double		Func21( double x )		{	return	(*CalculF2)( x, Param1 );		};
	double		Func22( double x )		{	return	(*CalculF2)( Param1, x );		};
	double		Func31( double x )		{	return	(*CalculF3)( x, Param1, Param2 );		};
	double		Func32( double x )		{	return	(*CalculF3)( Param1, x, Param2 );		};
	double		Func33( double x )		{	return	(*CalculF3)( Param1, Param2, x );		};
	double		Func41( double x )		{	return	(*CalculF4)( x, Param1, Param2, Param3 );		};
	double		Func42( double x )		{	return	(*CalculF4)( Param1, x, Param2, Param3 );		};
	double		Func43( double x )		{	return	(*CalculF4)( Param1, Param2, x, Param3 );		};
	double		Func44( double x )		{	return	(*CalculF4)( Param1, Param2, Param3, x );		};
	double		Func51( double x )		{	return	(*CalculF5)( x, Param1, Param2, Param3, Param4 );		};
	double		Func52( double x )		{	return	(*CalculF5)( Param1, x, Param2, Param3, Param4 );		};
	double		Func53( double x )		{	return	(*CalculF5)( Param1, Param2, x, Param3, Param4 );		};
	double		Func54( double x )		{	return	(*CalculF5)( Param1, Param2, Param3, x, Param4 );		};
	double		Func55( double x )		{	return	(*CalculF5)( Param1, Param2, Param3, Param4, x );		};
	double		Func61( double x )		{	return	(*CalculF6)( x, Param1, Param2, Param3, Param4, Param5 );		};
	double		Func62( double x )		{	return	(*CalculF6)( Param1, x, Param2, Param3, Param4, Param5 );		};
	double		Func63( double x )		{	return	(*CalculF6)( Param1, Param2, x, Param3, Param4, Param5 );		};
	double		Func64( double x )		{	return	(*CalculF6)( Param1, Param2, Param3, x, Param4, Param5 );		};
	double		Func65( double x )		{	return	(*CalculF6)( Param1, Param2, Param3, Param4, x, Param5 );		};
	double		Func66( double x )		{	return	(*CalculF6)( Param1, Param2, Param3, Param4, Param5, x );		};
	double		Func71( double x )		{	return	(*CalculF7)( x, Param1, Param2, Param3, Param4, Param5, Param6 );		};
	double		Func72( double x )		{	return	(*CalculF7)( Param1, x, Param2, Param3, Param4, Param5, Param6 );		};
	double		Func73( double x )		{	return	(*CalculF7)( Param1, Param2, x, Param3, Param4, Param5, Param6 );		};
	double		Func74( double x )		{	return	(*CalculF7)( Param1, Param2, Param3, x, Param4, Param5, Param6 );		};
	double		Func75( double x )		{	return	(*CalculF7)( Param1, Param2, Param3, Param4, x, Param5, Param6 );		};
	double		Func76( double x )		{	return	(*CalculF7)( Param1, Param2, Param3, Param4, Param5, x, Param6 );		};
	double		Func77( double x )		{	return	(*CalculF7)( Param1, Param2, Param3, Param4, Param5, Param6, x );		};
	
protected:
	Calcul()	: CalculF1(NULL), CalculF2(NULL), CalculF3(NULL), CalculF4(NULL), CalculF5(NULL), CalculF6(NULL), CalculF7(NULL)		{};
	virtual ~Calcul()	{	delete CalculF1;  delete CalculF2;  delete CalculF3;  delete CalculF4;  delete CalculF5;  delete CalculF6;  delete CalculF7;	};
	
	void	SetF1( doubleFunction* f )		{	delete CalculF1;	CalculF1 = f; 	};
	void	SetF2( doubleFunction2* f )		{	delete CalculF2;	CalculF2 = f; 	};
	void	SetF3( doubleFunction3* f )		{	delete CalculF3;	CalculF3 = f; 	};
	void	SetF4( doubleFunction4* f )		{	delete CalculF4;	CalculF4 = f; 	};
	void	SetF5( doubleFunction5* f )		{	delete CalculF5;	CalculF5 = f; 	};
	void	SetF6( doubleFunction6* f )		{	delete CalculF6;	CalculF6 = f; 	};
	void	SetF7( doubleFunction7* f )		{	delete CalculF7;	CalculF7 = f; 	};
	
	doubleFunction*	FuncWithArg( int fCode, int pCode )
	{	switch ( ArgCount( fCode ) )
		{	case 1:								return	new doubleCalcFunction( this, &Calcul::Func11 );
			case 2:	switch (pCode)	{	case 1:	return	new doubleCalcFunction( this, &Calcul::Func21 );
										case 2:	return	new doubleCalcFunction( this, &Calcul::Func22 );	}
			case 3:	switch (pCode)	{	case 1:	return	new doubleCalcFunction( this, &Calcul::Func31 );
										case 2:	return	new doubleCalcFunction( this, &Calcul::Func32 );
										case 3:	return	new doubleCalcFunction( this, &Calcul::Func33 );	}
			case 4:	switch (pCode)	{	case 1:	return	new doubleCalcFunction( this, &Calcul::Func41 );
										case 2:	return	new doubleCalcFunction( this, &Calcul::Func42 );
										case 3:	return	new doubleCalcFunction( this, &Calcul::Func43 );
										case 4:	return	new doubleCalcFunction( this, &Calcul::Func44 );	}
			case 5:	switch (pCode)	{	case 1:	return	new doubleCalcFunction( this, &Calcul::Func51 );
										case 2:	return	new doubleCalcFunction( this, &Calcul::Func52 );
										case 3:	return	new doubleCalcFunction( this, &Calcul::Func53 );
										case 4:	return	new doubleCalcFunction( this, &Calcul::Func54 );
										case 5:	return	new doubleCalcFunction( this, &Calcul::Func55 );	}
			case 6:	switch (pCode)	{	case 1:	return	new doubleCalcFunction( this, &Calcul::Func61 );
										case 2:	return	new doubleCalcFunction( this, &Calcul::Func62 );
										case 3:	return	new doubleCalcFunction( this, &Calcul::Func63 );
										case 4:	return	new doubleCalcFunction( this, &Calcul::Func64 );
										case 5:	return	new doubleCalcFunction( this, &Calcul::Func65 );
										case 6:	return	new doubleCalcFunction( this, &Calcul::Func66 );	}
			case 7:	switch (pCode)	{	case 1:	return	new doubleCalcFunction( this, &Calcul::Func71 );
										case 2:	return	new doubleCalcFunction( this, &Calcul::Func72 );
										case 3:	return	new doubleCalcFunction( this, &Calcul::Func73 );
										case 4:	return	new doubleCalcFunction( this, &Calcul::Func74 );
										case 5:	return	new doubleCalcFunction( this, &Calcul::Func75 );
										case 6:	return	new doubleCalcFunction( this, &Calcul::Func76 );
										case 7:	return	new doubleCalcFunction( this, &Calcul::Func77 );	}
		}
		return	NULL;
	}
								
private:
	int		p_code2;
	int		p_code3;
	double 	last_y;
	double 	last_z;
	doubleFunction*	multiDFunc;
	
private:
	double	Param1, Param2, Param3, Param4, Param5, Param6;
	
protected:
	virtual	doubleFunction*		GFunc( int fCode, int pCode ) = 0;
	
	doubleFunction2*	GFunc2()	{	return	new doubleCalcFunction2( this, &Calcul::Function2 );	};
	doubleFunction3*	GFunc3()	{	return	new doubleCalcFunction3( this, &Calcul::Function3 );	};
	
	void	SetParams( double p1=0, double p2=0, double p3=0, double p4=0, double p5=0, double p6=0 )
		{	Param1 = p1;	Param2 = p2;	Param3 = p3;	Param4 = p4;	Param5 = p5;	Param6 = p6;	}
	void	Set2ndParams( int pCode1=1, int pCode2=2, double p1=0, double p2=0, double p3=0, double p4=0, double p5=0 )
		{	p_code2	= ( pCode2>pCode1 ? pCode2-1 : pCode2 );
			switch (p_code2)	{
				case 1:		SetParams( 0, p1, p2, p3, p4, p5 );	break;
				case 2:		SetParams( p1, 0, p2, p3, p4, p5 );	break;
				case 3:		SetParams( p1, p2, 0, p3, p4, p5 );	break;
				case 4:		SetParams( p1, p2, p3, 0, p4, p5 );	break;
				case 5:		SetParams( p1, p2, p3, p4, 0, p5 );	break;
				case 6:		SetParams( p1, p2, p3, p4, p5, 0 );	break;
			};
		}
	void	Set2nd3rdParams( int pCode1=1, int pCode2=2, int pCode3=3, double p1=0, double p2=0, double p3=0, double p4=0 )
	{	p_code2	= ( pCode2>pCode1 ? pCode2-1 : pCode2 );
		p_code3	= ( pCode3>pCode1 ? pCode3-1 : pCode3 );
		int		sum = p_code2 + p_code3;
		int		dif = ( p_code2 > p_code3  ?  p_code2 - p_code3  :  p_code3 - p_code2 );
		
		switch (sum)	{
			case 3:		SetParams( 0, 0, p1, p2, p3, p4 );	break;		//	1 et 2
			case 4:		SetParams( 0, p1, 0, p2, p3, p4 );	break;		//	1 et 3
			case 5:		switch (dif)	{													//	2 et 3 ou 1 et 4
							case 3:		SetParams( 0, p1, p2, 0, p3, p4 );		break;		//	1 et 4
							case 1:		SetParams( p1, 0, 0, p2, p3, p4 );		break;		//	2 et 3
						}	break;
			case 6:		switch (dif)	{													//	2 et 4 ou 1 et 5
							case 4:		SetParams( 0, p1, p2, p3, 0, p4 );		break;		//	1 et 5
							case 2:		SetParams( p1, 0, p2, 0, p3, p4 );		break;		//	2 et 4
						}	break;
			case 7:		switch (dif)	{													//	3 et 4 ou 2 et 5 ou 1 et 6
							case 5:		SetParams( 0, p1, p2, p3, p4, 0 );		break;		//	1 et 6
							case 3:		SetParams( p1, 0, p2, p3, 0, p4 );		break;		//	2 et 5
							case 1:		SetParams( p1, p2, 0, 0, p3, p4 );		break;		//	3 et 4
						}	break;
			case 8:		switch (dif)	{													//	2 et 6 ou 3 et 5
							case 2:		SetParams( p1, p2, 0, p3, 0, p4 );		break;		//	3 et 5
							case 4:		SetParams( p1, 0, p2, p3, p4, 0 );		break;		//	2 et 6
						}	break;
			case 9:		switch (dif)	{													//	3 et 6 ou 4 et 5
							case 3:		SetParams( p1, p2, 0, p3, p4, 0 );		break;		//	3 et 6
							case 1:		SetParams( p1, p2, p3, 0, 0, p4 );		break;		//	4 et 5
						}	break;
			case 10:	SetParams( p1, p2, p3, 0, p4, 0 );	break;		//	4 et 6
			case 11:	SetParams( p1, p2, p3, p4, 0, 0 );	break;		//	5 et 6
		};
	}
	void	SetParamTo( int p_code, double y )
		{	switch (p_code)	{
				case 1:	Param1 = y;	break;
				case 2:	Param2 = y;	break;
				case 3:	Param3 = y;	break;
				case 4:	Param4 = y;	break;
				case 5:	Param5 = y;	break;
				case 6:	Param6 = y;	break;
		}	};
	void	Set2ndVariableTo( double y )	{	SetParamTo( p_code2, y );	};
	void	Set3rdVariableTo( double z )	{	SetParamTo( p_code3, z );	};
	
public:
	doubleFunction*		GlobalFunc( int fCode, int pCode=1, double p1=0, double p2=0, double p3=0, double p4=0, double p5=0, double p6=0 )
		{	SetParams( p1, p2, p3, p4, p5, p6 );
			return	GFunc( fCode, pCode );
		}
	doubleFunction2*	GlobalFunc2( int fCode, int pCode1=1, int pCode2=2, double p1=0, double p2=0, double p3=0, double p4=0, double p5=0 )
		{	multiDFunc	= GFunc( fCode, pCode1 );
			Set2ndParams( pCode1, pCode2, p1, p2, p3, p4, p5 );
			return	GFunc2();
		}
	doubleFunction3*	GlobalFunc3( int fCode, int pCode1=1, int pCode2=2, int pCode3=3, double p1=0, double p2=0, double p3=0, double p4=0 )
		{	multiDFunc	= GFunc( fCode, pCode1 );
			Set2nd3rdParams( pCode1, pCode2, pCode3, p1, p2, p3, p4 );
			return	GFunc3();
		}

	void	Check2ndVar( double y )		{	if (y != last_y)	{	last_y = y;	Set2ndVariableTo( y );	}	};
	void	Check3rdVar( double z )		{	if (z != last_z)	{	last_z = z;	Set3rdVariableTo( z );	}	};
	
	doubleFunction*	currentFunction()		{	return	multiDFunc;	};
		
	virtual	int		ArgCount( unsigned long fCode ) = 0;
};



class 	CalculAstro;
class	doubleAstroFunction : public doubleFunction {
protected:
	typedef		double	(CalculAstro::*astroFunc)(double);
	
	astroFunc		f;
	CalculAstro*	astro;
	virtual double	func( const double x )	const {	return	(astro->*f)(x);	};
public:
	doubleAstroFunction( CalculAstro* as, astroFunc f0 ):f(f0),astro(as)	{}; 
};


class CalculAstro	: public Calcul {
public:
	Boolean	timeTowardsPast;	//	true
	Boolean	timeInKyr;			//	true
	double	precessPhase;
	
	enum functionCode { obliquity_func, eccentricity_func, climaticPrec_func, climaticSinPrec_func };

public:	
	virtual	int		ArgCount( unsigned long )		//	( unsigned long fCode )
		{	return	1;	};
		
protected:
	virtual	doubleFunction*		GFunc( int fCode, int pCode )
		{	switch (fCode)	{
				case	obliquity_func:			SetF1( new doubleAstroFunction( this, &CalculAstro::Obliquity ) );			break;
				case	eccentricity_func:		SetF1( new doubleAstroFunction( this, &CalculAstro::Eccentricity ) );		break;
				case	climaticPrec_func:		SetF1( new doubleAstroFunction( this, &CalculAstro::ClimaticPrecAngle ) );	break;
				case	climaticSinPrec_func:	SetF1( new doubleAstroFunction( this, &CalculAstro::ClimaticSinPrec ) );	break;
			};
			return	FuncWithArg( fCode, pCode );
		};
		
public:
	CalculAstro()		{	timeTowardsPast = timeInKyr = true;		precessPhase = 180;	};
	
	virtual	double	Obliquity( double t )		= 0;
	virtual	double	Eccentricity( double t )	= 0;
	virtual	double	ClimaticPrec( double t )	= 0;				//	used internally. ANgle + 180 (cf Berger)
	
	void	SetTimeInKyr( Boolean inKyr )			{	timeInKyr = inKyr;			};
	void	SetTimeTowardPast( Boolean inPast )		{	timeTowardsPast = inPast;	};
	void	SetPrecessionParamPhase( double ph )	{	precessPhase = ph;			};		//	(Berger = 180, standard = 0, ...)
	
	double	ClimaticSinPrec( double t )
			{	double	e = Eccentricity( t );
				double	p = ClimaticPrec( t ) + precessPhase - 180;
				return	( e * std::sin( p * MyMath::PiSur180 ) );		//	used internally. Angle + 180 (cf Berger)
			};
	double	ClimaticPrecAngle( double t )
			{	double	perh = ClimaticPrec( t ) + precessPhase - 180;			// + 180;				//	long. perhelion + �
				while (perh < 0)		perh += 360;
				while (perh >= 360)		perh -= 360;
				return	perh;
			};

	void	AstroClimParams( double t, double& ecc, double& perh, double& pre, double& xob )
	{	ecc	 = Eccentricity( t );				//	= e (eccentricity)
		perh = ClimaticPrec( t );				//	long. perhelion
		xob	 = Obliquity( t );					//	 obliquity
		pre  = ecc * std::sin( perh * MyMath::PiSur180 );	//	prec. param. = e sin(long. perhelion)
		
	};
	
	double	TimeInPastKyr( double t )						//	used by Laskar 90
			{	double tt = (timeTowardsPast ? t : -t);
				return	(timeInKyr ? tt : tt / 1000);
			};
	double	TimeInFutureYr( double t )						//	used by Berger 78
			{	double tt = (timeTowardsPast ? -t : t);
				return	(timeInKyr ? tt * 1000 : tt);
			};
	virtual	Boolean	TimeInAcceptableRange( double t )	= 0;
	virtual	char*	Name()	= 0;
	virtual	char*	Reference()	= 0;
	
	char*	UnitName()
			{	if (timeTowardsPast)	{	if (timeInKyr)	return "kyr BP";	else return "years BP";	}
				else					{	if (timeInKyr)	return "kyr AP";	else return "years AP";	}
			};
			
	virtual	double	FirstAbs()	{	return	0;	};
	virtual	double	LastAbs()	{	return	0;	};
};



class CalcAstro_Table : public CalculAstro	{

private:

	virtual MyMath::double_regular_array&		Absc() = 0;
	virtual MyMath::splin_interpolfunc&			EccSpl() = 0;
	virtual MyMath::splin_interpolfunc&			OblSpl() = 0;
	virtual MyMath::lin_interpol_y_cyclicfunc&	Precess() = 0;
					
public:

	CalcAstro_Table()	{};
		
	virtual	double	Obliquity( double t )
		{	double	tt = TimeInPastKyr( t );			MyMath::ThrowErrorIf( tt < FirstAbs() || tt > LastAbs() );
			return	OblSpl().ValueAt( tt )/MyMath::PiSur180;
		};
	virtual	double	Eccentricity( double t )
		{	double	tt = TimeInPastKyr( t );			MyMath::ThrowErrorIf( tt < FirstAbs() || tt > LastAbs() );
			return	EccSpl().ValueAt( tt );
		};
	virtual	double	ClimaticPrec( double t )
		{	double	tt = TimeInPastKyr( t );			MyMath::ThrowErrorIf( tt < FirstAbs() || tt > LastAbs() );
			return	Precess().ValueAt( tt )/MyMath::PiSur180;
		};
	
	virtual	Boolean	TimeInAcceptableRange( double t )
		{	double	tt = TimeInPastKyr(t);	return	((FirstAbs()<=tt) && (LastAbs()>=tt));	};
};

class CalcAstro_LA04 : public CalcAstro_Table	{

private:

//		Laskar 2004

	static	const	double			First_Absc04;		//	defined in Ecc.cp
	static	const	double			Last_Absc04;		//	defined in Ecc.cp
	static	const	unsigned long	NbValue_LA04;		//	defined in Ecc.cp

	static	double	Ecc_LA04[];					//	defined in Ecc.cp
	static	double	Obl_LA04[];					//	defined in Obl.cp
	static	double	Pre_LA04[];					//	defined in Pre.cp
	
	MyMath::double_regular_array			Abscissa;
	MyMath::splin_interpolfunc				EccSpline;
	MyMath::splin_interpolfunc				OblSpline;
	MyMath::lin_interpol_y_cyclicfunc		PrecLine;
	
	virtual MyMath::double_regular_array&		Absc() 		{	return Abscissa;	};
	virtual MyMath::splin_interpolfunc&			EccSpl() 	{	return EccSpline;	};
	virtual MyMath::splin_interpolfunc&			OblSpl() 	{	return OblSpline;	};
	virtual MyMath::lin_interpol_y_cyclicfunc&	Precess() 	{	return PrecLine;	};
					
public:

	CalcAstro_LA04() : Abscissa( First_Absc04, Last_Absc04, NbValue_LA04 ),
			EccSpline( Abscissa, Ecc_LA04 ),
			OblSpline( Abscissa, Obl_LA04 ),
			PrecLine( 0, MyMath::DeuxPi, Abscissa, Pre_LA04 )	{};
		
	virtual	char*	Name()			{	return	"Laskar 2004";	};	
	virtual	char*	Reference()		{	return	"Laskar J. et al. (2004), A&A, 428: 261-285";	};
	virtual	double	FirstAbs()		{	return	First_Absc04;	};
	virtual	double	LastAbs()		{	return	Last_Absc04;	};
};

class CalcAstro_LA93_0 : public CalcAstro_Table	{

private:

//		Laskar 2004

	static	const	double			First_Absc93_0;		//	defined in Ecc.cp
	static	const	double			Last_Absc93_0;		//	defined in Ecc.cp
	static	const	unsigned long	NbValue_LA93_0;		//	defined in Ecc.cp

	static	double	Ecc_LA93_0[];					//	defined in Ecc.cp
	static	double	Obl_LA93_0[];					//	defined in Obl.cp
	static	double	Pre_LA93_0[];					//	defined in Pre.cp
	
	MyMath::double_regular_array			Abscissa;
	MyMath::splin_interpolfunc				EccSpline;
	MyMath::splin_interpolfunc				OblSpline;
	MyMath::lin_interpol_y_cyclicfunc		PrecLine;
	
	virtual MyMath::double_regular_array&		Absc() 		{	return Abscissa;	};
	virtual MyMath::splin_interpolfunc&			EccSpl() 	{	return EccSpline;	};
	virtual MyMath::splin_interpolfunc&			OblSpl() 	{	return OblSpline;	};
	virtual MyMath::lin_interpol_y_cyclicfunc&	Precess() 	{	return PrecLine;	};
					
public:

	CalcAstro_LA93_0() : Abscissa( First_Absc93_0, Last_Absc93_0, NbValue_LA93_0 ),
			EccSpline( Abscissa, Ecc_LA93_0 ),
			OblSpline( Abscissa, Obl_LA93_0 ),
			PrecLine( 0, MyMath::DeuxPi, Abscissa, Pre_LA93_0 )	{};
		
	virtual	char*	Name()			{	return	"Laskar 1993(0,1)";	};	
	virtual	char*	Reference()		{	return	"Laskar J. et al. (1993), ...";	};
	virtual	double	FirstAbs()		{	return	First_Absc93_0;	};
	virtual	double	LastAbs()		{	return	Last_Absc93_0;	};
};

class CalcAstro_LA93_1 : public CalcAstro_Table	{

private:

//		Laskar 2004

	static	const	double			First_Absc93_1;		//	defined in Ecc.cp
	static	const	double			Last_Absc93_1;		//	defined in Ecc.cp
	static	const	unsigned long	NbValue_LA93_1;		//	defined in Ecc.cp

	static	double	Ecc_LA93_1[];					//	defined in Ecc.cp
	static	double	Obl_LA93_1[];					//	defined in Obl.cp
	static	double	Pre_LA93_1[];					//	defined in Pre.cp
	
	MyMath::double_regular_array			Abscissa;
	MyMath::splin_interpolfunc				EccSpline;
	MyMath::splin_interpolfunc				OblSpline;
	MyMath::lin_interpol_y_cyclicfunc		PrecLine;
	
	virtual MyMath::double_regular_array&		Absc() 		{	return Abscissa;	};
	virtual MyMath::splin_interpolfunc&			EccSpl() 	{	return EccSpline;	};
	virtual MyMath::splin_interpolfunc&			OblSpl() 	{	return OblSpline;	};
	virtual MyMath::lin_interpol_y_cyclicfunc&	Precess() 	{	return PrecLine;	};
					
public:

	CalcAstro_LA93_1() : Abscissa( First_Absc93_1, Last_Absc93_1, NbValue_LA93_1 ),
			EccSpline( Abscissa, Ecc_LA93_1 ),
			OblSpline( Abscissa, Obl_LA93_1 ),
			PrecLine( 0, MyMath::DeuxPi, Abscissa, Pre_LA93_1 )	{};
		
	virtual	char*	Name()			{	return	"Laskar 1993(1,1)";	};	
	virtual	char*	Reference()		{	return	"Laskar J. et al. (1993), ...";	};
	virtual	double	FirstAbs()		{	return	First_Absc93_1;	};
	virtual	double	LastAbs()		{	return	Last_Absc93_1;	};
};




class CalcAstro_BER78 : public CalculAstro	{

public:
	CalcAstro_BER78();
	
	virtual	double	Obliquity( double t );
	virtual	double	Eccentricity( double t );
	virtual	double	ClimaticPrec( double t );
	
private:

//		Berger 78

	static	const	int		NbEccCst_BER78;
	static	const	int		NbObliqCst_BER78;
	static	const	int		NbPrecCst_BER78;
	
	static	const	double	ObliqCst_BER78;
	static	const	double	GenPrecCst1_BER78;
	static	const	double	GenPrecCst2_BER78;
	
	static	const	double	EccA_BER78[];
	static	const	double	EccB_BER78[];
	static	const	double	EccC_BER78[];
	static	const	double	OblA_BER78[];
	static	const	double	OblB_BER78[];
	static	const	double	OblC_BER78[];
	static	const	double	PreA_BER78[];
	static	const	double	PreB_BER78[];
	static	const	double	PreC_BER78[];
	
	double_vector0	ae;
	double_vector0	be;
	double_vector0	ce;
	double_vector0	aob;
	double_vector0	bob;
	double_vector0	cob;
	double_vector0	aop;
	double_vector0	bop;
	double_vector0	cop;
	
	void	EccAndPi_BER78( double t, double& xes, double& xec );
	double	GeneralPrec_BER78( double t );
	double	ClimaticPrec_BER78( double t, double xes, double xec );

	virtual	Boolean	TimeInAcceptableRange( double )	{	return	true;	};
	virtual	char*	Name()			{	return	"Berger 1978";	};
	virtual	char*	Reference()		{	return	"Berger A. (1978), J. Atmos. Sci., 35: 2362-2367";	};
};



typedef	char*	charPtr;
typedef	double	threeDouble[3];





class 	CalculInso;
class	doubleInsoFunction3 : public doubleFunction3 {
protected:
	typedef		double	(CalculInso::*insoFunc)(double,double,double);
	insoFunc	f;
	CalculInso*	inso;
	virtual double	func( const double x, const double y, const double z )	const {	return	(inso->*f)(x,y,z);	};
public:
	doubleInsoFunction3( CalculInso* in, insoFunc f0 ):f(f0),inso(in)	{}; 
};
class	doubleInsoFunction4 : public doubleFunction4 {
protected:
	typedef		double	(CalculInso::*insoFunc)(double,double,double,double);
	insoFunc	f;
	CalculInso*	inso;
	virtual double	func( const double x1, const double x2, const double x3, const double x4 )	const {	return	(inso->*f)(x1,x2,x3,x4);	};
public:
	doubleInsoFunction4( CalculInso* in, insoFunc f0 ):f(f0),inso(in)	{}; 
};
class	doubleInsoFunction5 : public doubleFunction5 {
protected:
	typedef		double	(CalculInso::*insoFunc)(double,double,double,double,double);
	insoFunc	f;
	CalculInso*	inso;
	virtual double	func( const double x1, const double x2, const double x3, const double x4, const double x5 )	const {	return	(inso->*f)(x1,x2,x3,x4,x5);	};
public:
	doubleInsoFunction5( CalculInso* in, insoFunc f0 ):f(f0),inso(in)	{}; 
};
class	doubleInsoFunction6 : public doubleFunction6 {
protected:
	typedef		double	(CalculInso::*insoFunc)(double,double,double,double,double,double);
	insoFunc	f;
	CalculInso*	inso;
	virtual double	func( const double x1, const double x2, const double x3, const double x4, const double x5, const double x6 )	const {	return	(inso->*f)(x1,x2,x3,x4,x5,x6);	};
public:
	doubleInsoFunction6( CalculInso* in, insoFunc f0 ):f(f0),inso(in)	{}; 
};

class	doubleInsoFunction7 : public doubleFunction7 {
protected:
	typedef		double	(CalculInso::*insoFunc)(double,double,double,double,double,double,double);
	insoFunc	f;
	CalculInso*	inso;
	virtual double	func( const double x1, const double x2, const double x3, const double x4, const double x5, const double x6, const double x7 )	const {	return	(inso->*f)(x1,x2,x3,x4,x5,x6,x7);	};
public:
	doubleInsoFunction7( CalculInso* in, insoFunc f0 ):f(f0),inso(in)	{}; 
};

class CalculInso	: public Calcul {
public:

	enum functionCode {			//	functions of true longitude (season)
						daylyInso_time_func,		//	function of geologic time (1), season (2), latitude (3)
						meanInso_time_func,			//	function of geologic time (1), start season (2), end season (3), latitude (4)
						meanIrrad_time_func,		//	function of geologic time (1), start season (2), end season (3), latitude (4)
						seasonLength_time_func,		//	function of geologic time (1), start season (2), end season (3)
						daylyCosz_time_func,		//	function of geologic time (1), season (2), latitude (3)
						dayLength_time_func,		//	function of geologic time (1), season (2), latitude (3)
						meanLatInso_time_func,		//	function of geologic time (1), season (2), start latitude (3), end latitude (4)
						instantInso_time_func,		//	function of geologic time (1), season (2), latitude (3), hour angle (4)
//	8 - 8
						daylyInso_time_ecc_func,		//	function of geologic time (1), eccentricity(2), season (3), latitude (4)
						meanInso_time_ecc_func,			//	function of geologic time (1), eccentricity(2), start season (3), end season (4), latitude (5)
						meanIrrad_time_ecc_func,		//	function of geologic time (1), eccentricity(2), start season (3), end season (4), latitude (5)
						seasonLength_time_ecc_func,		//	function of geologic time (1), eccentricity(2), start season (3), end season (4)
						meanLatInso_time_ecc_func,		//	function of geologic time (1), eccentricity(2), season (3), start latitude (4), end latitude (5)
						instantInso_time_ecc_func,		//	function of geologic time (1), eccentricity(2), season (3), latitude (4), hour angle (5)
//	6 - 14
						daylyInso_time_ecc_obl_func,		//	function of geologic time (1), eccentricity(2), obliquity (3), season (4), latitude (5)
						meanInso_time_ecc_obl_func,			//	function of geologic time (1), eccentricity(2), obliquity (3), start season (4), end season (5), latitude (6)
						meanLatInso_time_ecc_obl_func,		//	function of geologic time (1), eccentricity(2), obliquity (3), season (4), start latitude (5), end latitude (6)
						instantInso_time_ecc_obl_func,		//	function of geologic time (1), eccentricity(2), obliquity (3), season (4), latitude (5), hour angle (6)
//	4 - 18
						daylyInso_time_ecc_pre_func,		//	function of geologic time (1), eccentricity(2), climatic prec. (3), season (4), latitude (5)
						meanInso_time_ecc_pre_func,			//	function of geologic time (1), eccentricity(2), climatic prec. (3), start season (4), end season (5), latitude (6)
						meanLatInso_time_ecc_pre_func,		//	function of geologic time (1), eccentricity(2), climatic prec. (3), season (4), start latitude (5), end latitude (6)
						instantInso_time_ecc_pre_func,		//	function of geologic time (1), eccentricity(2), climatic prec. (3), season (4), latitude (5), hour angle (6)
//	4 - 22
						daylyInso_time_pre_func,		//	function of geologic time (1), climatic prec.(2), season (3), latitude (4)
						meanInso_time_pre_func,			//	function of geologic time (1), climatic prec.(2), start season (3), end season (4), latitude (5)
						seasonLength_time_pre_func,		//	function of geologic time (1), climatic prec.(2), start season (3), end season (4)
						meanLatInso_time_pre_func,		//	function of geologic time (1), climatic prec.(2), season (3), start latitude (4), end latitude (5)
						instantInso_time_pre_func,		//	function of geologic time (1), climatic prec.(2), season (3), latitude (4), hour angle (5)
//	5 - 27
						daylyInso_time_pre_obl_func,		//	function of geologic time (1), climatic prec.(2), obliquity (3), season (4), latitude (5)
						meanInso_time_pre_obl_func,			//	function of geologic time (1), climatic prec.(2), obliquity (3), start season (4), end season (5), latitude (6)
						meanLatInso_time_pre_obl_func,		//	function of geologic time (1), climatic prec.(2), obliquity (3), season (4), start latitude (5), end latitude (6)
						instantInso_time_pre_obl_func,		//	function of geologic time (1), climatic prec.(2), obliquity (3), season (4), latitude (5), hour angle (6)
//	4 - 31
						daylyInso_time_obl_func,		//	function of geologic time (1), obliquity(2), season (3), latitude (4)
						meanInso_time_obl_func,			//	function of geologic time (1), obliquity(2), start season (3), end season (4), latitude (5)
						meanIrrad_time_obl_func,		//	function of geologic time (1), obliquity(2), start season (3), end season (4), latitude (5)
						meanLatInso_time_obl_func,		//	function of geologic time (1), obliquity(2), season (3), start latitude (4), end latitude (5)
						instantInso_time_obl_func,		//	function of geologic time (1), obliquity(2), season (3), latitude (4), hour angle (5)
//	5 - 36
						daylyInso_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), season (4), latitude (5)
						meanInso_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), start season (4), end season (5), latitude (6)
						meanIrrad_astro_func,		//	function of eccentricity (1), obliquity (2), start season (3), end season (4), latitude (5)
						seasonLength_astro_func,	//	function of eccentricity (1), climatic prec. (2), start season (3), end season (4)
						daylyCosz_astro_func,		//	function of obliquity (1), season (2), latitude (3)
						dayLength_astro_func,		//	function of obliquity (1), season (2), latitude (3)
						meanLatInso_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), season (4), start latitude (5), end latitude (6)
						instantInso_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), season (4), latitude (5), hour angle (6)
//	8 - 44
					  		//	functions of mean longitude (time from ref. season) -> add reference season as parameter
						daylyInso_M_time_func,		//	function of geologic time (1), season (2), latitude (3)
						meanInso_M_time_func,		//	function of geologic time (1), start season (2), end season (3), latitude (4)
						meanIrrad_M_time_func,		//	function of geologic time (1), start season (2), end season (3), latitude (4)
						daylyCosz_M_time_func,		//	function of geologic time (1), season (2), latitude (3)
						dayLength_M_time_func,		//	function of geologic time (1), season (2), latitude (3)
						meanLatInso_M_time_func,	//	function of geologic time (1), season (2), start latitude (3), end latitude (4)
						instantInso_M_time_func,	//	function of geologic time (1), season (2), latitude (3), hour angle (4)
//	7 - 51
						daylyInso_M_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), season (4), latitude (5)
						meanInso_M_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), start season (4), end season (5), latitude (6)
						meanIrrad_M_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), start season (4), end season (5), latitude (6)
						daylyCosz_M_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), season (4), latitude (5)
						dayLength_M_astro_func,		//	function of eccentricity (1), climatic prec. (2), obliquity (3), season (4), latitude (5)
						meanLatInso_M_astro_func,	//	function of eccentricity (1), climatic prec. (2), obliquity (3), season (4), start latitude (5), end latitude (6)
						instantInso_M_astro_func,	//	function of eccentricity (1), climatic prec. (2), obliquity (3), season (4), latitude (5), hour angle (6)
//	7 - 58
						irrad_Threshold_time_func,
						irrad_Threshold_astro_func,
						
					  	bad_func		//	sometimes usefull
					};
					
/*	enum paramOptionCode {
						fn_of_eccentricity,		//	instead of geologic time
						fn_of_obliquity,		//	instead of geologic time
						fn_of_precession,		//	instead of geologic time
						fn_of_orbitalTime		//	instead of orbital angle
					};
*/					
	enum funcUnitCode {
						watts_per_m2,
						megaJoule_per_m2,
						days,
						hours,
						unitless_0_1					//	dimensionless between 0 and 1
					};
						
	enum parameterCode {	time_param,				//	geologic time
							eccentricity_param,		//	eccentricity
							precession_param,		//	precession
							obliquity_param,		//	obliquity
							season_param,			//	season
							latitude_param,			//	latitude
							season_start_param,		//	start season
							season_end_param,		//	end season
							latitude_start_param,	//	start latitude
							latitude_end_param,		//	end latitude
							hour_param,				//	hour angle
							seasontime_param,		//	time from ref. season
							seasontime_start_param,	//	start time from ref. season
							seasontime_end_param,	//	end time from ref. season
							ref_season_param,		//	reference season
							inso_threshold_param,	//	daily insolation threshold (Wm-2) for Irrad above threshold
							solar_constant,			//	the solar constant: not a direct parameter of functions (stupid to use as a scale...)
							
					  		bad_param		//	sometimes usefull
					  };
	
	static const FunctionTypeRecord	functionDefCode[];
	static const charPtr			unitName[];
	static const charPtr			parameterName[];
	static const charPtr			parameterUnit[];
	static const threeDouble		parameterValues[];		//	min, max, default
	static const unsigned long		numberOfFunc  = 60;		//58;
	static const unsigned long		numberOfParam = 17;		//16;

public:

	const FunctionTypeRecord&	FunctionCodes( unsigned long fCode )
		{	if (fCode == functionDefCode[fCode].FunctionCode() )	return	functionDefCode[fCode];		//	a priori, codes bien classe, mais...
			else
			{	unsigned long	i  = 0;
				while (i<numberOfFunc && fCode != functionDefCode[i].FunctionCode()) i++;
				if (fCode == functionDefCode[i].FunctionCode() )	return	functionDefCode[i];
				else	return	functionDefCode[0];
			}
		};
		
	virtual int		ArgCount( unsigned long fCode )							{	return FunctionCodes( fCode ).ArgNumber();				};
	parameterCode	Parameter( unsigned long fCode, unsigned long pCode )	{	return (parameterCode)FunctionCodes( fCode ).ParameterCode( pCode<MAX_CALC_ARG_COUNT ? pCode+1 : 1 );	};
	funcUnitCode	UnitCode( unsigned long fCode )							{	return (funcUnitCode)FunctionCodes( fCode ).UnitCode();	};


protected:
	virtual	doubleFunction*	GFunc( int fCode, int pCode )
		{	switch (fCode)	{
				case	daylyInso_time_func:		SetF3( new doubleInsoFunction3( this, &CalculInso::DaylyInso ) );			break;
				case	meanInso_time_func:			SetF4( new doubleInsoFunction4( this, &CalculInso::MeanInso ) );			break;
				case	meanIrrad_time_func:		SetF4( new doubleInsoFunction4( this, &CalculInso::MeanIrrad_MJm2 ) );		break;
				case	seasonLength_time_func:		SetF3( new doubleInsoFunction3( this, &CalculInso::SeasonLengthInDays ) );	break;
				case	daylyCosz_time_func:		SetF3( new doubleInsoFunction3( this, &CalculInso::DaylyMeanCosz ) );		break;
				case	dayLength_time_func:		SetF3( new doubleInsoFunction3( this, &CalculInso::DayLength ) );			break;
				case	meanLatInso_time_func:		SetF4( new doubleInsoFunction4( this, &CalculInso::MeanLatDaylyInso ) );	break;
				case	instantInso_time_func:		SetF4( new doubleInsoFunction4( this, &CalculInso::InstantaneousInso ) );	break;
				
				case	daylyInso_time_ecc_func:	SetF4( new doubleInsoFunction4( this, &CalculInso::DaylyInso_E ) );			break;
				case	meanInso_time_ecc_func:		SetF5( new doubleInsoFunction5( this, &CalculInso::MeanInso_E ) );			break;
				case	meanIrrad_time_ecc_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::MeanIrrad_MJm2_E ) );	break;
				case	seasonLength_time_ecc_func:	SetF4( new doubleInsoFunction4( this, &CalculInso::SeasonLengthInDays_E ) );break;
				case	meanLatInso_time_ecc_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::MeanLatDaylyInso_E ) );	break;
				case	instantInso_time_ecc_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::InstantaneousInso_E ) );	break;
				
				case	daylyInso_time_ecc_obl_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::DaylyInso_EO ) );			break;
				case	meanInso_time_ecc_obl_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::MeanInso_EO ) );				break;
				case	meanLatInso_time_ecc_obl_func:	SetF6( new doubleInsoFunction6( this, &CalculInso::MeanLatDaylyInso_EO ) );		break;
				case	instantInso_time_ecc_obl_func:	SetF6( new doubleInsoFunction6( this, &CalculInso::InstantaneousInso_EO ) );	break;
				
				case	daylyInso_time_ecc_pre_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::DaylyInso_EP ) );			break;
				case	meanInso_time_ecc_pre_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::MeanInso_EP ) );				break;
				case	meanLatInso_time_ecc_pre_func:	SetF6( new doubleInsoFunction6( this, &CalculInso::MeanLatDaylyInso_EP ) );		break;
				case	instantInso_time_ecc_pre_func:	SetF6( new doubleInsoFunction6( this, &CalculInso::InstantaneousInso_EP ) );	break;
				
				case	daylyInso_time_pre_func:	SetF4( new doubleInsoFunction4( this, &CalculInso::DaylyInso_P ) );			break;
				case	meanInso_time_pre_func:		SetF5( new doubleInsoFunction5( this, &CalculInso::MeanInso_P ) );			break;
				case	seasonLength_time_pre_func:	SetF4( new doubleInsoFunction4( this, &CalculInso::SeasonLengthInDays_P ) );break;
				case	meanLatInso_time_pre_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::MeanLatDaylyInso_P ) );	break;
				case	instantInso_time_pre_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::InstantaneousInso_P ) );	break;
				
				case	daylyInso_time_pre_obl_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::DaylyInso_PO ) );			break;
				case	meanInso_time_pre_obl_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::MeanInso_PO ) );				break;
				case	meanLatInso_time_pre_obl_func:	SetF6( new doubleInsoFunction6( this, &CalculInso::MeanLatDaylyInso_PO ) );		break;
				case	instantInso_time_pre_obl_func:	SetF6( new doubleInsoFunction6( this, &CalculInso::InstantaneousInso_PO ) );	break;
				
				case	daylyInso_time_obl_func:	SetF4( new doubleInsoFunction4( this, &CalculInso::DaylyInso_O ) );			break;
				case	meanInso_time_obl_func:		SetF5( new doubleInsoFunction5( this, &CalculInso::MeanInso_O ) );			break;
				case	meanIrrad_time_obl_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::MeanIrrad_MJm2_O ) );	break;
				case	meanLatInso_time_obl_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::MeanLatDaylyInso_O ) );	break;
				case	instantInso_time_obl_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::InstantaneousInso_O ) );	break;
				
				case	daylyInso_astro_func:		SetF5( new doubleInsoFunction5( this, &CalculInso::daylyInso ) );			break;
				case	meanInso_astro_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::meanInso ) );			break;
				case	meanIrrad_astro_func:		SetF5( new doubleInsoFunction5( this, &CalculInso::meanIrrad_MJm2 ) );		break;
				case	seasonLength_astro_func:	SetF4( new doubleInsoFunction4( this, &CalculInso::seasonLengthInDays ) );	break;
				case	daylyCosz_astro_func:		SetF3( new doubleInsoFunction3( this, &CalculInso::daylyMeanCosz ) );		break;
				case	dayLength_astro_func:		SetF3( new doubleInsoFunction3( this, &CalculInso::dayLength ) );			break;
				case	meanLatInso_astro_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::meanLatDaylyInso ) );	break;
				case	instantInso_astro_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::instantaneousInso ) );	break;
				
				case	daylyInso_M_time_func:		SetF4( new doubleInsoFunction4( this, &CalculInso::DaylyInso_H ) );			break;
				case	meanInso_M_time_func:		SetF5( new doubleInsoFunction5( this, &CalculInso::MeanInso_H ) );			break;
				case	meanIrrad_M_time_func:		SetF5( new doubleInsoFunction5( this, &CalculInso::MeanIrrad_MJm2_H ) );	break;
				case	daylyCosz_M_time_func:		SetF4( new doubleInsoFunction4( this, &CalculInso::DaylyMeanCosz_H ) );		break;
				case	dayLength_M_time_func:		SetF4( new doubleInsoFunction4( this, &CalculInso::DayLength_H ) );			break;
				case	meanLatInso_M_time_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::MeanLatDaylyInso_H ) );	break;
				case	instantInso_M_time_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::InstantaneousInso_H ) );	break;
				
				case	daylyInso_M_astro_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::daylyInso_H ) );			break;
				case	meanInso_M_astro_func:		SetF7( new doubleInsoFunction7( this, &CalculInso::meanInso_H ) );			break;
				case	meanIrrad_M_astro_func:		SetF7( new doubleInsoFunction7( this, &CalculInso::meanIrrad_MJm2_H ) );	break;
				case	daylyCosz_M_astro_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::daylyMeanCosz_H ) );		break;
				case	dayLength_M_astro_func:		SetF6( new doubleInsoFunction6( this, &CalculInso::dayLength_H ) );			break;
				case	meanLatInso_M_astro_func:	SetF7( new doubleInsoFunction7( this, &CalculInso::meanLatDaylyInso_H ) );	break;
				case	instantInso_M_astro_func:	SetF7( new doubleInsoFunction7( this, &CalculInso::instantaneousInso_H ) );	break;
				
				case	irrad_Threshold_time_func:	SetF3( new doubleInsoFunction3( this, &CalculInso::IrradAboveInso ) );			break;
				case	irrad_Threshold_astro_func:	SetF5( new doubleInsoFunction5( this, &CalculInso::irradiationAboveInso ) );	break;
			};
			return	FuncWithArg( fCode, pCode );
		};

private:
	
	static	const	double	DefaultSolarCst;

	static CalcAstro_BER78	ber78;
	static CalcAstro_LA93_0	la93_0;
	static CalcAstro_LA93_1	la93_1;
	static CalcAstro_LA04	la04;
	
	CalculAstro*	calc_astro;
	double		SolarCst;
	
	//	some utility functions
	
	double	atanEpsTan( double eps, double x );
	double	atanEpsTanC( double eps, double x );
	double	primitiv( double e, double v );
	double	seasonLength( double e, double perh, double tls1, double tls2 );
	double	meanIrradiation( double ecc, double xob, double tls1, double tls2, double dphi );
	double	meanIrrad( double eps, double phi, double lbd1, double lbd2 );
	double	intElle( double phi1, double phi2, double k );
	double	intEllf( double phi1, double phi2, double k );
	double	intEllpi( double phi1, double phi2, double en, double k );
	double	Elle( double phi, double k );					//	idem MyMath::elle, with argument checking
	double	Ellf( double phi, double k );					//	idem MyMath::ellf, with argument checking
	double	EllPi( double phi, double en, double k );		//	idem MyMath::ellpi, with argument checking
	static double	anomaly( double lon, double perh );
	static double	longitude( double anom, double perh );
	static double	MinusPiS2_3PiS2( double v );
	static double	MinusPi_Pi( double v );
	static double	Zero_DeuxPi( double v );
	static double	Zero_360( double v );
	double	solveKepler( double ecc, double vm );
	double	trueAnomaly( double mean_anom, double ecc );
	double	trueLongitude( double mean_lon, double from_lon, double ecc, double perh_lon );
	double	meanAnomaly( double true_anom, double ecc );
	double	primitivMeanLatInso( double sd, double cd, double x );
	double	solarRad( double ecc, double perh, double dlam );
	
	static double	HfromCosH( double sd, double cd, double x );				//	sin(delta), cos(delta), et phi(radian)
	static double	HfromCosH( double sd, double x )							//	sin(delta) et phi(radian)
	{	return	HfromCosH( sd, std::sqrt(1 - sd*sd), x );	};
	static double	solar( double ecc, double perh, double dlam );
	static double	dInso( double ecc, double perh, double xob, double dlam, double phi );
	static double	phiPolarDay( double xob, double dlam );						//	limite du jour polaire

//		new code, for irradiationAboveInso()
	static	int		MinAndMaxInso( double ecc, double perh, double xob, double dphi, 
						double_vector& minInso, double_vector& maxInso, double_vector& minInsoLong, double_vector& maxInsoLong );
						
	static double	MyF( double h )		{	return	(h==0 ? 0 : 1 - h/std::tan(h));	};		//	h in [0,�[ => MyF in [0,inf[
	class	MyFZFunc : public doubleFunction
	{	double	v;
		public:	MyFZFunc( double vv ):doubleFunction(),v(vv) {};
				virtual double	func( const double h )	const {	return	MyF(h) - v;	};
	};
	static double	MyFM1( double f );
	
	static double	sFunc( double e, double x )	{	return	MyMath::PiSur2 - x + atan( 2*e*sin(x)/(1-e*cos(x)) );		};
	static double	sFunc_xc( double e )		{	return	(e <= 1/3. ? 0 : acos( (sqrt(7+18*e*e)-2)/3/e ));	};
	static double	sFunc_yc( double e )		{	return	(e <= 1/3. ? MyMath::PiSur2 : MyMath::PiSur2 - acos( (sqrt(7+18*e*e)-2)/3/e ) + atan( 2*sqrt(4*sqrt(7+18*e*e)-11-9*e*e)/(5-sqrt(7+18*e*e)) ) );	};
	class	sFuncZFunc : public doubleFunction
	{	double	e, y;
		public:	sFuncZFunc( double ee, double yy ):doubleFunction(),e(ee),y(yy) {};
				virtual double	func( const double x )	const {	return	sFunc(e,x) - y;	};
	};
	static double	sFuncM1( double e, double y );			//	inverse in x of sFunc(e,x), unique if e < 1/3
	static double	sFuncM1_bis( double e, double y );		//	2nd value of inverse in x of sFunc(e,x) if e > 1/3
		//	idem, but for any value of y, return value in [0,Pi]
	static double	sFuncM1_sup( double e, double y );		//	sFuncM1_sup = sFuncM1_inf if e < 1/3
	static double	sFuncM1_inf( double e, double y );		//	if not
	static double	sFuncM1_mid( double e, double y );
	
	static double	solPhi( double ecc, double perh, double xob, double dlam );
	class	sFuncZsolPhi : public doubleFunction
	{	double	e, ob, om;
		public:	sFuncZsolPhi( double ee, double oo, double mm ):doubleFunction(),e(ee),ob(oo),om(mm) {};
				virtual double	func( const double x )	const {	return	solPhi(e,om,ob,x);	};
	};
	static double	minSolPhi( double ecc, double omega, double eps, double& xmin );
	
	class	sFuncZinso : public doubleFunction
	{	double	e, xob, perh, dphi, inso, sg;
		public:	sFuncZinso( double ee, double oo, double mm, double p, double i, double s = 1 )
					:doubleFunction(),e(ee),xob(oo),perh(mm),dphi(p),inso(i), sg(s) {};
				virtual double	func( const double x )	const {	return	sg*(dInso(e,perh,xob,x,dphi)-inso);	};
	};
	static double	minimumSol( double ecc, double xob, double perh, double dphi, double dlat1, double dlat2, double& latmin );
	static double	maximumSol( double ecc, double xob, double perh, double dphi, double dlat1, double dlat2, double& latmax );
	static double	myMinimizing( double a, double b, doubleFunction& func, double& z );
	
public:

	CalculInso() : calc_astro(&la04)
					{	SetSolarCsteTo( DefaultSolarCst );	};
	
	typedef enum { kAstro_Ber78 = 1, kAstro_La90, kAstro_La93_11, kAstro_La04 }	astrotype;
	
	CalculAstro*	AstroChoice( astrotype choice )
	{	switch ( choice )
		{	case kAstro_Ber78:		return &ber78;	break;
			case kAstro_La90:		return &la93_0;	break;
			case kAstro_La93_11:	return &la93_1;	break;
			case kAstro_La04:		return &la04;	break;
		}
		return NULL;
	};
	void	SetAstroTo( astrotype choice )		{	SetAstroTo( AstroChoice( choice ) );		};
	char*	ReferTo( astrotype choice )			{	return	AstroChoice( choice )->Reference();	};
	
	void	SetAstroTo( CalculAstro* astro )	{	calc_astro = astro;		};
	CalculAstro&	Astro()						{	return	*calc_astro;	};
	void	SetSolarCsteTo( double solar )		{	SolarCst = solar;		};
	void	ResetSolarCste()					{	SolarCst = DefaultSolarCst;	};
	static double	DefaultSolarCste()			{	return DefaultSolarCst;	};

//	Output functions:
	
//	computes inso using orbital params
	
	double	daylyInso( double ecc, double perh, double xob, double dlam, double phi );
	double	daylyMeanCosz( double xob, double dlam, double phi );
	double	meanInso( double ecc, double perh, double xob, double tls1, double tls2, double dphi );
	double	meanIrrad_MJm2( double ecc, double xob, double tls1, double tls2, double dphi );
	double	seasonLengthInDays( double e, double perh, double tls1, double tls2 );
	double	dayLength( double xob, double dlam, double phi );
	double	meanLatDaylyInso( double ecc, double perh, double xob, double dlam, double phi1, double phi2 );
	double	instantaneousInso( double ecc, double perh, double xob, double dlam, double phi, double h );
	double	irradiationAboveInso( double ecc, double perh, double xob, double phi, double insoTh );

	
		//	computes inso using orbital params and mean longitude
	
	double	daylyInso_H( double ecc, double perh, double xob, double tlam, double phi, double ref_dlam )
			{	return	daylyInso( ecc, perh, xob, trueLongitude( tlam, ref_dlam, ecc, perh ), phi );	};
	double	meanInso_H( double ecc, double perh, double xob, double tls1, double tls2, double dphi, double ref_dlam )
			{	return	meanInso( ecc, perh, xob, trueLongitude( tls1, ref_dlam, ecc, perh ), trueLongitude( tls2, ref_dlam, ecc, perh ), dphi );	};
	double	meanIrrad_MJm2_H( double ecc, double perh, double xob, double tls1, double tls2, double dphi, double ref_dlam )
			{	return	meanIrrad_MJm2( ecc, xob, trueLongitude( tls1, ref_dlam, ecc, perh ), trueLongitude( tls2, ref_dlam, ecc, perh ), dphi );	};
	double	daylyMeanCosz_H( double ecc, double perh, double xob, double tlam, double phi, double ref_dlam )
			{	return	daylyMeanCosz( xob, trueLongitude( tlam, ref_dlam, ecc, perh ), phi );	};
	double	dayLength_H( double ecc, double perh, double xob, double tlam, double phi, double ref_dlam )
			{	return	dayLength( xob, trueLongitude( tlam, ref_dlam, ecc, perh ), phi );	};
	double	meanLatDaylyInso_H( double ecc, double perh, double xob, double tlam, double phi1, double phi2, double ref_dlam )
			{	return	meanLatDaylyInso( ecc, perh, xob, trueLongitude( tlam, ref_dlam, ecc, perh ), phi1, phi2 );	};
	double	instantaneousInso_H( double ecc, double perh, double xob, double tlam, double phi, double h, double ref_dlam )
			{	return	instantaneousInso( ecc, perh, xob, trueLongitude( tlam, ref_dlam, ecc, perh ), phi, h );	};
	
//	computes inso as a function of time
	
	double	DaylyInso( double t, double dlam, double phi )
			{	return	daylyInso(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi );	};
	double	DaylyMeanCosz( double t, double dlam, double phi )
			{	return	daylyMeanCosz( calc_astro->Obliquity(t), dlam, phi );	};
	double	MeanInso( double t, double dlam1, double dlam2, double phi )
			{	return	meanInso(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam1, dlam2, phi );	};
	double	MeanIrrad_MJm2( double t, double dlam1, double dlam2, double phi )
			{	return	meanIrrad_MJm2(	calc_astro->Eccentricity(t), calc_astro->Obliquity(t), dlam1, dlam2, phi );		};
	double	SeasonLengthInDays( double t, double dlam1, double dlam2 )
			{	return	seasonLengthInDays(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), dlam1, dlam2 );	};
	double	DayLength( double t, double dlam, double phi )
			{	return	dayLength(	calc_astro->Obliquity(t), dlam, phi );	};
	double	MeanLatDaylyInso( double t, double dlam, double phi1, double phi2 )
			{	return	meanLatDaylyInso(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi1, phi2 );	};
	double	InstantaneousInso( double t, double dlam, double phi, double h )
			{	return	instantaneousInso(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, h );		};
	double	IrradAboveInso( double t, double phi, double insoTh )
			{	return	irradiationAboveInso( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), phi, insoTh );	};

		//	computes inso as a function of time and mean longitude
	
	double	DaylyInso_H( double t, double dlam, double phi, double ref_dlam )
			{	return	daylyInso_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	DaylyMeanCosz_H( double t, double dlam, double phi, double ref_dlam )
			{	return	daylyMeanCosz_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	MeanInso_H( double t, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanInso_H(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam1, dlam2, phi, ref_dlam );	};
	double	MeanIrrad_MJm2_H( double t, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanIrrad_MJm2_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam1, dlam2, phi, ref_dlam );		};
	double	DayLength_H( double t, double dlam, double phi, double ref_dlam )
			{	return	dayLength_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	MeanLatDaylyInso_H( double t, double dlam, double phi1, double phi2, double ref_dlam )
			{	return	meanLatDaylyInso_H(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi1, phi2, ref_dlam );	};
	double	InstantaneousInso_H( double t, double dlam, double phi, double h, double ref_dlam )
			{	return	instantaneousInso_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, h, ref_dlam );		};
	
//	computes inso as a function of time + ecc
	
	double	DaylyInso_E( double t, double ecc, double dlam, double phi )
			{	return	daylyInso(	ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi );	};
	double	MeanInso_E( double t, double ecc, double dlam1, double dlam2, double phi )
			{	return	meanInso(	ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam1, dlam2, phi );	};
	double	MeanIrrad_MJm2_E( double t, double ecc, double dlam1, double dlam2, double phi )
			{	return	meanIrrad_MJm2(	ecc, calc_astro->Obliquity(t), dlam1, dlam2, phi );		};
	double	SeasonLengthInDays_E( double t, double ecc, double dlam1, double dlam2 )
			{	return	seasonLengthInDays(	ecc, calc_astro->ClimaticPrec(t), dlam1, dlam2 );	};
	double	MeanLatDaylyInso_E( double t, double ecc, double dlam, double phi1, double phi2 )
			{	return	meanLatDaylyInso(	ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi1, phi2 );	};
	double	InstantaneousInso_E( double t, double ecc, double dlam, double phi, double h )
			{	return	instantaneousInso(	ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, h );		};
	
		//	computes inso as a function of time and mean longitude
	
	double	DaylyInso_H_E( double t, double ecc, double dlam, double phi, double ref_dlam )
			{	return	daylyInso_H( ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	DaylyMeanCosz_H_E( double t, double ecc, double dlam, double phi, double ref_dlam )
			{	return	daylyMeanCosz_H( ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	MeanInso_H_E( double t, double ecc, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanInso_H(	ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam1, dlam2, phi, ref_dlam );	};
	double	MeanIrrad_MJm2_H_E( double t, double ecc, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanIrrad_MJm2_H( ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam1, dlam2, phi, ref_dlam );		};
	double	DayLength_H_E( double t, double ecc, double dlam, double phi, double ref_dlam )
			{	return	dayLength_H( ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	MeanLatDaylyInso_H_E( double t, double ecc, double dlam, double phi1, double phi2, double ref_dlam )
			{	return	meanLatDaylyInso_H(	ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi1, phi2, ref_dlam );	};
	double	InstantaneousInso_H_E( double t, double ecc, double dlam, double phi, double h, double ref_dlam )
			{	return	instantaneousInso_H( ecc, calc_astro->ClimaticPrec(t), calc_astro->Obliquity(t), dlam, phi, h, ref_dlam );		};
	
//	computes inso as a function of time + ecc + obl
	
	double	DaylyInso_EO( double t, double ecc, double obl, double dlam, double phi )
			{	return	daylyInso(	ecc, calc_astro->ClimaticPrec(t), obl, dlam, phi );	};
	double	MeanInso_EO( double t, double ecc, double obl, double dlam1, double dlam2, double phi )
			{	return	meanInso(	ecc, calc_astro->ClimaticPrec(t), obl, dlam1, dlam2, phi );	};
	double	MeanLatDaylyInso_EO( double t, double ecc, double obl, double dlam, double phi1, double phi2 )
			{	return	meanLatDaylyInso(	ecc, calc_astro->ClimaticPrec(t), obl, dlam, phi1, phi2 );	};
	double	InstantaneousInso_EO( double t, double ecc, double obl, double dlam, double phi, double h )
			{	return	instantaneousInso(	ecc, calc_astro->ClimaticPrec(t), obl, dlam, phi, h );		};
	
		//	computes inso as a function of time and mean longitude
	
	double	DaylyInso_H_EO( double t, double ecc, double obl, double dlam, double phi, double ref_dlam )
			{	return	daylyInso_H( ecc, calc_astro->ClimaticPrec(t), obl, dlam, phi, ref_dlam );	};
	double	DaylyMeanCosz_H_EO( double t, double ecc, double obl, double dlam, double phi, double ref_dlam )
			{	return	daylyMeanCosz_H( ecc, calc_astro->ClimaticPrec(t), obl, dlam, phi, ref_dlam );	};
	double	MeanInso_H_EO( double t, double ecc, double obl, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanInso_H(	ecc, calc_astro->ClimaticPrec(t), obl, dlam1, dlam2, phi, ref_dlam );	};
	double	MeanIrrad_MJm2_H_EO( double t, double ecc, double obl, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanIrrad_MJm2_H( ecc, calc_astro->ClimaticPrec(t), obl, dlam1, dlam2, phi, ref_dlam );		};
	double	DayLength_H_EO( double t, double ecc, double obl, double dlam, double phi, double ref_dlam )
			{	return	dayLength_H( ecc, calc_astro->ClimaticPrec(t), obl, dlam, phi, ref_dlam );	};
	double	MeanLatDaylyInso_H_EO( double t, double ecc, double obl, double dlam, double phi1, double phi2, double ref_dlam )
			{	return	meanLatDaylyInso_H(	ecc, calc_astro->ClimaticPrec(t), obl, dlam, phi1, phi2, ref_dlam );	};
	double	InstantaneousInso_H_EO( double t, double ecc, double obl, double dlam, double phi, double h, double ref_dlam )
			{	return	instantaneousInso_H( ecc, calc_astro->ClimaticPrec(t), obl, dlam, phi, h, ref_dlam );		};
	
//	computes inso as a function of time + ecc + pre
	
	double	DaylyInso_EP( double t, double ecc, double pre, double dlam, double phi )
			{	return	daylyInso(	ecc, pre, calc_astro->Obliquity(t), dlam, phi );	};
	double	MeanInso_EP( double t, double ecc, double pre, double dlam1, double dlam2, double phi )
			{	return	meanInso(	ecc, pre, calc_astro->Obliquity(t), dlam1, dlam2, phi );	};
	double	MeanLatDaylyInso_EP( double t, double ecc, double pre, double dlam, double phi1, double phi2 )
			{	return	meanLatDaylyInso(	ecc, pre, calc_astro->Obliquity(t), dlam, phi1, phi2 );	};
	double	InstantaneousInso_EP( double t, double ecc, double pre, double dlam, double phi, double h )
			{	return	instantaneousInso(	ecc, pre, calc_astro->Obliquity(t), dlam, phi, h );		};
	
		//	computes inso as a function of time and mean longitude
	
	double	DaylyInso_H_EP( double t, double ecc, double pre, double dlam, double phi, double ref_dlam )
			{	return	daylyInso_H( ecc, pre, calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	DaylyMeanCosz_H_EP( double t, double ecc, double pre, double dlam, double phi, double ref_dlam )
			{	return	daylyMeanCosz_H( ecc, pre, calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	MeanInso_H_EP( double t, double ecc, double pre, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanInso_H(	ecc, pre, calc_astro->Obliquity(t), dlam1, dlam2, phi, ref_dlam );	};
	double	MeanIrrad_MJm2_H_EP( double t, double ecc, double pre, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanIrrad_MJm2_H( ecc, pre, calc_astro->Obliquity(t), dlam1, dlam2, phi, ref_dlam );		};
	double	DayLength_H_EP( double t, double ecc, double pre, double dlam, double phi, double ref_dlam )
			{	return	dayLength_H( ecc, pre, calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	MeanLatDaylyInso_H_EP( double t, double ecc, double pre, double dlam, double phi1, double phi2, double ref_dlam )
			{	return	meanLatDaylyInso_H(	ecc, pre, calc_astro->Obliquity(t), dlam, phi1, phi2, ref_dlam );	};
	double	InstantaneousInso_H_EP( double t, double ecc, double pre, double dlam, double phi, double h, double ref_dlam )
			{	return	instantaneousInso_H( ecc, pre, calc_astro->Obliquity(t), dlam, phi, h, ref_dlam );		};
	
//	computes inso as a function of time + pre
	
	double	DaylyInso_P( double t, double pre, double dlam, double phi )
			{	return	daylyInso(	calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam, phi );	};
	double	MeanInso_P( double t, double pre, double dlam1, double dlam2, double phi )
			{	return	meanInso(	calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam1, dlam2, phi );	};
	double	SeasonLengthInDays_P( double t, double pre, double dlam1, double dlam2 )
			{	return	seasonLengthInDays(	calc_astro->Eccentricity(t), pre, dlam1, dlam2 );	};
	double	MeanLatDaylyInso_P( double t, double pre, double dlam, double phi1, double phi2 )
			{	return	meanLatDaylyInso(	calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam, phi1, phi2 );	};
	double	InstantaneousInso_P( double t, double pre, double dlam, double phi, double h )
			{	return	instantaneousInso(	calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam, phi, h );		};
	
		//	computes inso as a function of time and mean longitude
	
	double	DaylyInso_H_P( double t, double pre, double dlam, double phi, double ref_dlam )
			{	return	daylyInso_H( calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	DaylyMeanCosz_H_P( double t, double pre, double dlam, double phi, double ref_dlam )
			{	return	daylyMeanCosz_H( calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	MeanInso_H_P( double t, double pre, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanInso_H(	calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam1, dlam2, phi, ref_dlam );	};
	double	MeanIrrad_MJm2_H_P( double t, double pre, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanIrrad_MJm2_H( calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam1, dlam2, phi, ref_dlam );		};
	double	DayLength_H_P( double t, double pre, double dlam, double phi, double ref_dlam )
			{	return	dayLength_H( calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam, phi, ref_dlam );	};
	double	MeanLatDaylyInso_H_P( double t, double pre, double dlam, double phi1, double phi2, double ref_dlam )
			{	return	meanLatDaylyInso_H(	calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam, phi1, phi2, ref_dlam );	};
	double	InstantaneousInso_H_P( double t, double pre, double dlam, double phi, double h, double ref_dlam )
			{	return	instantaneousInso_H( calc_astro->Eccentricity(t), pre, calc_astro->Obliquity(t), dlam, phi, h, ref_dlam );		};
	
//	computes inso as a function of time + pre + obl
	
	double	DaylyInso_PO( double t, double pre, double obl, double dlam, double phi )
			{	return	daylyInso(	calc_astro->Eccentricity(t), pre, obl, dlam, phi );	};
	double	MeanInso_PO( double t, double pre, double obl, double dlam1, double dlam2, double phi )
			{	return	meanInso(	calc_astro->Eccentricity(t), pre, obl, dlam1, dlam2, phi );	};
	double	MeanLatDaylyInso_PO( double t, double pre, double obl, double dlam, double phi1, double phi2 )
			{	return	meanLatDaylyInso(	calc_astro->Eccentricity(t), pre, obl, dlam, phi1, phi2 );	};
	double	InstantaneousInso_PO( double t, double pre, double obl, double dlam, double phi, double h )
			{	return	instantaneousInso(	calc_astro->Eccentricity(t), pre, obl, dlam, phi, h );		};
	
		//	computes inso as a function of time and mean longitude
	
	double	DaylyInso_H_PO( double t, double pre, double obl, double dlam, double phi, double ref_dlam )
			{	return	daylyInso_H( calc_astro->Eccentricity(t), pre, obl, dlam, phi, ref_dlam );	};
	double	DaylyMeanCosz_H_PO( double t, double pre, double obl, double dlam, double phi, double ref_dlam )
			{	return	daylyMeanCosz_H( calc_astro->Eccentricity(t), pre, obl, dlam, phi, ref_dlam );	};
	double	MeanInso_H_PO( double t, double pre, double obl, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanInso_H(	calc_astro->Eccentricity(t), pre, obl, dlam1, dlam2, phi, ref_dlam );	};
	double	MeanIrrad_MJm2_H_PO( double t, double pre, double obl, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanIrrad_MJm2_H( calc_astro->Eccentricity(t), pre, obl, dlam1, dlam2, phi, ref_dlam );		};
	double	DayLength_H_PO( double t, double pre, double obl, double dlam, double phi, double ref_dlam )
			{	return	dayLength_H( calc_astro->Eccentricity(t), pre, obl, dlam, phi, ref_dlam );	};
	double	MeanLatDaylyInso_H_PO( double t, double pre, double obl, double dlam, double phi1, double phi2, double ref_dlam )
			{	return	meanLatDaylyInso_H(	calc_astro->Eccentricity(t), pre, obl, dlam, phi1, phi2, ref_dlam );	};
	double	InstantaneousInso_H_PO( double t, double pre, double obl, double dlam, double phi, double h, double ref_dlam )
			{	return	instantaneousInso_H( calc_astro->Eccentricity(t), pre, obl, dlam, phi, h, ref_dlam );		};
	
//	computes inso as a function of time + obl
	
	double	DaylyInso_O( double t, double obl, double dlam, double phi )
			{	return	daylyInso(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam, phi );	};
	double	MeanInso_O( double t, double obl, double dlam1, double dlam2, double phi )
			{	return	meanInso(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam1, dlam2, phi );	};
	double	MeanIrrad_MJm2_O( double t, double obl, double dlam1, double dlam2, double phi )
			{	return	meanIrrad_MJm2(	calc_astro->Eccentricity(t), obl, dlam1, dlam2, phi );		};
	double	MeanLatDaylyInso_O( double t, double obl, double dlam, double phi1, double phi2 )
			{	return	meanLatDaylyInso(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam, phi1, phi2 );	};
	double	InstantaneousInso_O( double t, double obl, double dlam, double phi, double h )
			{	return	instantaneousInso(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam, phi, h );		};
	
		//	computes inso as a function of time and mean longitude
	
	double	DaylyInso_H_O( double t, double obl, double dlam, double phi, double ref_dlam )
			{	return	daylyInso_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam, phi, ref_dlam );	};
	double	DaylyMeanCosz_H_O( double t, double obl, double dlam, double phi, double ref_dlam )
			{	return	daylyMeanCosz_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam, phi, ref_dlam );	};
	double	MeanInso_H_O( double t, double obl, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanInso_H(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam1, dlam2, phi, ref_dlam );	};
	double	MeanIrrad_MJm2_H_O( double t, double obl, double dlam1, double dlam2, double phi, double ref_dlam )
			{	return	meanIrrad_MJm2_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam1, dlam2, phi, ref_dlam );		};
	double	DayLength_H_O( double t, double obl, double dlam, double phi, double ref_dlam )
			{	return	dayLength_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam, phi, ref_dlam );	};
	double	MeanLatDaylyInso_H_O( double t, double obl, double dlam, double phi1, double phi2, double ref_dlam )
			{	return	meanLatDaylyInso_H(	calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam, phi1, phi2, ref_dlam );	};
	double	InstantaneousInso_H_O( double t, double obl, double dlam, double phi, double h, double ref_dlam )
			{	return	instantaneousInso_H( calc_astro->Eccentricity(t), calc_astro->ClimaticPrec(t), obl, dlam, phi, h, ref_dlam );		};

};

