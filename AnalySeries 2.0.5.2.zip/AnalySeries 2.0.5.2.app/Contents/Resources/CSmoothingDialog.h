
#include "CMyStdDialogs.h"


//	CSamplingDialog

const ResIDT	rPPob_SmoothingDialog	= 1010;
const PaneIDT	kSmooth_Type_Popup		= 3;
const PaneIDT	kSmooth_Nb_Popup		= 4;
const PaneIDT	kSmooth_Degree_EditTxt	= 5;
const PaneIDT	kSmooth_NbLeft_EditTxt	= 6;
const PaneIDT	kSmooth_NbRight_EditTxt	= 7;
const PaneIDT	kSmooth_Deriv_EditTxt	= 8;
const PaneIDT	kSmooth_Degree_StatTxt	= 9;
const PaneIDT	kSmooth_NbLeft_StatTxt	= 10;
const PaneIDT	kSmooth_NbRight_StatTxt	= 11;
const PaneIDT	kSmooth_Deriv_StatTxt	= 12;
const PaneIDT	kSmooth_FFT_CheckBox	= 13;
const PaneIDT	kSmooth_Bound_Popup		= 14;
const PaneIDT	kSmooth_BoundValue_EditTxt	= 15;

const PaneIDT	kSmooth_moving_average		= 1;
const PaneIDT	kSmooth_general_symetric	= 2;
const PaneIDT	kSmooth_general_asymetric	= 3;
const PaneIDT	kSmooth_general_derivative	= 4;

const PaneIDT	kSmooth_vs_mean			= 1;
const PaneIDT	kSmooth_vs_value		= 2;
const PaneIDT	kSmooth_shift_filter	= 3;

const PaneIDT	kSmooth_NbPoints_more		= 19;	//	de 3 a 37 => more.. = 19

const MessageT	msg_SmoothTypeChanged	= 1058;
const MessageT	msg_SmoothNbChanged		= 1059;
const MessageT	msg_SmoothTxtChanged	= 1060;
const MessageT	msg_SmoothBoundChanged	= 1061;


class CSmoothingDialog : public CMyStdDialog {
public:
	static Boolean	saved;
	static SInt32	savedSmoothType;
	static SInt32	savedSmoothNL;
	static SInt32	savedSmoothNR;
	static SInt32	savedSmoothM;
	static SInt32	savedSmoothND;
	static Boolean	savedSmoothFFT;
	static SInt32	savedSmoothBoundT;
	static double	savedSmoothBoundV;
	
	SInt32	Degree()
		{	if (GetPopupValue( kSmooth_Type_Popup ) == kSmooth_moving_average)
					return	0;
			else	return	lastSmoothM;
		};
	SInt32	Deriv()
		{	if (GetPopupValue( kSmooth_Type_Popup ) != kSmooth_general_derivative)
					return	0;
			else	return	lastSmoothND;
		};
		
private:
	SInt32	lastSmoothNL;
	SInt32	lastSmoothNR;
	SInt32	lastSmoothM;
	SInt32	lastSmoothND;
	
	void	UpdateDialog()
		{	SInt32	smoothType = GetPopupValue( kSmooth_Type_Popup );
			SInt32	smoothNb   = GetPopupValue( kSmooth_Nb_Popup );
			Boolean deriv = (smoothType == kSmooth_general_derivative);
			Boolean moving_ave = (smoothType == kSmooth_moving_average);
			Boolean outOfRange = (smoothNb == kSmooth_NbPoints_more);
			Boolean symetric = (moving_ave || smoothType == kSmooth_general_symetric );
			
			if (deriv)
			{	GetEditText( kSmooth_Deriv_EditTxt )->Show();
				GetStaticText( kSmooth_Deriv_StatTxt )->Show();
			}
			else
			{	GetEditText( kSmooth_Deriv_EditTxt )->Hide();
				GetStaticText( kSmooth_Deriv_StatTxt )->Hide();
			}
			GetEditText( kSmooth_Deriv_EditTxt )->SetValue( Deriv() );
			
			if (moving_ave)	GetEditText( kSmooth_Degree_EditTxt )->Disable();
			else			GetEditText( kSmooth_Degree_EditTxt )->Enable();
			GetEditText( kSmooth_Degree_EditTxt )->SetValue( Degree() );
				
			if (symetric)	GetPopup( kSmooth_Nb_Popup )->Show();
			else			GetPopup( kSmooth_Nb_Popup )->Hide();
			
			if (symetric && !outOfRange)
			{	GetEditText( kSmooth_NbLeft_EditTxt )->Disable();
				GetEditText( kSmooth_NbRight_EditTxt )->Disable();
				GetEditText( kSmooth_NbLeft_EditTxt )->SetValue( smoothNb );
				GetEditText( kSmooth_NbRight_EditTxt )->SetValue( smoothNb );
			}
			else
			{	GetEditText( kSmooth_NbLeft_EditTxt )->Enable();
				GetEditText( kSmooth_NbRight_EditTxt )->Enable();
				GetEditText( kSmooth_NbLeft_EditTxt )->SetValue( lastSmoothNL );
				GetEditText( kSmooth_NbRight_EditTxt )->SetValue( lastSmoothNR );
			}
			
			
		};
		
public:
	enum { class_ID = 'SmoD' };
	
	CSmoothingDialog( LStream *inStream )	: CMyStdDialog( inStream )	{};
	~CSmoothingDialog()		{};

	virtual void	ListenToMessage( MessageT inMessage, void *ioParam )
		{	switch ( inMessage ) {
				case msg_SmoothTypeChanged:
				UpdateDialog();
				break;
				
				case msg_SmoothBoundChanged:
				if (GetPopupValue( kSmooth_Bound_Popup ) == kSmooth_vs_value)
					GetEditText( kSmooth_BoundValue_EditTxt )->Show();
				else
					GetEditText( kSmooth_BoundValue_EditTxt )->Hide();
				break;
				
				case msg_SmoothNbChanged:
				UpdateDialog();
				lastSmoothNR	= GetEditText( kSmooth_NbRight_EditTxt )->GetValue();
				lastSmoothNL	= GetEditText( kSmooth_NbLeft_EditTxt )->GetValue();
				break;
				
				case msg_SmoothTxtChanged:
				lastSmoothNR	= GetEditText( kSmooth_NbRight_EditTxt )->GetValue();
				lastSmoothNL	= GetEditText( kSmooth_NbLeft_EditTxt )->GetValue();
				if (GetPopupValue( kSmooth_Type_Popup ) != kSmooth_moving_average)
					lastSmoothM = GetEditText( kSmooth_Degree_EditTxt )->GetValue();
				if (GetPopupValue( kSmooth_Type_Popup ) == kSmooth_general_derivative)
					lastSmoothND	= GetEditText( kSmooth_Deriv_EditTxt )->GetValue();
				break;
				
			default:
				LDialogBox::ListenToMessage( inMessage, ioParam );
				break;
			}
		};
		
	//virtual Boolean	ValidDialog()	{};
	virtual void	SetupDialog()
		{	if (saved)
			{	SetPopupValue( kSmooth_Type_Popup,	savedSmoothType );
				SetPopupValue( kSmooth_Nb_Popup,	savedSmoothNR );
				SetPopupValue( kSmooth_Bound_Popup,	savedSmoothBoundT );
				//GetEditText( kSmooth_BoundValue_EditTxt )->SetValue( savedSmoothBoundV );
                SetDValue( kSmooth_BoundValue_EditTxt, savedSmoothBoundV );
				SetCheckBoxValue( kSmooth_FFT_CheckBox,	savedSmoothFFT );
				GetEditText( kSmooth_NbLeft_EditTxt )->SetValue( savedSmoothNL );
				GetEditText( kSmooth_NbRight_EditTxt )->SetValue( savedSmoothNR );
				//GetEditText( kSmooth_Degree_EditTxt )->SetValue( Degree() );
				//GetEditText( kSmooth_Deriv_EditTxt )->SetValue( Deriv() );		//	cf UpdateDialog();
				lastSmoothNR = savedSmoothNR;
				lastSmoothNL = savedSmoothNL;
				lastSmoothM  = savedSmoothM;
				lastSmoothND = savedSmoothND;
			}
			else
			{	lastSmoothM		= GetEditText( kSmooth_Degree_EditTxt )->GetValue();	//	get the default values
				lastSmoothND	= GetEditText( kSmooth_Deriv_EditTxt )->GetValue();
				lastSmoothNR	= GetEditText( kSmooth_NbRight_EditTxt )->GetValue();
				lastSmoothNL	= GetEditText( kSmooth_NbLeft_EditTxt )->GetValue();
				savedSmoothM	= lastSmoothM;
				savedSmoothND	= lastSmoothND;
			}
			UpdateDialog();
		};
	virtual void	SaveDialog()
		{	saved = true;
			savedSmoothType	= GetPopupValue( kSmooth_Type_Popup );
			savedSmoothFFT  = GetCheckBoxValue( kSmooth_FFT_CheckBox );
			savedSmoothNL	= GetEditText( kSmooth_NbLeft_EditTxt )->GetValue();
			savedSmoothNR	= GetEditText( kSmooth_NbRight_EditTxt )->GetValue();
			savedSmoothBoundT	= GetPopupValue( kSmooth_Bound_Popup );
			savedSmoothBoundV	= GetDValue( kSmooth_BoundValue_EditTxt );
			if (savedSmoothType != kSmooth_moving_average)
				savedSmoothM = GetEditText( kSmooth_Degree_EditTxt )->GetValue();
			if (savedSmoothType == kSmooth_general_derivative)
				savedSmoothND	= GetEditText( kSmooth_Deriv_EditTxt )->GetValue();
		};
		
protected:

	virtual	SInt16	rPPob()	{	return	rPPob_SmoothingDialog;	};
	
};