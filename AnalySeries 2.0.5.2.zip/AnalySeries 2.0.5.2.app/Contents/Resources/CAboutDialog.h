
#include "CMyStdDialogs.h"
#include "CTextDocument.h"
#include <LTextEditView.h>
#include <UDesktop.h>


//	CAboutDialog

const ResIDT	rPPob_AboutAlert				= 1300;

const ResIDT	choice_Popup					= 3;
const ResIDT	text_View						= 4;
const ResIDT	msg_choiceChanged				= 1000;
const ResIDT	msg_Print						= 1001;


const ResIDT	readMe				= 128;
const ResIDT	license				= 129;
const ResIDT	licenseF			= 130;
const ResIDT	references			= 131;
const ResIDT	changes				= 132;


class CAboutDialog : public CMyStdDialog {
private:
	void ChangeText( SInt32 choice )
	{	ResIDT	textID = readMe;
		switch (choice)
		{	case 1:		textID = readMe;		break;
			case 2:		textID = license;		break;
			case 3:		textID = licenseF;		break;
			case 4:		textID = references;	break;
			case 5:		textID = changes;		break;
		};
		StResource	textRes(ResType_Text, textID, false);
		LTextEditView*	textView = GetTextEditView( text_View );
		
		StResource	styleRes;
		if ( textView->HasAttribute(textAttr_MultiStyle) )
			styleRes.GetResource(ResType_TextStyle, textID, false);

		Size textLength = ::GetHandleSize(textRes);
		textView->SetTextHandle(textRes, (StScrpHandle) styleRes.mResourceH);

		::TESetSelect(0, 0, textView->GetMacTEH());
		textView->AlignTextEditRects();
		textView->AdjustImageToText();
	};
		
public:
	enum { class_ID = 'AboD' };
	
	CAboutDialog( LStream *inStream )	: CMyStdDialog( inStream )	{};
	~CAboutDialog()		{};

	virtual void	ListenToMessage( MessageT inMessage, void *ioParam )
		{	switch ( inMessage ) {
				case msg_choiceChanged:
				{	SInt32	choice = GetPopupValue( choice_Popup );
					ChangeText( choice );
				}
				break;
				case msg_Print:
				{	LPane* paneToPrint = GetTextEditView( text_View );
					LPrintSpec	printSpec;
					
					StPrintSession	session(printSpec);

					UDesktop::Deactivate();
					bool	printIt = UPrinting::AskPrintJob(printSpec);
					UDesktop::Activate();

					if (printIt) {
						SendSelfAE(kCoreEventClass, kAEPrint, ExecuteAE_No);
					//	DoPrint();
						CTextDocument::DoPrintPane( paneToPrint, printSpec );
					}
				}
				break;
				
			default:
				LDialogBox::ListenToMessage( inMessage, ioParam );
				break;
			}
		};
		
protected:

	virtual	SInt16	rPPob()	{	return	rPPob_AboutAlert;	};
	
};