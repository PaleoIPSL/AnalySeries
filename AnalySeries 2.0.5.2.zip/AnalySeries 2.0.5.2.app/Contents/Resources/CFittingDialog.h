
#include "CMyStdDialogs.h"
#include "plotRecord.h"
#include "CDynamicPaneTable.h"
#include "CSelectionDialog.h"
#include "CRegScaleView.h"
#include "LMultiPanelView.h"
#include "LTextGroupBox.h"
#include "LTabsControl.h"
#include "LControlImp.h"


//	CFittingDialog

const ResIDT	rPPob_FittingDialog		= 1011;
const PaneIDT	kFitting_Funct_Popup	= 4;
/*
const PaneIDT	kFitting_Npts_StatTxt	= 5;
const PaneIDT	kFitting_Extra_StatTxt	= 6;
const PaneIDT	kFitting_evenly_Radio	= 10;
const PaneIDT	kFitting_using_Radio	= 11;
const PaneIDT	kFitting_From			= 12;
const PaneIDT	kFitting_To				= 13;
const PaneIDT	kFitting_Step			= 14;
const PaneIDT	kFitting_From_capt		= 15;
const PaneIDT	kFitting_To_capt		= 16;
const PaneIDT	kFitting_Step_capt		= 17;
const PaneIDT	kFitting_Scroller		= 18;
const PaneIDT	kFitting_DynTable		= 19;
const PaneIDT	kFitting_scale_capt		= 20;
const PaneIDT	kFitting_sample_capt	= 21;
const PaneIDT	kFitting_adjust			= 22;
const PaneIDT	kFitting_act_stp_capt	= 23;
*/
const PaneIDT	kFitting_degree_capt	= 24;
const PaneIDT	kFitting_degree			= 25;
const PaneIDT	kFitting_error_Popup	= 26;
const PaneIDT	kFitting_type_Popup		= 27;

const ResIDT	rPPob_FitList_Subpane	= 1055;
const PaneIDT	kFitList_use_CheckBox	= 1;
const PaneIDT	kFitList_do_CheckBox	= 2;
//const PaneIDT	kFitList_Caption		= 3;

const PaneIDT	kFitting_y_err_StatTxt	= 87;
const PaneIDT	kFitting_x_err_StatTxt	= 88;
const PaneIDT	kFitting_y_err_cste		= 85;
const PaneIDT	kFitting_x_err_cste		= 86;

//const PaneIDT	k_simple_interp	= 1;
//const PaneIDT	k_integ_interp	= 2;

const PaneIDT	k_polynomFit			= 1;
const PaneIDT	k_linearFit				= 2;
const PaneIDT	k_staircaseFit			= 3;
const PaneIDT	k_cubic_splineFit		= 4;

const PaneIDT	k_noFit_Err				= 1;
const PaneIDT	k_y_cst_Err				= 2;
const PaneIDT	k_y_Err					= 3;
const PaneIDT	k_xy_cst_Err			= 4;
const PaneIDT	k_xy_Err				= 5;

const PaneIDT	k_meanSquareFit			= 1;
const PaneIDT	k_meanAbsFit			= 2;

const MessageT	msg_popupFitChanged		= 1050;

/*
const MessageT	msg_radioFitChanged		= 1055;
const MessageT	msg_FitTextChanged		= 1056;
const MessageT	msg_FitAdjust			= 1057;
*/

const MessageT	msg_FitTabChanged		= 3000;
const PaneIDT	kFitting_multiView			= 50;
const PaneIDT	kFitting_tabsControl		= 51;
const PaneIDT	kFitting_tabsControl_sca	= 61;
const PaneIDT	kFitting_tabsControl_err	= 71;
const PaneIDT	kFitting_txtBox				= 52;
/*
const PaneIDT	kFitting_multiView_sca		= 60;
const PaneIDT	kFitting_tabsControl_sca	= 61;
const PaneIDT	kFitting_multiView_err		= 70;
const PaneIDT	kFitting_tabsControl_err	= 71;
*/


//	CFitErrorDialog

const ResIDT	rPPob_FitErrorDialog	= 1012;
const PaneIDT	kFitError_y_Popup		= 3;
const PaneIDT	kFitError_x_Popup		= 4;
const PaneIDT	kFitError_y_StatTxt		= 7;
const PaneIDT	kFitError_x_StatTxt		= 8;
const PaneIDT	kFitError_y_cste		= 5;
const PaneIDT	kFitError_x_cste		= 6;
const PaneIDT	kFitError_title_StatTxt	= 9;

const MessageT	msg_select_y_Changed			= 1059;
const MessageT	msg_select_x_Changed			= 1060;


class CFittingDialog : public CMyStdDialog {
public:
	STableItem1D*	theItem;
	size_t			item_nb()		{	return	theItem->TableSize();	};
//	STableItemPtr	item_( int i )	{	return	(i==1 ? theItem : theItem->itemTable[i-2] );	};
private:
	Boolean	regScale;
	
	LTabsControl*		GetTabsControl( PaneIDT paneID )				DefineGetField( LTabsControl, paneID );
//	{	return	GetField<LCaption>(this,paneID);		};
	LMultiPanelView*		GetMultiPanelView( PaneIDT paneID )				DefineGetField( LMultiPanelView, paneID );
//	{	return	GetField<LCaption>(this,paneID);		};
	LTextGroupBox*		GetTextGroupBox( PaneIDT paneID )				DefineGetField( LTextGroupBox, paneID );
//	{	return	GetField<LCaption>(this,paneID);		};


	void	ShowScaleAndErrors()		//	( Boolean show_scale, Boolean show_error )
		{	Boolean show_scale = hasScale();
			Boolean show_error = hasErrorPopup();
			if (show_scale)
			{	GetCaption( kFitting_degree_capt )->Hide();
				GetEditText( kFitting_degree )->Hide();
			}
			else
			{	GetCaption( kFitting_degree_capt )->Show();
				GetEditText( kFitting_degree )->Show();
			}
			if (GetPopupValue( kFitting_error_Popup ) == k_y_cst_Err || GetPopupValue( kFitting_error_Popup ) == k_xy_cst_Err)
			{	GetStaticText( kFitting_y_err_StatTxt )->Show();
				GetEditText( kFitting_y_err_cste )->Show();
			}
			else
			{	GetStaticText( kFitting_y_err_StatTxt )->Hide();
				GetEditText( kFitting_y_err_cste )->Hide();
			}
			if (GetPopupValue( kFitting_error_Popup ) == k_xy_cst_Err)
			{	GetStaticText( kFitting_x_err_StatTxt )->Show();
				GetEditText( kFitting_x_err_cste )->Show();
			}
			else
			{	GetStaticText( kFitting_x_err_StatTxt )->Hide();
				GetEditText( kFitting_x_err_cste )->Hide();
			}
			
			LTabsControl* tabsPane3 = GetTabsControl( kFitting_tabsControl );			//	GetField<LTabsControl>( this, kFitting_tabsControl );
			LTabsControl* tabsPane2 = GetTabsControl( kFitting_tabsControl_sca );		//	GetField<LTabsControl>( this, kFitting_tabsControl_sca );
			LTabsControl* tabsPane1 = GetTabsControl( kFitting_tabsControl_err );		//	GetField<LTabsControl>( this, kFitting_tabsControl_err );
			LMultiPanelView* multiPane = GetMultiPanelView( kFitting_multiView );				//	GetField<LMultiPanelView>( this, kFitting_multiView );
			LTextGroupBox* boxPane = GetTextGroupBox( kFitting_txtBox );				//	GetField<LTextGroupBox>( this, kFitting_txtBox );
			SInt32 i = multiPane->GetCurrentIndex();
			multiPane->Show();
			boxPane->Show();
			
			ErrorView()->ShowSecondCheckBox( GetPopupValue( kFitting_error_Popup ) == k_xy_Err );
			
			if (show_scale && show_error)
			{	tabsPane3->Show();	tabsPane2->Hide();	tabsPane1->Hide();
				tabsPane3->StopBroadcasting();
				tabsPane3->SetValue(i);
				tabsPane3->StartBroadcasting();
			}
			else
			{	tabsPane3->Hide();
				if (show_scale && (!show_error))
				{	tabsPane2->Show();		tabsPane1->Hide();
					tabsPane2->StopBroadcasting();
					if (i==3)	{	multiPane->SwitchToPanel(1);	tabsPane2->SetValue(1);	}
					else	tabsPane2->SetValue(i);
					tabsPane2->StartBroadcasting();
				}
				else
				{	tabsPane2->Hide();
					if ((!show_scale) && show_error)
					{	tabsPane1->Show();
						if (i!=3)	multiPane->SwitchToPanel(3);
					}
					else
					{	tabsPane1->Hide();
						multiPane->Hide();
						boxPane->Hide();
			}	}	}
		};
	Boolean	hasErrorPopup()
		{	switch( GetPopupValue( kFitting_error_Popup ) )	{
				case k_noFit_Err:	return false;
				case k_y_cst_Err:	return false;
				case k_y_Err:		return true;
				case k_xy_cst_Err:	return false;
				case k_xy_Err:		return true;
			}
			return false;
		};
	Boolean	hasScale()
		{	switch( GetPopupValue( kFitting_Funct_Popup ) )
			{	case k_polynomFit:	return false;	break;
				default:			return true;	break;
			}
			return true;
		};
	void	SelectTab( SInt32 index )		//	index = 1 ou 2			(3-index) = 2 ou 1
		{	SelectNameInTabPane( GetTabsControl( kFitting_tabsControl ), /*GetField<LTabsControl>( this, kFitting_tabsControl ),*/ index, true );
			SelectNameInTabPane( GetTabsControl( kFitting_tabsControl_sca ), /*GetField<LTabsControl>( this, kFitting_tabsControl_sca ),*/ index, true );
			
			SelectNameInTabPane( GetTabsControl( kFitting_tabsControl ), /*GetField<LTabsControl>( this, kFitting_tabsControl ),*/ 3-index, false );
			SelectNameInTabPane( GetTabsControl( kFitting_tabsControl_sca ), /*GetField<LTabsControl>( this, kFitting_tabsControl_sca ),*/ 3-index, false );
			regScale = (index == 1);
		};
	void	SelectNameInTabPane( LTabsControl* tabsPane, SInt32 index, bool select )
		{	ControlTabInfoRec	tabInfo;
			tabInfo.version = 0;
			Size actualSize;
			OSErr err = ::GetControlData( tabsPane->GetControlImp()->GetMacControl(), index, kControlTabInfoTag, sizeof(ControlTabInfoRec), &tabInfo, &actualSize);
			if (!err)
			{	LStr255	tag("\p� ");
				LStr255	txt( tabInfo.name );
				if (txt.BeginsWith(tag) && !select)		{	LString::CopyPStr( txt.Remove(0,2), tabInfo.name );		};
				if (!txt.BeginsWith(tag) && select)		{	LString::CopyPStr( tag+txt, tabInfo.name );				};
				err = ::SetControlData( tabsPane->GetControlImp()->GetMacControl(), index, kControlTabInfoTag, actualSize, &tabInfo);
				tabsPane->Refresh();
			}
		};

public:
	static Boolean	saved;
	static double	saved_From;
	static double	saved_To;
	static double	saved_Step;
	static UInt32	saved_Degree;
	//static SInt32	saved_FunctionType;
	//static SInt32	saved_FitType;
	
	static FourCharCode saved_FunctionType;
	static MyMath::fit_func::fittingFlag saved_Fit_Flag;

public:
	enum { class_ID = 'FitD' };
	
	CFittingDialog( LStream *inStream )	: CMyStdDialog( inStream )
		{	theItem = NULL;		regScale = true;
		};
	~CFittingDialog()
		{	
		};
		
	virtual void	FinishCreateSelf()
		{	LMultiPanelView* multiPane = GetMultiPanelView( kFitting_multiView );	//	GetField<LMultiPanelView>( this, kFitting_multiView );
			multiPane->AddPanel( rPPob_RegScaleView, nil, LArray::index_Last );
			multiPane->AddPanel( rPPob_UnevenScaleView, nil, LArray::index_Last );
			multiPane->AddPanel( rPPob_SeriesCheckView, nil, LArray::index_Last );
			multiPane->CreateAllPanels();
			multiPane->SwitchToPanel(3);
			multiPane->SwitchToPanel(2);
			multiPane->SwitchToPanel(1);
			SelectTab( 1 );		//	a priori, evenly sampled scale
			UnevenScaleView()->SetCaption( "\pFit" );
			ErrorView()->SetCaption( "\px-error" );
			ErrorView()->SetYCaption( "\py-error" );
			UReanimator::LinkListenerToBroadcasters( this, this, rPPob() );
			CMyStdDialog::FinishCreateSelf();
			ShowScaleAndErrors();	//	( false, false );
		};
	CMultiItemRegScaleView* RegScaleView()
		{	LMultiPanelView* multiPane = GetMultiPanelView( kFitting_multiView );	//	GetField<LMultiPanelView>( this, kFitting_multiView );
			return	dynamic_cast<CMultiItemRegScaleView*>(multiPane->GetPanel(1));
		};
	CUnevenScaleView* UnevenScaleView()
		{	LMultiPanelView* multiPane = GetMultiPanelView( kFitting_multiView );	//	GetField<LMultiPanelView>( this, kFitting_multiView );
			return	dynamic_cast<CUnevenScaleView*>(multiPane->GetPanel(2));
		};
	CSeriesCheckView* ErrorView()
		{	LMultiPanelView* multiPane = GetMultiPanelView( kFitting_multiView );	//	GetField<LMultiPanelView>( this, kFitting_multiView );
			return	dynamic_cast<CSeriesCheckView*>(multiPane->GetPanel(3));
		};
	Boolean isRegular()
		{	//LMultiPanelView* multiPane = GetField<LMultiPanelView>( this, kFitting_multiView );
			//return (multiPane->GetCurrentPanel() == RegScaleView());
			return regScale;
		};
		
	virtual void	ListenToMessage( MessageT inMessage, void *ioParam )
		{	switch ( inMessage ) {
		
				case msg_popupFitChanged:
					ShowScaleAndErrors();
				/*	switch( GetPopupValue( kFitting_Funct_Popup ) )
					{	case k_polynomFit:
							//ShowScale( false );
							ShowScaleAndErrors( false, hasErrorPopup() );
							break;
						default:
							//ShowScale( true );
							ShowScaleAndErrors( true, hasErrorPopup() );
							break;
					}*/
					break;
				
				case msg_FitTabChanged:
					{	SInt32*	v = (SInt32*)ioParam;
						LMultiPanelView* multiPane = GetMultiPanelView( kFitting_multiView );	//	GetField<LMultiPanelView>( this, kFitting_multiView );
						Boolean has_scale = hasScale();
						Boolean has_error = hasErrorPopup();
						if (has_scale && has_error)
						{	multiPane->SwitchToPanel(*v);		//	v = 1,2,3
							if (*v != 3)	SelectTab( *v );
						}
						if (has_scale && (!has_error))
						{	multiPane->SwitchToPanel(*v);		//	v = 1,2
							SelectTab( *v );
						}
						if ((!has_scale) && has_error)
							multiPane->SwitchToPanel(3);		//	v = 3
							
					/*		
						LTabsControl* tabsPane3 = GetField<LTabsControl>( this, kFitting_tabsControl );
						LTabsControl* tabsPane2 = GetField<LTabsControl>( this, kFitting_tabsControl_sca );
						
						ControlTabInfoRec	tabInfo;
						tabInfo.version = 0;
						Size actualSize;
						OSErr err = ::GetControlData( tabsPane3->GetControlImp()->GetMacControl(), 3, kControlTabInfoTag, sizeof(ControlTabInfoRec), &tabInfo, &actualSize);
						if (!err)
						{	LStr255	txt("\p� ");	txt += tabInfo.name;
							LString::CopyPStr( txt, tabInfo.name );
							err = ::SetControlData( tabsPane3->GetControlImp()->GetMacControl(), 3, kControlTabInfoTag, actualSize, &tabInfo);
							tabsPane3->Refresh();
						}
					*/	
					}
					break;

			default:
				LDialogBox::ListenToMessage( inMessage, ioParam );
				break;
			}
		};
		
	virtual Boolean	ValidDialog()		//	only check wether it is consistent
		{	Boolean	isOk = true;
			if (hasScale())
			{	if (isRegular())	isOk = RegScaleView()->ValidView();
				else				isOk = UnevenScaleView()->ValidView();
			}
			if (isOk && (GetPopupValue( kFitting_error_Popup ) == k_y_cst_Err || GetPopupValue( kFitting_error_Popup ) == k_xy_cst_Err))
			{	GetDValue( kFitting_y_err_cste, isOk );
				if (!isOk)	MySimpleAlert( "\pThe y-error constant is unreadable" );
			}
			if (isOk && (GetPopupValue( kFitting_error_Popup ) == k_xy_cst_Err))
			{	GetDValue( kFitting_x_err_cste, isOk );
				if (!isOk)	MySimpleAlert( "\pThe x-error constant is unreadable" );
			}
			if (isOk && hasErrorPopup())
			{	if (GetPopupValue( kFitting_error_Popup ) == k_xy_cst_Err)
					ErrorView()->ValidSeriesView(1,1,LStr255("\p y-errors"),1,1,LStr255("\p x-errors"));
				else	//	if (GetPopupValue( kFitting_error_Popup ) == k_y_cst_Err)
					ErrorView()->ValidSeriesView(1,1,LStr255("\p y-errors"),0,0,LStr255("\p x-errors"));
			}
			if (isOk)
			{	PaneIDT	err_popup = GetPopupValue( kFitting_error_Popup );
				if ( (err_popup == k_xy_cst_Err) || (err_popup == k_xy_Err) )
				{	PaneIDT	func_popup = GetPopupValue( kFitting_Funct_Popup );
					if (func_popup == k_polynomFit)
					{	PaneIDT	fit_popup = GetPopupValue( kFitting_type_Popup );
						isOk = ((degree() <= 1) && (fit_popup == k_meanSquareFit));
					}
					else isOk = false;
				}
				if (!isOk)	MySimpleAlert( "\pErrors on x can be used only with mean-square straight-line fit", this );
			}
			return	isOk;
		};
	
	virtual void	SetupDialog()
		{	if (saved)
			{	//	SetPopupValue( kFitting_Interp_Popup, saved_InterpType );
				RegScaleView()->SetValues( saved_From, saved_To, saved_Step );		
			//	SetDValue( kFitting_From, saved_From );
			//	SetDValue( kFitting_To,   saved_To );
			//	SetDValue( kFitting_Step, saved_Step );
				SetDValue( kFitting_degree, saved_Degree );
			//	SetPopupValue( kFitting_type_Popup, saved_FitType );
				ShowScaleAndErrors();	//	( saved_FunctionType != k_polynomFit, false );
				//ShowEvenScale( GetRadioValue( kFitting_evenly_Radio ) );
				
				switch (saved_Fit_Flag)
				{	case MyMath::fit_func::stdFit:		SetPopupValue( kFitting_type_Popup, k_meanSquareFit );	break;
					case MyMath::fit_func::absFit:		SetPopupValue( kFitting_type_Popup, k_meanAbsFit );		break;
				};
				//SetPopupValue( kFitting_Funct_Popup, saved_FunctionType );
				
				switch (saved_FunctionType)
				{	case MyMath::LinearInterpFunctionCode:	SetPopupValue( kFitting_Funct_Popup, k_linearFit );			break;
					case MyMath::PolynomialFunctionCode:	SetPopupValue( kFitting_Funct_Popup, k_polynomFit );		break;
					case MyMath::StairInterpFunctionCode:	SetPopupValue( kFitting_Funct_Popup, k_staircaseFit );		break;
					case MyMath::SplineInterpFunctionCode:	SetPopupValue( kFitting_Funct_Popup, k_cubic_splineFit );	break;
				};
			}
		};
	void	SetupDialogScale( STableItem1D*	item )
		{	theItem 	= item;
			RegScaleView()->SetupDialogScale( item );		
			UnevenScaleView()->SetupDialogScale( item );
			ErrorView()->SetupDialogScale( item );
			
			//Boolean npoly = GetPopupValue( kFitting_Funct_Popup ) != k_polynomFit;
			ShowScaleAndErrors();	//	( npoly, false );
			Refresh();
		};
	virtual void	SaveDialog()
		{	saved 		= true;
			RegScaleView()->GetScale( saved_From, saved_To, saved_Step );	
			saved_Degree = (UInt32)GetDValue( kFitting_degree );
			//saved_FunctionType	= GetPopupValue( kFitting_Funct_Popup );
			//saved_FitType		= GetPopupValue( kFitting_type_Popup );
			
			switch (GetPopupValue( kFitting_type_Popup ))
			{	case k_meanSquareFit:	saved_Fit_Flag = MyMath::fit_func::stdFit;	break;
				case k_meanAbsFit:		saved_Fit_Flag = MyMath::fit_func::absFit;	break;
			};
			switch (GetPopupValue( kFitting_Funct_Popup ))
			{	case k_linearFit:			saved_FunctionType = MyMath::LinearInterpFunctionCode;	break;
				case k_polynomFit:			saved_FunctionType = MyMath::PolynomialFunctionCode;	break;
				case k_staircaseFit:		saved_FunctionType = MyMath::StairInterpFunctionCode;	break;
				case k_cubic_splineFit:		saved_FunctionType = MyMath::SplineInterpFunctionCode;	break;
			};
		};

	Boolean	DoFit( size_t i )
	/*	{	if (GetRadioValue( kFitting_evenly_Radio ) )	return true;
			else
			{	CDynamicPaneTable*	table = GetDynTable(kFitting_DynTable);
				if (i>=1 && i<= table->CountNodes())
					return	(table->GetCheckBoxInCell( STableCell(i,1), kFitList_do_CheckBox )->GetValue());
				else	return false;
			}
		};*/
		{	Boolean doFit = true;
			if (!isRegular())	doFit = UnevenScaleView()->DoResample( i );
			STableItem1D*	item = theItem->item_1D(i);
			if (item == Get_Error_Y_Series())	doFit = false;
			if (item == Get_Error_X_Series())	doFit = false;
			return doFit;
		};
/*	double_vector*	x_scale()
		{	if (GetRadioValue( kFitting_evenly_Radio ) )
				return new MyMath::double_regular_array( saved_From, saved_To, saved_Step );
			else
				return new double_vector( *checkedVector );
		};
*/	double_vector*	x_scale()
		{	if (isRegular())	return new MyMath::double_regular_array( saved_From, saved_To, saved_Step );
			else				return new double_vector( *(UnevenScaleView()->checkedVector) );
		};
	size_t			degree()
		{	if (GetPopupValue( kFitting_Funct_Popup ) == k_polynomFit)
				return (size_t)GetDValue( kFitting_degree );
			else	return 0;
		};
	double		Error_Y()
		{	if (GetPopupValue( kFitting_error_Popup ) == k_y_cst_Err || GetPopupValue( kFitting_error_Popup ) == k_xy_cst_Err)
					return	GetDValue( kFitting_y_err_cste );
			else	return MyMath::NaN();
		};
	double		Error_X()
		{	if (GetPopupValue( kFitting_error_Popup ) == k_xy_cst_Err)
					return	GetDValue( kFitting_x_err_cste );
			else	return MyMath::NaN();
		};
	STableItem1D*	Get_Error_Y_Series()
		{	if (GetPopupValue( kFitting_error_Popup ) == k_y_Err || GetPopupValue( kFitting_error_Popup ) == k_xy_Err)
					return	ErrorView()->GetFirstCheckedSeries( true );
			else	return nil;
		}
	STableItem1D*	Get_Error_X_Series()
		{	if (GetPopupValue( kFitting_error_Popup ) == k_xy_Err)
					return	ErrorView()->GetFirstCheckedSeries( false );
			else	return nil;
		}
		
protected:

	virtual	SInt16	rPPob()	{	return	rPPob_FittingDialog;	};
	
};

/*

class CFitErrorDialog : public CMyStdDialog {
private:
	CFittingDialog* fDialog;
	size_t			i0;
	
	void	SetPopupList( PaneIDT popupID );
	void	SelectSomeSeries( Boolean is_x );		//	choose series in CGroupTable, add them in popmenu and select first one.
	size_t	GetItem( PaneIDT popupID );
	void	SelectItem( PaneIDT popupID, STableItem* selectedItem );
	
	Boolean	checkItem( const STableItem1D* item_i )	const	//	items to display in menu, to choose from
		{	STableItem1D* item_0 = fDialog->theItem->item_1D(i0);
			return ( (item_i != item_0) && (item_i->x_Axis->x->check_same_as( *(item_0->x_Axis->x) )) );
		};
		
public:
	enum { class_ID = 'ErrD' };
	
	CFitErrorDialog( LStream *inStream )	: CMyStdDialog( inStream )	{	fDialog = NULL;	};
	~CFitErrorDialog()	{};
	
	void	SetupFittingDialog( CFittingDialog* dialog, double err_y, double err_x, size_t i  )
		{	fDialog = dialog;
			i0 = i;
			PaneIDT	popup =	fDialog->GetPopupValue( kFitting_error_Popup );
			LStr255 sname("Errors on ");	sname += fDialog->theItem->item_1D(i0)->Name();
			GetStaticText( kFitError_title_StatTxt  )->SetDescriptor( sname );
			GetStaticText( kFitError_y_StatTxt  )->Hide();
			GetEditText	 ( kFitError_y_cste 	)->Hide();
			GetStaticText( kFitError_x_StatTxt  )->Hide();
			GetEditText  ( kFitError_x_cste 	)->Hide();
			GetPopup	 ( kFitError_y_Popup 	)->Hide();
			GetPopup	 ( kFitError_x_Popup 	)->Hide();
			if (popup == k_y_cst_Err || popup == k_xy_cst_Err)
				{	GetStaticText( kFitError_y_StatTxt )->Show();	GetEditText( kFitError_y_cste )->Show();	SetDValue( kFitError_y_cste, err_y );	}
			if (popup == k_xy_cst_Err)
				{	GetStaticText( kFitError_x_StatTxt )->Show();	GetEditText( kFitError_x_cste )->Show();	SetDValue( kFitError_y_cste, err_x );	}
			if (popup == k_y_Err || popup == k_xy_Err)
			{	GetPopup( kFitError_y_Popup )->Show();
				SetPopupList( kFitError_y_Popup );
			}
			if (popup == k_xy_Err)
			{	GetPopup( kFitError_x_Popup )->Show();
				SetPopupList( kFitError_x_Popup );
			}	
		};
	size_t GetYItem()
		{	size_t yItem = 0;
			PaneIDT	popup =	fDialog->GetPopupValue( kFitting_error_Popup );
			if (popup == k_y_Err || popup == k_xy_Err)
				yItem = GetItem( kFitError_y_Popup );
			return	yItem;
		}
	size_t GetXItem()
		{	size_t	xItem = 0;
			PaneIDT	popup =	fDialog->GetPopupValue( kFitting_error_Popup );
			if (popup == k_xy_Err)
				xItem = GetItem( kFitError_x_Popup );
			return	xItem;
		}

	virtual void	ListenToMessage( MessageT inMessage, void *ioParam );
	
	Boolean	validItem( const STableItem1D* item_i )	const;	//	idem "checkItem" but with error messages
	
	
		
protected:
	virtual	SInt16	rPPob()	{	return	rPPob_FitErrorDialog;	};
};


class	FitSelectFunction : public TestItemFunction {
private:
	CFitErrorDialog* dialog;
protected:
	virtual Boolean	func( const STableItem* it ) const
		{	const STableItem1D* it1D = dynamic_cast<const STableItem1D*>(it);
			if (it1D == nil)	return false;
			else				return	dialog->validItem( it1D );
		};
public:
	FitSelectFunction( CFitErrorDialog* d ):dialog(d)	{};
};


*/