
#pragma once

#include <sstream>
#include <LCaption.h>
#include <LEditText.h>
#include <LLittleArrows.h>
#include "CMyStdDialogs.h"
#include "CSelectionDialog.h"
#include "CGroupTableItem.h"


//	CRegScaleView


const ResIDT	rPPob_RegScaleView	= 1080;
const PaneIDT	kRegScale_From		= 1;
const PaneIDT	kRegScale_To		= 2;
const PaneIDT	kRegScale_Step		= 3;
const PaneIDT	kRegScale_Adjust	= 4;
const PaneIDT	kRegScale_Npts_txt	= 5;
const PaneIDT	kRegScale_Extra_txt	= 6;
const PaneIDT	kRegScale_ActualStp	= 7;

const MessageT	msg_RegScaleTextChanged		= 1056;
const MessageT	msg_RegScaleAdjust			= 1057;

//	CUnevenScaleView


const ResIDT	rPPob_UnevenScaleView	= 1081;
const PaneIDT	kUnevenScale_DynTable	= 10;
const PaneIDT	kUnevenScale_Npts_Txt	= 11;
const PaneIDT	kUnevenScale_Caption	= 12;
const PaneIDT	kUnevenScale_YCaption	= 13;
const ResIDT	rPPob_UnevenScaleList_Subpane	= 1055;
const PaneIDT	kUnevenScaleList_use_CheckBox	= 1;
const PaneIDT	kUnevenScaleList_do_CheckBox	= 2;
const MessageT	msg_UseScaleChanged				= 1060;
const MessageT	msg_AddNewSeries				= 3100;

//	CSeriesCheckView  =  same resource than above !!

const ResIDT	rPPob_SeriesCheckView	= 1082;


class CRegScaleView : public LView, public LListener, public LBroadcaster {
private:
	bool		has_min;
	bool		has_max;
	double		min_x;
	double		max_x;
	
	double	GetDValue( PaneIDT paneID, Boolean& io_isOk )
	{	double	v = 0;
		if (io_isOk)
		{	Str255	ptxt;		GetEditText(paneID)->GetDescriptor(ptxt);
			char	txt[255];	TCLptocstrcpy( txt, ptxt );
			std::istringstream s(txt);
			s >> v;
			io_isOk = s.eof() && !(s.fail());
		}
		return v;
	}
	void	SetDValue( PaneIDT paneID, double inValue )
	{	std::ostringstream s;	s << inValue << '\0';
		Str255	ptxt;		TCLctopstrcpy( ptxt, s.str().c_str() );
		GetEditText(paneID)->SetDescriptor ( ptxt );
	}
	LStaticText*	GetStaticText( PaneIDT paneID )				DefineGetField( LStaticText, paneID );
//	{	return	GetField<LStaticText>(this,paneID);		};
	LEditText*		GetEditText( PaneIDT paneID )				DefineGetField( LEditText, paneID );
//	{	return	GetField<LEditText>(this,paneID);		};
	LLittleArrows*	GetLittleArrows( PaneIDT paneID )			DefineGetField( LLittleArrows, paneID );
//	{	return	GetField<LEditText>(this,paneID);		};
public:
	enum { class_ID = 'RSvw' };
	
	CRegScaleView( LStream *inStream ) : LView( inStream )
		{	has_min = false;	has_max = false;	};
	
	virtual void	FinishCreateSelf()
		{	UReanimator::LinkListenerToControls( this, this, rPPob() );
		};
//	void	SetMin( double x )	{	has_min = true;		min_x = x;	};
//	void	SetMax( double x )	{	has_max = true;		max_x = x;	};
	
	
	void	SetupDialogScale( double max_, double min_, double stp_ )
		{	has_min = true;		min_x = min_;
			has_max = true;		max_x = max_;
			if ((stp_ > 0) && (max_x > min_x))
			{	double	rst = MyMath::Arondi( stp_, MyMath::round_nearest, 3 );	//	rounded step
				size_t	n1 = MyMath::long_round( (max_x - min_x)/rst );			//	Nb of points - 1
				double	xn = min_x + n1 * rst;
				if (xn > max_x)
					xn = min_x + (--n1) * rst;
				SetValues( min_x, xn, rst );
				//ShowEvenScale( true );
				SetNbText();
			}
		};
		
	void	SetValues( double from, double to, double step )
		{	SetDValue( kRegScale_From, from );
			SetDValue( kRegScale_To,   to );
			SetDValue( kRegScale_Step, step );
		};
	Boolean	GetScale( double& from, double& to, double& step )
		{	Boolean	isOk = true;
			from = GetDValue( kRegScale_From, isOk );
			to   = GetDValue( kRegScale_To,   isOk );
			step = GetDValue( kRegScale_Step, isOk );
			return isOk;
		};
	Boolean	ValidView()
		{	double	from, to, step;
			Boolean	isOk = GetScale( from, to, step );
			if (!isOk)				MySimpleAlert( "\pSome numerical fields are unreadable" );
			else if (step <= 0)		MySimpleAlert( "\pThe time step must be positive" );
			else if (to <= from)	MySimpleAlert( "\pThe final time must be larger than the starting time" );
			return ( isOk && (step > 0) && (to > from) );
		};
		
	void	SetNbText()
		{	double	from, to, step;
			if ( GetScale( from, to, step ) )
			{	unsigned long n = 1 + MyMath::long_round((to - from)/step);
				ostringstream s;
				s << "The new series will have " << n << " points";
				Str255	ptxt;	TCLctopstrcpy( ptxt, s.str().c_str() );
				GetStaticText( kRegScale_Npts_txt )->SetDescriptor( ptxt );
				
				double	dstep	= step * 1e-8;
				double	newto = from + (n-1)*step;
				if (fabs(newto - to) > dstep)
				{	double	ss = (to-from)/(n-1);
					ostringstream s2;
					s2 << "!! The actual step will be " << ss << " !!";
					Str255	ptxt2;	TCLctopstrcpy( ptxt2, s2.str().c_str() );
					GetStaticText( kRegScale_ActualStp )->SetDescriptor( ptxt2 );
				}
				else
					GetStaticText( kRegScale_ActualStp )->SetDescriptor( "\p" );
			}
			else
			{	GetStaticText( kRegScale_Npts_txt )->SetDescriptor( "\p" );
				GetStaticText( kRegScale_ActualStp )->SetDescriptor( "\p" );
			}
			if ( (has_min && (from < min_x)) || (has_max && (to > max_x)) )
					GetStaticText( kRegScale_Extra_txt )->Show();
			else	GetStaticText( kRegScale_Extra_txt )->Hide();
		};

	virtual void	ListenToMessage( MessageT inMessage, void* )
		{	switch ( inMessage ) {
				case msg_RegScaleTextChanged:
				SetNbText();
				break;
				
				case msg_RegScaleAdjust:
				{	//LLittleArrows*	arrows = GetField<LLittleArrows>( this, kRegScale_Adjust );
					LLittleArrows*	arrows = GetLittleArrows( kRegScale_Adjust );
					int i = arrows->GetValue();
					double	from, to, step;
					if ( GetScale( from, to, step ) )
					{	double	dstep	= step * 1e-8;
						unsigned long n = 1 + MyMath::long_round((to - from)/step);
						double	newto = from + (n-1)*step;
						if (newto - to < dstep && i==1)
							SetDValue( kRegScale_To, newto+step );
						else if (to - newto < dstep && i==-1)
							SetDValue( kRegScale_To, newto-step );
						else
							SetDValue( kRegScale_To, newto );
						SetNbText();
					}
					StopListening();
					arrows->SetValue(0);
					StartListening();
				}
				break;
		
			default:
				//LListener::ListenToMessage( inMessage, ioParam );
				break;
			}
		};
	
protected:

	virtual	SInt16	rPPob()	{	return	rPPob_RegScaleView;	};
};



class CMultiItemRegScaleView : public CRegScaleView {
private:
	STableItem1D*	theItem;
public:
	enum { class_ID = 'MSvw' };
	
	CMultiItemRegScaleView( LStream *inStream ) : CRegScaleView( inStream )
		{	theItem = NULL;	};
	
	void	SetupDialogScale( STableItem1D*	item, bool y_scale = false )
		{	theItem 	= item;
			size_t nb	= theItem->TableSize();
				//	set up evenly-spaced scale: 1/ find max_x1, min_xn, min_st
			double_vector&	x0 = (y_scale ? *(theItem->Vector()) : *(theItem->x_Axis->x));
			double	max_x1 = x0[1];
			double	min_xn = x0[x0.length()];
			double	min_st  = (min_xn-max_x1) / (x0.length()-1);	//	mean step value
			for (size_t i=2; i<=nb; i++)
			{	double_vector&	x = (y_scale ? *(theItem->item_1D(i)->Vector()) : *(theItem->item_1D(i)->x_Axis->x));
				size_t 	n 	= x.length();
				double	st  = (x[n]-x[1]) / (x.length()-1);
				if (x[1] > max_x1)	max_x1 = x[1];
				if (x[n] < min_xn)	min_xn = x[n];
				if (st   < min_st)	min_st = st;					//	minimum of mean step values
			}
			CRegScaleView::SetupDialogScale( min_xn, max_x1, min_st );	
		};
};



class CSeriesCheckView : public LView, public LListener, public LBroadcaster {
protected:
	Boolean 		show2ndCheckBox;
	STableItem1D*	theItem;
	LStaticText*	GetStaticText( PaneIDT paneID )				DefineGetField( LStaticText, paneID );
	//	{	return	GetField<LStaticText>(this,paneID);		};
	LCaption*		GetCaption( PaneIDT paneID )				DefineGetField( LCaption, paneID );
//	{	return	GetField<LCaption>(this,paneID);		};
	CDynamicPaneTable*		GetDynamicPaneTable( PaneIDT paneID )				DefineGetField( CDynamicPaneTable, paneID );
//	{	return	GetField<CDynamicPaneTable>(this,kUnevenScale_DynTable);	};
public:
	enum { class_ID = 'SCvw' };
	
	CSeriesCheckView( LStream *inStream ) : LView( inStream )
		{	theItem = NULL;		show2ndCheckBox = true;	};
	
	virtual void	FinishCreateSelf()
		{	UReanimator::LinkListenerToBroadcasters( this, this, rPPob() );
		};

	virtual void	ListenToMessage( MessageT inMessage, void* )
		{	switch ( inMessage ) {
				case msg_AddNewSeries:
					StopListening();
					AddSomeSeries();
					StartListening();
				break;
				default:
					//LListener::ListenToMessage( inMessage, ioParam );
				break;
			}
		};
	Boolean	hasItem( const STableItem* it ) const
		{	return	(theItem->the_item_Table().FindInTable( it ) > 0);	};
	virtual void	AddSomeSeries();
	void	ShowSecondCheckBox( Boolean show )
		{	show2ndCheckBox = show;
			UpdateSecondCheckBox();
		};
	void	UpdateSecondCheckBox()
		{	LCaption*	capt = GetCaption( kUnevenScale_Caption );		//	GetField<LCaption>(this,kUnevenScale_Caption);
			if (show2ndCheckBox)	capt->Show();
			else					capt->Hide();
			CDynamicPaneTable*	table = GetDynamicPaneTable( kUnevenScale_DynTable );	//	GetField<CDynamicPaneTable>(this,kUnevenScale_DynTable);
			for (int i=1; i<= table->CountNodes(); i++)
				if (show2ndCheckBox)	table->GetCheckBoxInCell( STableCell(i,1), kUnevenScaleList_do_CheckBox )->Show();
				else					table->GetCheckBoxInCell( STableCell(i,1), kUnevenScaleList_do_CheckBox )->Hide();
		};
		
	void	SetupDialogScale( STableItem1D*	item )
		{	theItem 	= item;
			size_t nb	= theItem->TableSize();
			for (size_t i=1; i<=nb; i++)
				AddCheckList( theItem->item_1D(i), i==1 );		//	check first series only
		};
	void	SetCaption( const unsigned char* t )
		{	LCaption*	capt = GetCaption( kUnevenScale_Caption );		//	GetField<LCaption>(this,kUnevenScale_Caption);
			capt->SetDescriptor( t );
		};
	void	SetYCaption( const unsigned char* t )
		{	LCaption*	capt = GetCaption( kUnevenScale_YCaption );		//	GetField<LCaption>(this,kUnevenScale_YCaption);
			capt->SetDescriptor( t );
		};
	void	AddCheckListName( const unsigned char* name, Boolean check_use=false, Boolean check_do=true )
		{	CDynamicPaneTable*	table = GetDynamicPaneTable( kUnevenScale_DynTable );	//	GetField<CDynamicPaneTable>(this,kUnevenScale_DynTable);
			table->AddNewView( rPPob_UnevenScaleList_Subpane, nil, this );
			SDimension16 fsize;
			LCheckBox* chbx = table->GetCheckBoxInCell( STableCell(table->CountNodes(),1), kUnevenScaleList_use_CheckBox );
			chbx->GetFrameSize( fsize );
			Str255	txt;	LString::CopyPStr( name, txt );
			::TruncString( fsize.width - 15 ,txt, truncEnd );
			chbx->SetDescriptor(txt);
			chbx->SetValue(check_use);
			table->GetCheckBoxInCell( STableCell(table->CountNodes(),1), kUnevenScaleList_do_CheckBox )->SetValue(check_do);
		};
	void	AddCheckList( STableItem1D* item, Boolean check_use=false, Boolean check_do=true )
		{	AddCheckListName( item->FileName(), check_use, check_do );
		};
	Boolean	DoResample( size_t i )
		{	CDynamicPaneTable*	table = GetDynamicPaneTable( kUnevenScale_DynTable );	//	GetField<CDynamicPaneTable>(this,kUnevenScale_DynTable);
			if (i>=1 && i<= table->CountNodes())
				return	(table->GetCheckBoxInCell( STableCell(i,1), kUnevenScaleList_do_CheckBox )->GetValue());
			else	return false;
		};
	Boolean	ValidSeriesView( long max_y, long min_y, LStr255 txt_y, long max_x, long min_x, LStr255 txt_x )		//	max_ = n (at most n), min_ = n (at least n), max_ = 0 (dont care)
		{	Boolean isOk = true;
			CDynamicPaneTable*	table = GetDynamicPaneTable( kUnevenScale_DynTable );	//	GetField<CDynamicPaneTable>(this,kUnevenScale_DynTable);
			if (max_y != 0 || min_y != 0)
			{	int sum_y = 0;
				for (size_t i=1; i<= table->CountNodes(); i++)
				{	if (table->GetCheckBoxInCell( STableCell(i,1), kUnevenScaleList_use_CheckBox )->GetValue())
						sum_y++;
				}
				isOk = ( ((max_y == 0) || (max_y >= sum_y)) && ((min_y == 0) || (sum_y >= min_y)) );
				if (!isOk)
				{	LStr255 txt = LStr255("\pYou need to check ");
					if ( (max_y != min_y) && (max_y != 0) && (min_y != 0) )	txt += LStr255("\pexactly ") + LStr255(max_y) + LStr255("\p ");
					else
					{	size_t i = txt.Length();
						if ((max_y != 0) && (max_y < sum_y))	txt += LStr255("\pat most ")  + LStr255(max_y) + LStr255("\p ");
						if ((min_y != 0) && (min_y > sum_y))
						{	if (i != txt.Length())				txt += LStr255("\pand ");
							txt += LStr255("\pat least ") + LStr255(min_y) + LStr255("\p ");
					}	}
					MySimpleAlert( txt + txt_y );
			}	}
			if (isOk && (max_x != 0 || min_x != 0))
			{	int sum_x = 0;
				for (size_t i=1; i<= table->CountNodes(); i++)
				{	if (table->GetCheckBoxInCell( STableCell(i,1), kUnevenScaleList_do_CheckBox )->GetValue())
						sum_x++;
				}
				isOk = ( ((max_x == 0) || (max_x >= sum_x)) && ((min_x == 0) || (sum_x >= min_x)) );
				if (!isOk)
				{	LStr255 txt = LStr255("\pYou need to check ");
					if ( (max_x != min_x) && (max_x != 0) && (min_x != 0) )	txt += LStr255("\pexactly ") + LStr255(max_x) + LStr255("\p ");
					else
					{	size_t i = txt.Length();
						if ((max_x != 0) && (max_x < sum_x))	txt += LStr255("\pat most ")  + LStr255(max_x) + LStr255("\p ");
						if ((min_x != 0) && (min_x > sum_x))
						{	if (i != txt.Length())				txt += LStr255("\pand ");
							txt += LStr255("\pat least ") + LStr255(min_x) + LStr255("\p ");
					}	}
					MySimpleAlert( txt + txt_x );
			}	}
			return isOk;
		};
	STableItem1D*	GetFirstCheckedSeries( Boolean useChck )
		{	CDynamicPaneTable*	table = GetDynamicPaneTable( kUnevenScale_DynTable );	//	GetField<CDynamicPaneTable>(this,kUnevenScale_DynTable);
			int nb = table->CountNodes();
			STableItem1D*	firstChecked = nil;
			for (int i=1; i<=nb && !firstChecked; i++)
			{	if ( useChck && (table->GetCheckBoxInCell( STableCell(i,1), kUnevenScaleList_use_CheckBox )->GetValue()))
					firstChecked = theItem->item_1D(i);
				if ( !useChck && (table->GetCheckBoxInCell( STableCell(i,1), kUnevenScaleList_do_CheckBox )->GetValue()))
					firstChecked = theItem->item_1D(i);
			}
			return firstChecked;
		}
		
		
protected:

	virtual	SInt16	rPPob()	{	return	rPPob_SeriesCheckView;	};
};




class CUnevenScaleView : public CSeriesCheckView {
public:
	double_vector*	checkedVector;
	bool use_y_scale;
	
	enum { class_ID = 'USvw' };
	
	CUnevenScaleView( LStream *inStream ) : CSeriesCheckView( inStream )
		{	checkedVector	= NULL;		use_y_scale = false;	/*theItem = NULL;*/	};
		
	~CUnevenScaleView()
		{	delete checkedVector;	};
	
	virtual void	ListenToMessage( MessageT inMessage, void* info )
		{	switch ( inMessage ) {
				case msg_DynPaneTableChanged:
				{	CDynamicViewMessage*	messageInfo = (CDynamicViewMessage*)info;
					if (messageInfo->mMessage == msg_UseScaleChanged)
					{	Make_x_scale();
						SetNbText();
					}
				}
				break;
				default:
					CSeriesCheckView::ListenToMessage( inMessage, info );
				break;
			}
		};
	virtual void	AddSomeSeries();
	void	SetupDialogScale( STableItem1D*	item )		//	, bool y_scale = false )
		{	CSeriesCheckView::SetupDialogScale( item );
			//use_y_scale = y_scale;
			AddToVector( theItem->item_1D(1) );
			SetNbText();
		};
	void	SetupYScale( bool y_scale = false )
		{	use_y_scale = y_scale;
			//AddToVector( theItem->item_1D(1) );
			Make_x_scale();
			SetNbText();
		};
	void	Make_x_scale()
		{	delete checkedVector;	checkedVector = NULL;
			CDynamicPaneTable*	table = GetDynamicPaneTable( kUnevenScale_DynTable );	//	GetField<CDynamicPaneTable>(this,kUnevenScale_DynTable);
			int nb = table->CountNodes();
			for (int i=1; i<=nb; i++)
				if (table->GetCheckBoxInCell( STableCell(i,1), kUnevenScaleList_use_CheckBox )->GetValue())
					AddToVector( theItem->item_1D(i) );
		}
	void	AddToVector( STableItem1D* item )
		{	if (checkedVector == NULL)	checkedVector = new double_vector( (use_y_scale ? *(item->Vector()) : *(item->x_Axis->x)) );
			else						checkedVector->insert_vector( (use_y_scale ? *(item->Vector()) : *(item->x_Axis->x)), true, 1e-10 );
		};
	void	SetNbText()
		{	unsigned long n = 0;
			ostringstream s;
			if (checkedVector != NULL)
			{	n = checkedVector->length();
				s << "New x-scale: " << n << " points, from "
					<< (*checkedVector)[1] << " to " << (*checkedVector)[n];
			}
			else	s << "Check at least one scale !!";
			Str255	ptxt;	TCLctopstrcpy( ptxt, s.str().c_str() );
			LStaticText* txt = GetStaticText( kUnevenScale_Npts_Txt );
			txt->SetDescriptor( ptxt );
		};
	Boolean	ValidView()
		{	Boolean isOk = (checkedVector != NULL);
			if (isOk) 		isOk = (checkedVector->length() > 0);
			if (!isOk)		MySimpleAlert( "\pCheck at least one scale" );
			else			isOk = ValidSeriesView( 0, 1, LStr255("\p x-scale"), 0, 1, LStr255("\p series to fit") );
			return isOk;
		};
		
		
protected:

	virtual	SInt16	rPPob()	{	return	rPPob_UnevenScaleView;	};
};


class	DefSelectFunction : public TestItemFunction {
private:
	CSeriesCheckView* view;
protected:
	virtual Boolean	func( const STableItem* it ) const
		{	const STableItem1D* it1D = dynamic_cast<const STableItem1D*>(it);
			if (it1D == nil)	return false;
			else				return !(view->hasItem( it ));		
		};
public:
	DefSelectFunction( CSeriesCheckView* v ):view(v)	{};
};



