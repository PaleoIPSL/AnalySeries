// =================================================================================
//	CTextDocument.h					�1996-1998 Metrowerks Inc. All rights reserved.
// =================================================================================

#pragma once

#include <LSingleDoc.h>
#include <LCaption.h>
#include <LPeriodical.h>

//const CommandT	cmd_RefreshMemView				= 11000;

class CGroupTable;


class CMemView : public LCaption, public LPeriodical	{
protected:
	UInt32			mNextIdleTick;
	static const UInt32	TickFreq = 60;
public:
	enum { class_ID = 'memV' };
	CMemView( LStream *inStream ) : LCaption( inStream )
		{	mNextIdleTick = ::TickCount() + TickFreq;
			StartIdling();
		};
	
	virtual void	SpendTime( const EventRecord& )
		{		// Regulate "speed" of animation by idling at most TickFreq frequency
			if (::TickCount() >= mNextIdleTick)
			{	long	fMem = ::FreeMem();
				LStr255	text( "\p  Free memory: " );	text += (fMem/1024);	text += " K";
				SetDescriptor( text );
				Refresh();
				mNextIdleTick = ::TickCount() + TickFreq;
			}
		}

};


class binaryStream;


class CTextDocument : public LSingleDoc {
public:
						CTextDocument( LCommander *inSuper, FSSpec *inFileSpec );

	virtual Boolean		IsModified();
	
	virtual void		DoAESave( FSSpec &inFileSpec, OSType inFileType );
	virtual void		DoSave();
	virtual void		DoRevert();
	virtual void		DoPrint();
	
	static void			DoPrintPane( LPane* paneToPrint, LPrintSpec& printSpec );
	
	virtual void		Close();
	
	binaryStream* 		TheBinaryStream();
	
//	virtual	void		FindCommandStatus( CommandT inCommand, Boolean &outEnabled, Boolean	&outUsesMark, UInt16 &outMark, Str255 outName );
	
	
/*	
//	virtual Boolean		ObeyCommand( CommandT inCommand, void *ioParam );
	
	void				RefreshMemoryView();
	static void	RefreshMemView( LCommander *com )
		{	LCommander*		super 		= com->GetSuperCommander();
			CTextDocument*	txtsuper 	= dynamic_cast<CTextDocument*>(super);
			while (txtsuper == NULL && super != NULL)
			{	super = super->GetSuperCommander();		txtsuper = dynamic_cast<CTextDocument*>(super);	}
			if (txtsuper)	txtsuper->RefreshMemoryView();
		};
*/

	Boolean				IsDirty() const					{	return mIsDirty;		};
	void				SetDirty( Boolean inDirty )		{	mIsDirty = inDirty;		};
	
	CGroupTable *		TableView()	{	return mTableView;	};
	
protected:
	bool				mIsDirty;
	
protected:
	CGroupTable *		mTableView;
	CMemView *			mMemView;

	void				NameNewDoc();
	void				OpenFile( FSSpec &inFileSpec );
	void				SetPrintFrameSize(void);
};