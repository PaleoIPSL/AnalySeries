
#include "myMath.h"
#include "CMyStdDialogs.h"
#include "plotRecord.h"
#include "CDynamicPaneTable.h"
#include "CDrawingView.h"




//	CFilteringDialog

const ResIDT	rPPob_FilteringDialog		= 1013;
const PaneIDT	kFiltering_DrawView			= 3;
const PaneIDT	kFiltering_FuncPopup		= 4;
const PaneIDT	kFiltering_Frequency		= 5;
const PaneIDT	kFiltering_Bandwidth		= 6;
const PaneIDT	kFiltering_Slopewidth		= 7;
const PaneIDT	kFiltering_Frequ_StatTxt	= 9;
const PaneIDT	kFiltering_Bandw_StatTxt	= 10;
const PaneIDT	kFiltering_Slopew_StatTxt	= 11;
const PaneIDT	kFiltering_Notch_ChkBox		= 12;
const PaneIDT	kFiltering_x_ZoomAdjust		= 13;
const PaneIDT	kFiltering_x_ZoomCaption	= 14;

const MessageT	msg_FilterFuncChanged		= 1050;
const MessageT	msg_FilterParamChanged		= 1060;

const MessageT	msg_Filter_x_ZoomAdjust		= 1003;

const PaneIDT	k_gaussianFilter			= 1;
const PaneIDT	k_piecewiseLinearFilter		= 2;
const PaneIDT	k_sym_gaussianFilter		= 4;



//class CDrawingView;

class CFilteringDialog : public CMyStdDialog {
public:
	STableItem1D*	inputItem;
	STableItem1D*	filterItem;
//	size_t			item_nb()		{	return	1 + inputItem->itemTableSize;	};
	double_vector1	in_px;
	double_vector1	in_py;
			
private:
	CDrawingView*	drawView;
	
	void	HideAndShow()
		{	switch( GetPopupValue( kFiltering_FuncPopup ) ) {
				case k_gaussianFilter:
				case k_sym_gaussianFilter:
					GetEditText( kFiltering_Slopewidth )->Hide();
					GetStaticText( kFiltering_Slopew_StatTxt )->Hide();
					break;
				case k_piecewiseLinearFilter:
					GetEditText( kFiltering_Slopewidth )->Show();
					GetStaticText( kFiltering_Slopew_StatTxt )->Show();
					break;
			}
		};
	void	ResetFunction()
		{	if (filterItem)		{	delete	filterItem;	filterItem = NULL;	}
			const double_vector& in_x = *(inputItem->x_Axis->x);
			if (! in_x.check_regular())		MyMath::ThrowError( "bad scale in CFilteringDialog::ResetFunction" );
			double	freq	= GetDValue( kFiltering_Frequency );
			double	bwidth	= GetDValue( kFiltering_Bandwidth );
			double	slwidth	= GetDValue( kFiltering_Slopewidth );
			double	fc = 1.0/(2*(in_x[2]-in_x[1]));
			SInt32	popup	= GetPopupValue( kFiltering_FuncPopup );
			plotRecord*	pRec = NULL;
			Boolean	check = ( (freq >= 0) && (freq <= fc) && (bwidth > 0) );
			check = check && ( popup == k_gaussianFilter || popup == k_sym_gaussianFilter || ( (slwidth <= bwidth) && (bwidth - slwidth < freq) && (slwidth > 0) ) );
			if ( check )
			{	double_vector1*	pxf = NULL;
				MyMath::simplefunc*	func = NULL;
				switch( popup ) {
					case k_gaussianFilter:
					case k_sym_gaussianFilter:
						{	size_t nn = 1;
							if (GetCheckBoxValue( kFiltering_Notch_ChkBox ))	nn = 2;
							double_vector1 fr(nn);	fr(nn) = freq;
							double_vector1 bw(nn);	bw(nn) = bwidth;
							double_vector1 c(nn);	c(nn)  = 1.0;
							if (GetCheckBoxValue( kFiltering_Notch_ChkBox ))	{	fr(1) = 0;	bw(1) = 0;	c(1)  = 1.0;	c(nn) = -1.0;	};
							if (popup == k_sym_gaussianFilter)
								func = new MyMath::gaussian_filter_func( c, fr, bw, true );
							else
								func = new MyMath::gaussian_sum_func( c, fr, bw );
							pxf = new double_vector1(3);	double_vector1& xf  = *pxf;
							xf(1) = 0;		xf(2) = freq;		xf(3) = fc;
						}
						break;
					case k_piecewiseLinearFilter:
						{	double_vector1 x(6);
							double_vector1 y(6);
							size_t	k=1;
							x(k) = 0;	y(k) = 0;
							if (freq-bwidth-slwidth > 0)	{	x(++k) = freq-bwidth-slwidth;	y(k) = 0;				}
							else							{	x(k) = 0;	y(k) = -(freq-bwidth-slwidth)/(2*slwidth);	}
							x(++k) = freq-bwidth+slwidth;	y(k) = 1;
							if (freq+bwidth-slwidth >= fc)	{	x(++k) = fc;	y(k) = 0;	}
							else
							{	if (freq+bwidth-slwidth > freq-bwidth+slwidth)  //	sinon (slwidth == bwidth), un seul point
									x(++k) = freq+bwidth-slwidth;	y(k) = 1;
								if (freq+bwidth+slwidth <= fc)
								{	x(++k) = freq+bwidth+slwidth;	y(k) = 0;
									if (freq+bwidth+slwidth < fc)	{	x(++k) = fc;	y(k) = 0;	}
								}
								else	{	x(++k) = fc;	y(k) = (freq+bwidth+slwidth-fc)/(2*slwidth);	}
							}
							x.resize_but_keep(k);	y.resize_but_keep(k);
							if (GetCheckBoxValue( kFiltering_Notch_ChkBox ))
								for (size_t i=1; i<=y.length(); i++)	y(i) = 1-y(i);
							func = new MyMath::lin_interpolfunc( x, y, true );
							pxf = new double_vector1(x.length());	double_vector1& xf  = *pxf;
							for (size_t i=1; i<=x.length(); i++)	xf(i) = x(i);
						}
						break;
				}
				double_vector1& xf  = *pxf;		double_vector1*	pyf = new double_vector1(xf.length());		double_vector1& yf  = *pyf;
				for (size_t i=1; i<=xf.length(); i++)	yf(i) = func->ValueAt(xf(i));
				STableItemInfo	info( "\pfilter", "\pFilter", "", "\pFiltering" );
				//filterItem = new STableItem1D(  pxf, pyf, func, "\pfrequency", "\pfilter", "\pFilter", "" );
				filterItem = new STableItem1D(  pxf, pyf, func, "\pfrequency", info );
				pRec = filterItem->MakePlotRecord();
				
				line_type*	lt = new macLineType( macLineType::qdColors, 1 );
				std::string	s("filter");
				pRec->AddCurve( in_px, in_py, s, lt );
				pRec->SetMultYScale();
			}
			drawView->AttachRecord( pRec );
			drawView->Refresh();
		};

public:
	static Boolean	saved;
	static double	saved_Freq;
	static double	saved_Bw;
	static double	saved_SlopeW;
	static Boolean	saved_Notch;
	static SInt32	saved_FunctionType;
public:
	enum { class_ID = 'FilD' };
	
	CFilteringDialog( LStream *inStream )	: CMyStdDialog( inStream )
		{	inputItem			= NULL;
			filterItem			= NULL;
			drawView			= NULL;
			//checkedVector	= NULL;
		};
	~CFilteringDialog()
		{	//DeleteAllSubPanes();
			//delete checkedVector;
		};

	virtual void	ListenToMessage( MessageT inMessage, void *ioParam )
		{	switch ( inMessage ) {
				case msg_FilterFuncChanged:
					HideAndShow();
					ResetFunction();
					break;
				case msg_FilterParamChanged:
					ResetFunction();
					break;
				default:
					LDialogBox::ListenToMessage( inMessage, ioParam );
					break;
			}
		};
	virtual void	SetupDialog()
		{	if (saved)
			{	SetDValue( kFiltering_Frequency, saved_Freq );
				SetDValue( kFiltering_Bandwidth, saved_Bw );
				SetDValue( kFiltering_Slopewidth, saved_SlopeW );
				StopListening();
				SetCheckBoxValue( kFiltering_Notch_ChkBox, saved_Notch );
				SetPopupValue( kFiltering_FuncPopup, saved_FunctionType );
				StartListening();
			}
		};
	virtual void	SaveDialog()
		{	saved 		= true;
			saved_Freq		= GetDValue( kFiltering_Frequency );
			saved_Bw		= GetDValue( kFiltering_Bandwidth );
			saved_SlopeW	= GetDValue( kFiltering_Slopewidth );
			saved_Notch		= GetCheckBoxValue( kFiltering_Notch_ChkBox );
			saved_FunctionType 	= GetPopupValue( kFiltering_FuncPopup );
		};
		
	void	SetupDialogScale( STableItem1D*	item )					//	initialization is here
		{	inputItem = item;
		
			if (! item->x_Axis->x->check_regular() )				//	if not regular, resample
				inputItem = new ResampledSeries( item );
		
			drawView = dynamic_cast <CDrawingView*> (FindPaneByID( kFiltering_DrawView ));
			ThrowIfNil_ (drawView);
			drawView->LinkView( this, rPPob() );

			MyMath::double_power2_array	in_y( *(inputItem->Vector()), MyMath::double_power2_array::remove_mean );			
			const double_vector& in_x = *(inputItem->x_Axis->x);
			if (! in_x.check_regular())		MyMath::ThrowError( "bad scale in CFilteringDialog::ResetFunction" );
			double	in_dx = in_x[2]-in_x[1];
			
			in_y.DoFFT();
			double	fc = 1/(2*in_dx);
			size_t	no2 = in_y.length()/2;
			in_px.resize_but_keep( no2+1 );
			in_py.resize_but_keep( no2+1 );
			in_px[1] = 0;
			in_py[1] = in_y[1];
			in_px[no2+1] = fc;
			in_py[no2+1] = in_y[2];
			for (size_t i=2; i<=no2; i++)		//	frequency f varies from 0 to fc = 1/(2*dx)
			{	in_px[i] = (i-1)*fc/no2;
				in_py[i] = sqrt(MyMath::sqr(in_y[2*i-1])+MyMath::sqr(in_y[2*i]));
			}
				
			ResetFunction();
			HideAndShow();
		};
		
protected:

	virtual	SInt16	rPPob()	{	return	rPPob_FilteringDialog;	};
	
};