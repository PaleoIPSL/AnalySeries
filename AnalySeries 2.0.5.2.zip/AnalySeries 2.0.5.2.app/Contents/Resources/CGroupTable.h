
#pragma once

#include <list>
#include <LHierarchyTable.h>
#include <LCommander.h>
#include <LDragAndDrop.h>
#include <LTableMultiSelector.h>
#include <LAction.h>

#include	"myStdCFile.h"
#include	"MyPString.h"
#include	"CGroupTableItem.h"
//#include	"CLinage.h"

class 	LNodeArrayTree;
class 	CLinage;
class 	LPopupButton;
class 	CTextDocument;


const	SInt16	CGroupTable_ColumnNb = 4;

const	SInt16	CGroupTable_ColumnWidth[CGroupTable_ColumnNb] = { 0, 130, 40, 80 };		//	the first one is fixed by window width.



class CGroupTable : public LHierarchyTable, public LCommander, public LDragAndDrop {
public:
	CLinage*		linage;

	enum { class_ID = 'GTab' };

	static CGroupTable *	CreateCGroupTableStream( LStream *inStream );
						CGroupTable( LStream *inStream );
	virtual				~CGroupTable();
	
	CTextDocument*		GetTextDoc();

	virtual void		SelectionChanged();
	virtual void		ResizeFrameBy( SInt16 inWidthDelta,
							SInt16 inHeightDelta, Boolean inRefresh );

	virtual Boolean		ObeyCommand( CommandT inCommand, void *ioParam );
	virtual void		FindCommandStatus( CommandT inCommand,
							Boolean &outEnabled, Boolean &outUsesMark,
							UInt16 &outMark, Str255 outName );
	virtual Boolean		HandleKeyPress( const EventRecord &inKeyEvent );

	virtual Boolean		EditTableItem( STableItemPtr &ioItem );
	
	virtual void		Click( SMouseDownEvent	&inMouseDown );
	void				MakeDragRegion( StRegion &mDragRegion, const STableCell &inHitCell );
	void				DropInFinder( const FSSpec& dropSpec );
	
	void				SelectAll();

	Boolean				GetItemFromCell( const STableCell &inExposedCell, STableItemPtr &outItem ) const;
	Boolean				GetItemFromWOCell( const STableCell &inWideOpenCell, STableItemPtr &outItem ) const;
	
	//void				RefreshMemView();
	
protected:
	UInt16				mFirstIndent;
	UInt16				mLevelIndent;
	TableIndexT			mDropRow;
	SInt32				mDropLevel;

	virtual void		DrawCell( const STableCell &inCell,
							const Rect &inLocalRect );
	virtual void		HiliteCellActively( const STableCell &inCell,
							Boolean inHilite );
	virtual void		HiliteCellInactively( const STableCell &inCell,
							Boolean inHilite );
	virtual void		ClickCell( const STableCell &inCell,
							const SMouseDownEvent &inMouseDown );
			
	virtual void		ClickSelf(
								const SMouseDownEvent	&inMouseDown);
								
	virtual Boolean		ItemIsAcceptable( DragReference inDragRef, ItemReference inItemRef );
	virtual void		EnterDropArea( DragReference inDragRef, Boolean inDragHasLeftSender );
	virtual void		LeaveDropArea( DragReference inDragRef );
	virtual void		InsideDropArea( DragReference inDragRef);
	virtual void		HiliteDropArea( DragReference inDragRef );
	virtual void		ReceiveDragItem( DragReference inDragRef,
							DragAttributes inDragAttrs, ItemReference inItemRef,
							Rect &inItemBounds );
							
	void				GetDividingLineGivenPoint( const Point &inPortPoint,
							TableIndexT &outRow, SInt32 &outDropLevel );
	void				DrawDividingLine();							

	UInt32				CountNodes()	{	return	mCollapsableTree->CountNodes();		};
private:
//	SInt16				mAddTxtCellNb;			//	additional columns: 0 to N
//	SInt16				mAddTxtCellWidth;		//	and their width
	list<long>			tempDirID;				//	temp variable used in ReceiveDragItem()
	Boolean				mUpdateSelection;		//	temp variable for running faster
	static CGroupTable*	dragingFrom;
	Boolean				justReceivedDrag;		//	temp variable for running faster
	
public:
	virtual void		DoDragReceive( DragReference inDragRef )
							{	tempDirID.clear();	LDropArea::DoDragReceive(inDragRef);	};
	
private:
	
	void				InitGroupTable( SInt16 inCellHeight, SInt16 inFirstIndent,
							SInt16 inLevelIndent );
							
	void				CalcIconAndTextRect( const STableCell &inCell, const Rect &inLocalRect,
							const STableItemPtr &inItem, Rect &outIconRect, Rect &outTextRect,
							SInt32 &outTextv );
							
	void				ClickDragAndDrop( const SMouseDownEvent &inMouseDown, const STableCell &inHitCell );
	
	void				RemoveSelection();

	void				MoveSelectionAt( UInt32 afterItem, Boolean child, STableItem::copyOption copy );
	void				CopyAllDescendentsAt( CGroupTable* hTable, UInt32& ioAfterItem, UInt32& ioWOIndex, UInt32 maxDepth, Boolean inNeedOffset, STableItem::copyOption duplicate );

public:
	int					InsertItemAt( STableItemPtr& inItem, UInt32& ioAfterItem, Boolean inChild, Boolean collapsed = false );

private:
	STableItemPtr		GetItemPtr( UInt32 inIndex );
	UInt32				GetVisibleIndex( UInt32	inWideOpenIndex ) const;
	
	void				OpenFile();
	void				SaveSelection();
	void				DoCommandDraw();
	void				DoCommandMoreInso();
	void				DoCommandNoise();
	void				DoCommandCorrelations();
	void				DoCommandSampling();
	void				DoCommandFitting();
	void				DoCommandFiltering();
	void				DoCommandSmoothing();
	void				DoCommandPrincCompon();
	void				DoCommandSpectralAnalysis( CommandT inCommand );
	void				DoCommandStats();
	void				DoCommandSSA();
	void				DoCommandModel( CommandT inCommand );
	
	void				DoCommandLinage( int typ /*= linage_type_lin_interp*/ );
	void				DoCommandAgeScale();
	void				DoCommandCombine();
	
	//Boolean				OnSameRegular1DScale( MyMath::common_regular_scale*& x, Boolean on_intersection = true );
	Boolean				OnSameRegular1DScale( MyMath::common_regular_scale*& x, double_matrix1*& v );
	Boolean				OnSameRegular1DScale( STableItem1D* item, MyMath::common_regular_scale*& x, double_matrix1*& v );
	
//	void				DoCommandRunTest();			//	just for easy test plug-in
	
	
	void				DoCommandInso( CommandT inCommand );
	STableCell			WhereIsNewInsert( UInt32& outWOindex, Boolean& outAsChild );
	
	
//	void		  		MakePopup( UInt32 atItem );
	void				ResizeColumns();
	size_t				GroupDoubleSize( STableCell theCell );
	
//	typedef void (CGroupTable::*groupRoutine)(STableItem*);
//	void				ApplyToGroup( STableCell theCell, groupRoutine func  );
public:
	
	class	GroupIterator
	{	public:		virtual void	DoIt( STableItem* )	= 0;	};
	void				ApplyToGroup( STableCell theCell, GroupIterator& iter  );
	
	class	GroupSummer: public GroupIterator {
	public:	
		size_t	sum;
		GroupSummer()	{	sum = 0;	}
		virtual void	DoIt( STableItem* it )		{	sum += it->DoubleSize();	};
	};
	class	GroupCounter: public GroupIterator {
	public:	
		size_t	sum;
		GroupCounter()	{	sum = 0;	};
		virtual void	DoIt( STableItem* )		{	sum ++;	};
	};
	class	GroupSaver: public GroupIterator {
	public:	
		const CGroupTable&				gpTable;
		size_t							n0;
		size_t							n1;
		ulong_vector1&					line;
		ulong_vector1&					level;
		val1Darray<STableItemPtr,1>&	saved_items;
		GroupSaver( CGroupTable& g, size_t n, size_t m, ulong_vector1& li, ulong_vector1& lev, val1Darray<STableItemPtr,1>& it )
			:gpTable(g),n0(n),n1(m),line(li),level(lev),saved_items(it)	{};
		virtual void	DoIt( STableItem* )	
			{	line(n0)  = n1;
				level(n0) = gpTable.GetNestingLevel( n1 );
				STableCell	theCell( n1, 1 );
				gpTable.GetItemFromWOCell( theCell, saved_items(n0) );
				saved_items(n0)->InitTable(1);
				n0++;	n1++;
			};
	};
	
//	Boolean				selectionHasChanged;		//	used by the CRemoveSelectionAction class to disable Undo/Redo
								
public:
/*	Boolean			Exactly1Series1DSelected()
		{	return	(GetCurrentSelection( 0, 1, 0, 0, true, false ) == 1);	};		//	1
	Boolean			AtMost1Series1DSelected()
		{	return	(GetCurrentSelection( 0, 1, 0, 0, true, false ) >= 0);	};		//	0 or 1
	Boolean			AtLeast1Series1DSelected()
		{	return	(GetCurrentSelection( 0, -1, 0, 0, true, false ) > 0);	};		//	1 or more...
	Boolean			AtMost2Series1DSelected()
		{	return	(GetCurrentSelection( 0, 2, 0, 0, true, false ) > 0);	};		//	1 or 2
	Boolean			AtLeast2Series1DSelected()
		{	return	(GetCurrentSelection( 0, -2, 0, 0, true, false ) > 0);	};		//	2 or more...
*/
	Boolean				Has1DSelection( int min, int max )			//	min >= 0
		{	if (min == 0)
			{	if (!GetFirstSelectedItem())	return true;
				else return ( GetCurrentSelection( 0, max, 0, 0, true, false ) > 0 );
			}
			else
			{	int	n1 = GetCurrentSelection( 0, max, 0, 0, true, false );
				int	n2 = GetCurrentSelection( 0, -min, 0, 0, true, false );
				return	(n1 > 0) && (n2 > 0);
			}
		};
	Boolean				HasAtLeast1DSelection( int min )								//	min >= 1
		{	return	(GetCurrentSelection( 0, -min, 0, 0, true, false ) > 0);	};
		
	STableItemPtr		GetFirstSelectedItem();
	int					GetCurrentSelection( int max0, int max1, int max2, int max3, Boolean homogeneous, Boolean fill_last = false );
	int					GetSaveSelection( Boolean fill_last = false )
							{	return	GetCurrentSelection( 1000, 1000, 1, 1, true, fill_last );	};
	int					GetDrawSelection( Boolean fill_last = false )
							{	return	GetCurrentSelection( 0, 1000, 1, 1, true, fill_last );	};
//	STableItemPtr 		GetItemToSave();

	void				SaveItemsToBinary( binaryStream& iStream );
	void				ReadItemsFromBinary( binaryStream& iStream );
	
	void				InsertNewItem( STableItemPtr inNewItem, Boolean unselect_old = true, Boolean select_new = true );
	void				SetSelectionCheckFlags();
	void				CopySelectionAt( CGroupTable* hTable, UInt32 afterItem, Boolean child, STableItem::copyOption duplicate, Boolean copy_all = false );
	void				CopySelection( CGroupTable* hTable, STableItem::copyOption duplicate );
	
	STableItemPtr		ReadFromStream( istream& from, char* cname, Boolean dontAsk );
	STableItemPtr		ReadItem( Boolean isDir, const FSSpec& fileSpec, list<long>& dirList );
	STableItemPtr		OpenFileAndReadIt( const FSSpec& fileSpec );
	STableItemPtr		ReadFromFile( myStdCFileStream& f, Boolean dontAsk = false );
	STableItemPtr		ChooseFileAndReadIt();
	
	void				KillLinage( CLinage* lin );
	
	virtual UInt32		GetNestingLevel( UInt32 inWideOpenIndex ) const
		{	return	mCollapsableTree->GetNestingLevel( inWideOpenIndex );	};
	virtual UInt32		GetPreviousSibling( UInt32 inWideOpenIndex, UInt32 inNestingLevel )
		{	if ( GetNestingLevel( inWideOpenIndex ) < inNestingLevel )	return 0;
			while ( GetNestingLevel( inWideOpenIndex ) > inNestingLevel )	inWideOpenIndex--;
			return	inWideOpenIndex;
		};
};

class	GroupSelector {
private:
	int cur0, cur1, cur2, cur3;
	int max0, max1, max2, max3;
	Boolean homogeneous;
	DataIDT	refType;
public:
	GroupSelector( int m0, int m1, int m2, int m3, Boolean h )
		{	cur0 = cur1 = cur2 = cur3 = 0;
			max0 = m0;
			max1 = m1;
			max2 = m2;
			max3 = m3;
			homogeneous = h;
			refType = 0;
		}
	Boolean AcceptableItem( STableItemPtr item )
		{	if (homogeneous)
			{	if (refType == 0)	refType = item->ItsType();
				if (item->ItsType() != refType)
					return false;
			}
			switch (item->ItsType())	{
				case kNumberItemType:	cur0++;		break;
				case kSeriesItemType:	cur1++;		break;
				case kMapItemType:		cur2++;		break;
				case kMovieItemType:	cur3++;		break;
			}
			return	checkMax();
		};
	int		length()	{	return cur0 + cur1 + cur2 + cur3;	};
	Boolean	checkMax()	{	return ( (max0 < 0 || cur0 <= max0) && (max1 < 0 || cur1 <= max1)
							&& (max2 < 0 || cur2 <= max2) && (max3 < 0 || cur3 <= max3) );		};
	Boolean	checkMin()	{	return ( (max0 >= 0 || cur0 >= -max0) && (max1 >= 0 || cur1 >= -max1)
							&& (max2 >= 0 || cur2 >= -max2) && (max3 >= 0 || cur3 >= -max3) );	};
};

class	MyTableMultiSelector : public LTableMultiSelector {
private:
	EventModifiers	cKey;	//	modifier for contiguous selection
	EventModifiers	dKey;	//	modifier for discontiguous selection
public:
	MyTableMultiSelector( LTableView *inTableView, EventModifiers c_Key, EventModifiers d_Key )
		: LTableMultiSelector(inTableView), cKey(c_Key), dKey(d_Key)	{};
		
	void	SetModifierKeys( EventModifiers c_Key, EventModifiers d_Key )
		{	cKey = c_Key;	dKey = d_Key;	};

	virtual void	ClickSelect( const STableCell &inCell, const SMouseDownEvent &inMouseDown );
};




class	CTableAction : public LAction {
protected:
	CGroupTable*	gpTable;
public:
	CTableAction( CGroupTable*	g ): gpTable(g)	{};
};


class	CRemoveSelectionAction : public CTableAction {
private:
	ulong_vector1				line;			//	the "Wide Open" position index
	ulong_vector1				level;			//	the nesting level
	val1Darray<STableItemPtr,1>	saved_items;	//	the item
	Boolean	doneAlready;		//	do it just once !!
	
	void	RecordSelectedItems();
public:
	CRemoveSelectionAction( CGroupTable* g ): CTableAction( g ) {	doneAlready = false;	};
protected:
	virtual void	RedoSelf();
	virtual void	UndoSelf();
	
//	virtual Boolean	CanUndo() const	{	return	(!gpTable->selectionHasChanged) && LAction::CanUndo();		};
	virtual Boolean	CanRedo() const	{	return	(!doneAlready) && LAction::CanRedo();		};
};
