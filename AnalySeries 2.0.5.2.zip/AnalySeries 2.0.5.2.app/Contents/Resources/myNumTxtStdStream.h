



#pragma once


//#include	<iostream.h>
//#include	"strstream.h"
#include <istream>
#include <ostream>
#include <sstream>
#include <list>
#include	"myMath.h"


#define	NAN_VALUE	DBL_MAX


class CVocabularyList
{
protected:
	int		length;
	char*	(*VocList);
	
	CVocabularyList()
	{	VocList = NULL;		length = 0;	}
	
	void	init()
	{	if (VocList)
		{	length = 0;
			while ( VocList[length][0] )	length++;
		}
	};
	
public:
	Boolean	Contains( char* str )			//	ok si str est identique a un mot
	{	Boolean notFound = true;
		if (VocList)
		{	int i = 0;
			while ( VocList[i][0] && notFound )
			{	notFound = ( std::strcmp( str, VocList[i] ) != 0 );
				i++;
		}	}
		return !notFound;
	};
	Boolean	ContainsSub( char* str )		//	ok si str contient une sous-chaine identique a un mot
	{	Boolean notFound = true;
		if (VocList && *str)
		{	int i = 0;
			while ( VocList[i][0] && notFound )
			{	notFound = !std::strstr( str, VocList[i] );
				i++;
		}	}
		return !notFound;
	};
	
};


#define		DECLARE_NEW_VOCABULARY( newvoc )	\
class newvoc: public CVocabularyList {			\
public:											\
	static char*	VTable[];					\
	newvoc()	{ VocList = VTable; init();	}	\
};



//	Dans le 'newfile.h':		DECLARE_NEW_VOCABULARY( newvoc )
//	Dans le 'newfile.cp':		char*	newvoc::VTable[] = { "premier", "deuxieme", "" };


DECLARE_NEW_VOCABULARY( Not_A_Number )




#define		COMMENT_LENGTH			5000
#define		COLUMN_NAME_LENGTH		64
#define		FILE_NAME_LENGTH		64
#define		MAX_CELL_STR_LENGTH		1024


#define		PERFECT_ONLY		1				//	les lignes prises en compte doivent respecter EXACTEMENT le prototype
#define		NUM_TEXT_ONLY		2				//	....	avec d'eventuelles conversions numeric->text
#define		SKIP_TEXT			3				//	....	avec d'eventuelles conversions text->numeric (blancs/NAN/...)

typedef char	columnTitle[COLUMN_NAME_LENGTH];



class	lineInfo
{	
public:
	enum	CellType	{ string, number, emptycell, nanstring };

private:
	CellType*	isNum;				//	cell type
	
	void	init_lineInfo( int nb )
		{	nbcol = nb;		nbcolNum = 0;	nbcolRealNum = 0;
			nbLines = 0;	next = NULL;	firstOne = 0;
			isNum = new CellType[nbcol];
		};
	Boolean	is_number( int i )
		{	return (isNum[i] == number);	};
	Boolean	is_empty( int i )
		{	return (isNum[i] == emptycell);	};
	Boolean	is_num_string( int i )
		{	return ((isNum[i] == number) || (isNum[i] == emptycell) || (isNum[i] == nanstring));		};
		
public:
	lineInfo*	next;
	int			nbcol;				//	nombre de colonnes (0 = ligne vide)
	int			nbcolNum;			//	nombre de colonnes numeriques ou NaN
	int			nbcolRealNum;		//	nombre de colonnes numeriques vraies
	int			nbLines;
	int			firstOne;
	
	lineInfo( int nb, CellType* num, int lineNb )
	{	init_lineInfo( nb );	firstOne = lineNb;
		for (int i=0; i<nbcol; i++)
		{	isNum[i] = num[i];
			if (is_num_string(i))	nbcolNum++;
			if (is_number(i))		nbcolRealNum++;
		};
	};
	~lineInfo()
		{	delete [] isNum;	delete next;	};
	
	Boolean	isNumber( int i )
		{	return ( (i>=0 && i<nbcol) ? (is_number(i)) : false );		};
	Boolean	isNumString( int i )
		{	return ( (i>=0 && i<nbcol) ? (is_num_string(i)) : false );	};
	
	Boolean	sameAs( int nb, CellType* num )
		{	if (nbcol != nb)				return false;
			for (int i=0; i<nbcol; i++)
				if (isNum[i] != num[i])		return false;
			return true;
		};
	Boolean	canConvertToNumber( lineInfo* li, Boolean sameNbCol=false )		//	this = prototype
		{	if (!li)	return false;
			if (!li->is_number(0))	return false;
			if (li->nbcol<2)		return false;
			if (sameNbCol && nbcol!=li->nbcol)	return false;
		/*	for (int i=0; i<nbcol && i<li->nbcol; i++)
				if (is_number(i) && !li->is_num_string(i))
					return false;
		*/
			return true;
		};
	
public:
	Boolean	isNotEmptyLine()
		{	return	(nbcol>0);						};
	Boolean	isValidCommentLine()
		{	return	(nbcol==1 && nbcolRealNum==0);	};
	Boolean	isValidTitleLine()
		{	return	(nbcol>=2 && nbcolRealNum==0);	};
	Boolean	isValid1DNumLine()
		{	return	(nbcol>=2 && nbcolNum>=2);		};
	Boolean	isPrototype1DNumLine()
		{	return	(nbcol>=2 && nbcolRealNum>=2);	};
	Boolean	isValid0DNumLine()
		{	return	(nbcol>=2 && nbcolRealNum==1 && nbcolNum==1);			};
	Boolean	isValidXScaleLine()
		{	return	(nbcol>=3 && nbcolRealNum==nbcol-1 && is_empty(0));		};
	Boolean	isValidZValueLine()
		{	return	(nbcol>=1 && nbcolRealNum==1 && is_number(0));			};
};

typedef		lineInfo*	lineInfoPtr;




class	colonInfo
{
private:
	double	previous;
	size_t	nb;						//	number of true numeric values

public:
	char		name[COLUMN_NAME_LENGTH];
	Boolean*	InVocab;					//	name is in Vocabulary[i]
	Boolean*	SubInVocab;					//	substring of name is in Vocabulary[i]
	
	int		nbNum()			{	return nb;	};						//	number of true numeric values
	Boolean	croissant;					//	consecutive values are >=
	Boolean	decroissant;				//	consecutive values are <=
	Boolean	distinct;					//	consecutive values are !=
	Boolean	noNAN;						//	there is no NAN values
	
	colonInfo()		{	croissant = decroissant = distinct = noNAN = true;
						nb = 0;	InVocab = SubInVocab = NULL;	};
	~colonInfo()	{	delete [] InVocab;
						delete [] SubInVocab;	};

	void	SetSize( size_t n )		{	nb = n;	};
	void	CheckNumber( double v )
		{	if (nb > 0)
			{	if (v < previous && croissant)			croissant = false;
				else if (v > previous && decroissant)	decroissant = false;
				else if (v == previous && distinct)		distinct = false;
			}
			previous = v;
			nb++;
		};
						
	void	SetVocabDim( int n )
		{	InVocab = new Boolean[n];	SubInVocab = new Boolean[n];	};
		
	void	CheckVocab( CVocabularyList* vl, int n )
		{	for (size_t i=0; i<n; i++)
			{	InVocab[i] = vl[i].Contains( name );
				SubInVocab[i] = vl[i].ContainsSub( name );
			};
		};
};

class	readModule;

class	iStreamReader
{
			//	line positioning
private:
	std::streampos line_start;
	std::streampos line_end;
public:
	void setLineStart()		{	line_start = from.tellg();	};
	void setLineEnd()		{	line_end = from.tellg();	};
	void gotoLineStart()	{	from.seekg(line_start);		};
	void gotoLineEnd()		{	from.seekg(line_end);		};
	
			//	file size in terms of '\n' and '\t'
private:
	unsigned long	maxnbline;		//	= max nb of lines	(= nbre de '\n' + 1)
	unsigned long	maxnbcols;		//	= max nb of columns (= max of nb of '\t' + 1) SUR LA LIGNE COURANTE
	unsigned long	firstfulline;	//	= first line with exactly 'col' columns (=start of table?)
	unsigned long	nonemptynbline;	//	= nb of non-empty lines (lines different from '\n', '')
	
	void	reset()		{	firstfulline = maxnbline = nonemptynbline = maxnbcols = 0;	};
	void	maxLinesCols();		//	=> maxnbline, maxnbcols, firstfulline, nonemptynbline
	
public:
	unsigned long	maxLines()	{	return	maxnbline;	};
	unsigned long	maxCols()	{	return	maxnbcols;	};

			//	others
protected:
	unsigned long	curLineNb;		//	position courante sur le fichier (numero de la ligne)
	std::istream&		from;
	Boolean			hasNumComa;		//	some numbers have a numerical coma => problem....
	Boolean			endFile;

public:
	iStreamReader( std::istream& istr ):line_start(0),line_end(0),from(istr)
			{	curLineNb = 0; 	hasNumComa = false;	endFile = false;	maxLinesCols();		};
	
	Boolean		hasNumericComa()			{	return hasNumComa;	};
	Boolean		is_at_end()					{	return endFile;		};

	Boolean	isNotCR( const char& c )		{	return	(c!='\n' && c!='\r');				};
	Boolean	isNotCR_TAB( const char& c )	{	return	(c!='\n' && c!='\r' && c!='\t');	};
	
	void	clear()							{	from.clear();	};
	
	char	extractCharButNotCR()
		{	char c = from.peek();	if (isNotCR(c))	from.get(c);		return c;	};
	char	extractCharButNotCR_TAB()
		{	char c = from.peek();	if (isNotCR_TAB(c))	from.get(c);	return c;	};

	Boolean	isNumber();
	double	getNumber();
	char*	getString( char* str, int maxLength, Boolean extractTab = true );
	char*	getLine( char* str, int maxLength );
	
	int		countlines();		//	nombre de lignes (= nbre de '\n' + 1)
	int		countcols1();		//	nombre de colonnes sur la ligne (= nbre de '\t' + 1)
	void	gotoStart();
	Boolean	gotoLine( size_t i );
	Boolean	gotoNextLine();
	Boolean	gotoNextValidLine( const readModule& rm );
	void	gotoNextCell()
		{	char txt[MAX_CELL_STR_LENGTH];	getString( txt, MAX_CELL_STR_LENGTH );	};
	
	int		LineInfo( lineInfo::CellType* num );		//	returns information to construct lineInfo record
	
	unsigned long	CurrentLineNb()		{	return curLineNb;	};
		
};


class	lineInfoList
{
private:
	lineInfo*		firstLine;
	lineInfoPtr*	infoTable;
	unsigned long	tableDim;
	
	int		lineInfoNb( int nb, lineInfo::CellType* num, int lineNb )
		{	int	infoNb = 0;		int	curNb = 1;
			lineInfo*	curLine = firstLine;
			while (curLine && infoNb==0)
			{	if ( curLine->sameAs( nb, num ) )	infoNb = curNb;
				curLine = curLine->next;
				curNb++;
			}
			if (infoNb==0)		infoNb = AppendLineInfo( nb, num, lineNb );
			return infoNb;
		};
	int		AppendLineInfo( int nb, lineInfo::CellType* num, int lineNb )
		{	int	curNb = 1;
			if (firstLine)
			{	lineInfo*	lastLine = firstLine;
				curNb++;
				while (lastLine->next)
				{	lastLine = lastLine->next;	curNb++;	}
				lastLine->next = new lineInfo( nb, num, lineNb );
			}
			else	firstLine = new lineInfo( nb, num, lineNb );
			return curNb;
		};
	
	lineInfo*	NewLineInfo( int nb, lineInfo::CellType* isNum )		//	used only by MakeLineInfo()
		{	int index = lineInfoNb( nb, isNum, line_count+1 );
			infoTable[line_count] = getLineInfo( index );
			(infoTable[line_count]->nbLines)++;
			return infoTable[line_count];
		};
		
public:
	unsigned long	line_count;
	
	lineInfoList()	{	firstLine = NULL;	infoTable = NULL;	tableDim = 0;	line_count = 0;	};
	~lineInfoList()	{	delete firstLine;	delete [] infoTable;				};
	
	void	SetDim( unsigned long n )
		{	tableDim = n;
			infoTable = new lineInfoPtr[tableDim];
			for (unsigned long i=0; i<tableDim; i++)	infoTable[i] = NULL;
		};
		
	lineInfo*	getInfo( unsigned long line )
		{	if (line < tableDim)	return	infoTable[line];
			else	return NULL;
		};
	
	lineInfo*	getLineInfo( int i )
		{	lineInfo* li = firstLine;	int curNb = 1;
			while (li && curNb!=i)		{	li = li->next;	curNb++;	}
			return li;
		};
		
	lineInfo*	MakeLineInfo( iStreamReader* reader )
	{	lineInfo::CellType*	numT = new lineInfo::CellType[reader->maxCols()];
		int nb = reader->LineInfo( numT );
		lineInfo* curLineInfo = NewLineInfo( nb, numT );	line_count++;
		delete [] numT;
		if (reader->is_at_end())	reader->clear();
		return	curLineInfo;
	};
};



class	columnRec
{
private:
	CVocabularyList*	vocab;
	int					vocablength;
	
	colonInfo*	columns;
	
public:
	columnRec( CVocabularyList* vl = NULL, int vl_length = 0 )
		{	vocab = vl;		vocablength = vl_length;	columns = NULL;		};
	~columnRec()
		{	if (columns)	delete [] columns;	};
		
	void	SetDim( unsigned long n )
		{	columns = new colonInfo[n];
			for (size_t i=0; i<n; i++)
			{	std::ostringstream s;	s << "column " << i+1 << '\0';
				std::strcpy( columns[i].name, s.str().c_str() );
			}
			if (vocablength > 0)
				for (size_t i=0; i<n; i++)
					columns[i].SetVocabDim( vocablength );
		};
	
	void	CheckVocab( unsigned long n )
		{	for (unsigned long i=0; i<n; i++)
				if (vocab)	columns[i].CheckVocab( vocab, vocablength );
		};
		
	colonInfo&	Column( int i )				{	return	columns[i-1];		};
	colonInfo*	getColumn( int i )			{	return	&(columns[i-1]);	};
	

};


class	iStdStream;
typedef	void	(*valueFuncType)(int,int,double);
typedef	void 	(*svalueFuncType)(int,int,char*);
typedef	Boolean	(*boolFunc)(int);


class	readModule
{	
public:
	iStdStream&		its_stream;
protected:
	lineInfo*		firstValidLine;
	int				phase;
    
private:
	readModule*		next;

	double_matrix	value_matrix;
	string_matrix	sval_matrix;
	valueFuncType	valueFunc;
	svalueFuncType	svalueFunc;
	double**		values;				//	[nbnumcol][ max[i]-min[i]+1 ]			Attention, chaque colonne a ses propres dimensions: de min[i] a max[i] !!!
	char***			svalues;			//	[nbcol-nbnumcol][ max[i]-min[i]+1 ]		Attention, chaque colonne a ses propres dimensions: de min[i] a max[i] !!!

	
	
protected:
	void		gotoLineStart();
	void		gotoLineEnd();
	colonInfo&	Column( int i );
	void		gotoNextCell();
	Boolean		gotoLine( int i );
	double		getNumber();
	char*		getString( char* str, int maxLength, Boolean extractTab = true );
	void		newValidLine();
	void		invalidate()			{	firstValidLine = NULL;	newValidLine();	}
	
	virtual	Boolean	gotoFirstValidLine()
		{	return	( firstValidLine ? gotoLine( firstValidLine->firstOne ) : false );	};
	virtual	Boolean	gotoNextValidLine();
	
//	lineInfo*		getCurrentLineInfo()	const;
	unsigned long	CurrentLineNb()		const;
	
	void	SetMatrixDim()
		{	value_matrix = double_matrix( NumColDim(), numericLineNumber() );	};
	void	SetMatrixStrDim()
		{	sval_matrix	= string_matrix( StrColDim(), numericLineNumber() );	};
		
	int		NumColDim()
		{	int n = 0;	for (int i=1; i<=columnNumber(); i++)	if (IsNumColToRead(i))	n++;
			return n;
		};
	int		StrColDim()
		{	int n = 0;	for (int i=1; i<=columnNumber(); i++)	if (IsStrColToRead(i))	n++;
			return n;
		};
		
	virtual Boolean	IsNumColToRead( int )		{	return true;	};
	virtual Boolean	IsStrColToRead( int )		{	return true;	};
		
public:
	readModule( iStdStream& istr )
		:its_stream(istr), firstValidLine(NULL), phase(0), next(NULL)
			{	values = NULL;	svalues = NULL;	valueFunc = NULL;	svalueFunc = NULL;	};
    
	virtual ~readModule()	{};
		
	virtual	void	checkLine( lineInfo* line ) = 0;
	virtual	void	finalCheck() = 0;
	virtual	int		numericColumnNumber()
		{	return ( firstValidLine ? firstValidLine->nbcolNum : 0 );		};
	virtual	int		columnNumber()
		{	return ( firstValidLine ? firstValidLine->nbcol : 0 );			};
	
	void		setValidLine( lineInfo* line )	{	firstValidLine = line;	};
	Boolean		stillValid()					{	return (firstValidLine != NULL);	};
	Boolean		isInvalid()						{	return (firstValidLine == NULL);	};
	int			numericLineNumber();
	Boolean		isNumCol( int i )
		{	return (firstValidLine ? firstValidLine->isNumString(i-1) : false);		};
	Boolean		isNonEmptyNumCol( int i )
		{	return (isNumCol(i) ? Column(i).nbNum() > 0 : false );	};
		
	virtual	Boolean	acceptableLine( lineInfo* line )	const	{	return	line != NULL;	};
	
protected:
	void	CheckIncreasingColumns( lineInfo* currentInfo );
	void	AppendToList( lineInfo* currentInfo, std::list<double>& l )
		{	gotoLineStart();
			if (currentInfo->isNumber(0))	l.push_back( getNumber() );
			gotoLineEnd();
		};
	
	Boolean	BuildScale( double_vector& sc, std::list<double>& l )
		{	if (sc.length() == 0)
			{	int j = 1;
				sc = double_vector( l.size() );
				for (std::list<double>::iterator i = l.begin(); i != l.end(); i++)
					sc[j++] = *i;
				l.erase( l.begin(), l.end() );
				return	(sc.check_strict_increase() || sc.check_strict_decrease());
			}
			else return true;
		};
		
	double		InternalV( int i, int j )	{	if (value_matrix.length() > 0)	return value_matrix(i,j);	else return 0;	};
	std::string	InternalS( int i, int j )	{	if (sval_matrix.length() > 0)	return sval_matrix(i,j);	else return "";	};
	
	const double_matrix&	internalValues()	{	return	value_matrix;	};
	const string_matrix&	internalStrings()	{	return	sval_matrix;	};
		
	void	SetValueRead( double**	v )					{	values			= v;		};
	void	SetValueRead( valueFuncType vF )			{	valueFunc		= vF;		};
	void	SetSValueRead( char*** sv )					{	svalues			= sv;		};
	void	SetSValueRead(svalueFuncType svF )			{	svalueFunc		= svF;		};

	virtual void	SetValue( int i, int j, double v )
		{	if (values)							values[i][j] = v;
			else if (valueFunc)					valueFunc(i,j,v);
			else if (value_matrix.length() > 0)	value_matrix(i,j) = v;
		};
	virtual void	SetSValue( int i, int j, char* s )
		{	if (svalues)						std::strcpy( svalues[i][j], s );
			else if (svalueFunc)				svalueFunc(i,j,s);
			else if (sval_matrix.length() > 0)	sval_matrix(i,j) = s;
		};
	
public:
	virtual	int				read( Boolean* isNum = NULL );
	
	virtual	double			getValue( int i=0 )			{	return InternalV(1,i);	};
	virtual	std::string		getSValue( int i=0 )		{	return InternalS(1,i);	};
	virtual	double_vector*	getVector( int i=1 )
				{	return new double_vector( internalValues(), double_vector::fixed_x, i-1 );	};
	virtual	double_matrix*	getMatrix( int =0 )
				{	return new double_matrix( internalValues() );	};
	virtual	double_3tensor*	getTensor( int =0 )	{	return NULL;	};
};


class	readModule0D : public readModule
{
private:
	size_t	count;
protected:
	virtual Boolean	IsNumColToRead( int i )		{	return	(i==2);		};
	virtual Boolean	IsStrColToRead( int i )		{	return	(i==1);		};

public:
	readModule0D( iStdStream& istr ):readModule( istr )	{	count = 0;	};
	virtual	void	checkLine( lineInfo* lineInfo )	
		{	if (lineInfo->isNumber(1))	count++;	};
	virtual	void	finalCheck()
		{	if (count>0)	Column(2).SetSize( count );		};
	virtual	int		read( Boolean* isNum = NULL );
};



class	readModule1D : public readModule
{
private:
	boolFunc	colToReadFunc;
	boolFunc	scolToReadFunc;
	Boolean*	colToRead;
	Boolean*	scolToRead;

protected:
	
	virtual Boolean	IsNumColToRead( int i )
		{	return	( colToRead  ?	colToRead[i-1]  : ( colToReadFunc  ? colToReadFunc(i):	true )	);	};
	virtual Boolean	IsStrColToRead( int i )
		{	return	( scolToRead ?	scolToRead[i-1] : ( scolToReadFunc ? scolToReadFunc(i):	true )	);	};

public:
	readModule1D( iStdStream& istr ):readModule( istr )
		{	phase = 1;
			colToReadFunc = scolToReadFunc = NULL;
			colToRead = scolToRead = NULL;
		};
	virtual	void	checkLine( lineInfo* line )
		{	if (isInvalid())	return;
			CheckIncreasingColumns( line );						//	check increasing columns				
			if (phase == 1 && line->isPrototype1DNumLine())		//	search for a really valid 1D line
				phase = 0;
		}
	virtual	void	finalCheck()	
		{	if (stillValid() && phase > 0)	invalidate();	}

	void	SetColToRead( Boolean* colR )		{	colToRead		= colR;		};
	void	SetColToRead( boolFunc colF )		{	colToReadFunc	= colF;		};
	void	SetSColToRead( Boolean* scolR )		{	scolToRead		= scolR;	};
	void	SetSColToRead( boolFunc scolF )		{	scolToReadFunc	= scolF;	};
	
	virtual	int		read( Boolean* isNum = NULL );
};

class	readModule2D : public readModule
{
protected:
	double_vector	Xscale;
	double_vector	Yscale;
	std::list<double>	Ylist;
	
	void	AppendToYScale( lineInfo* currentInfo )		{	AppendToList( currentInfo, Ylist );	};
	Boolean	BuildYScale()								{	return BuildScale( Yscale, Ylist );	};

	Boolean	CheckIncreasingXScale( lineInfo* currentInfo )
		{	gotoLineStart();
			double_vector Xsc(currentInfo->nbcolRealNum);
			int j = 1;
			for (int i=0; i<currentInfo->nbcol; i++)
				if (currentInfo->isNumber(i) && j<=currentInfo->nbcolRealNum)
					Xsc[j++] = getNumber();
			gotoLineEnd();
			
			if (Xsc.check_strict_increase() || Xsc.check_strict_decrease())
			{	if (Xscale.length() == 0)						//	set new x-scale (2D or first 3D)
				{	Xscale = Xsc;	return true;	}
				else											//	check if same x-scale (3D)
					return Xscale.check_same_as( Xsc );
			}
			else return false;
		};
			
	virtual Boolean	IsNumColToRead( int i )		{	return	(i>=2);		};
	virtual Boolean	IsStrColToRead( int )		{	return	false;		};

public:
	readModule2D( iStdStream& istr ):readModule( istr )	{	phase = 1;	};
	virtual	void	checkLine( lineInfo* line )
		{	if (isInvalid())	return;
			if (phase == 0)	AppendToYScale( line );
			if (phase == 1)
				if (CheckIncreasingXScale( line ))				//	check increasing line
					phase = 0;
		};
	virtual	void	finalCheck()	
		{	if (isInvalid())	return;
			if (phase > 0)				invalidate();
			else if (!BuildYScale())	invalidate();
			if (stillValid())
				firstValidLine = firstValidLine->next;
		}
	virtual	int		numericColumnNumber()
		{	return ( (stillValid() && Xscale.length() > 0) ? Xscale.length() + 1 : 0 );		};
	virtual	int		columnNumber()
		{	return numericColumnNumber();	};
		
	virtual	double_vector*	getVector( int i=0 )
		{	return (i==1 ? new double_vector( Xscale ) : (i==2 ? new double_vector( Yscale ) : NULL));	};
						
	virtual	int		read( Boolean* isNum = NULL );
};

class	readModule3D : public readModule2D
{
private:
	double_vector	Zscale;
	std::list<double>	Zlist;
	size_t			lastCurLine3D;
	size_t			line_count;
	double_3tensor	value_tensor;

	void	SetTensorDim()
		{	value_tensor = double_3tensor( Xscale.length(), Yscale.length(), Zscale.length() );	};
	
	void	AppendToZScale( lineInfo* currentInfo )		{	AppendToList( currentInfo, Zlist );	};
	Boolean	BuildZScale()								{	return BuildScale( Zscale, Zlist );	};
	Boolean	CheckYScale( lineInfo* currentInfo, int j )
		{	Boolean is_ok = true;
			gotoLineStart();
			if (currentInfo->isNumber(0) && Yscale.length() > 0)
			{	double	v = getNumber();
				is_ok = (v == Yscale[j]);
			}
			gotoLineEnd();
			return	is_ok;
		};
public:
	readModule3D( iStdStream& istr ):readModule2D( istr )	{	phase = 2;	line_count = 0;	};
	virtual	void	checkLine( lineInfo* line )
		{	if (isInvalid())	return;
			line_count++;
			CheckIncreasingColumns( line );							//	check increasing columns				
			if (phase == 0)
			{	int	curLine = line_count;
				if (line->isValidZValueLine())
				{	if (Yscale.length() > 0)
					{	if ( Yscale.length() != (curLine - lastCurLine3D - 2) )
							invalidate();
					}
					else if (!BuildYScale())
						invalidate();
					lastCurLine3D = curLine;
					phase = 2;
				}
				else if (Zlist.size() == 1)
					AppendToYScale( line );
				else if (Zlist.size() > 1)
					if (!CheckYScale( line, curLine - lastCurLine3D - 1 ))
						invalidate();
			}
				
			if (phase == 1)
				if (line->isValidXScaleLine())
					if (CheckIncreasingXScale( line ))				//	check increasing line
						phase = 0;
			
			if (phase == 2)											//	first line: just one number
				{	AppendToZScale( line );		phase = 1;	};
		};
	virtual	void	finalCheck()	
		{	if (isInvalid())	return;
			if (phase > 0)				invalidate();
			else if (!BuildZScale())	invalidate();
			if (stillValid())
				firstValidLine = firstValidLine->next->next;
		}
		
	virtual	Boolean	acceptableLine( lineInfo* line )	const
		{	if (line == NULL)				return false;
			if (line == firstValidLine)		return true;
			if (firstValidLine->canConvertToNumber( line, true ))	return true;
			return false;
		};
		
	virtual	double_vector*	getVector( int i=0 )
		{	return	(i==1 ? new double_vector( Xscale ) :
					(i==2 ? new double_vector( Yscale ) :
					(i==3 ? new double_vector( Zscale ) : NULL)));	};

	virtual	double_3tensor*	getTensor( int  =0 )
						{	return new double_3tensor( value_tensor );	};
						
	virtual void	SetValue( int i, int j, double v )
		{	if (value_tensor.length() > 0)
			{	size_t cur_j = 1 + (j-1) % value_tensor.dim2();
				size_t cur_k = 1 + (j-1) / value_tensor.dim2();
				value_tensor(i,cur_j,cur_k) = v;
			}
		};
		
	virtual	int		read( Boolean* isNum = NULL );
};




class	iStdStream : public iStreamReader
{
		//	Construction
		
private:
	char*		cur_comment_pos;
	char		comment_cr;
	Boolean		hasTitles;
	
	void	initNULL();
	void	resetInfo();

public:	
	lineInfoList	TheLineInfo;
	readModule*		current_read_module;
private:
	columnRec		TheColumnRecord;
public:	
	readModule0D	read_0D;
	readModule1D	read_1D;
	readModule2D	read_2D;
	readModule3D	read_3D;
	
	
	Boolean		perfect;			//	correspond a la structure simple: comment + titles + valeurs (+ lignes vides), avec rigoureusement les memes colonnes dans le bloc 'valeurs'
	
	void	TableInfo();
	void	AddIntoComment();
	void	ReadTitles( int nb );
	
	void	EndComment()	{	*(cur_comment_pos++) = '\0';	};
	
	void	setName( char* s )
		{	std::strncpy( name, s, FILE_NAME_LENGTH );	name[FILE_NAME_LENGTH-1] = '\0';	};
		
public:	
	char 		name[FILE_NAME_LENGTH];		//	Filename
	char		comment[COMMENT_LENGTH];
	
	iStdStream( std::istream& istr, char* s, CVocabularyList* vl = NULL, int vl_length = 0 );
	~iStdStream()	{};


		//	Validation

public:	
	Boolean		isPerfect()		{	return	perfect;	};
	void		setValidLine()
					{	if (read_3D.stillValid())		current_read_module = &read_3D;
						else if (read_2D.stillValid())	current_read_module = &read_2D;
						else if (read_1D.stillValid())	current_read_module = &read_1D;
						else if (read_0D.stillValid())	current_read_module = &read_0D;
						else current_read_module = NULL;
					};
					
		//	Accessing after validation
	
public:
	int		nonEmptyNumericColumnNumber();
	int		numericLineNumber()
				{	return ( current_read_module ? current_read_module->numericLineNumber() : 0 );	};
	int		columnNumber()
				{	return ( current_read_module ? current_read_module->columnNumber() : 0 );		};
	int		numericColumnNumber()
				{	return ( current_read_module ? current_read_module->numericColumnNumber() : 0 );};
		
	colonInfo&	Column( int i )					{	return	TheColumnRecord.Column(i);		};
	colonInfo*	getColumn( int i )				{	return	TheColumnRecord.getColumn(i);	};
	
	colonInfo*	getNumericColumn( int i );
	colonInfo*	getNonEmptyNumericColumn( int i );
	int			getNumericColumnIndex( int i );
	int			getNonEmptyNumericColumnIndex( int i );
	
	Boolean	isNumCol( int i );
	Boolean	isNonEmptyNumCol( int i );
	
		
	int		read( Boolean* isNum = NULL )
		{	return ( current_read_module ? current_read_module->read(isNum) : 0 );	};
	
	Boolean	SetDim( int n )
		{	readModule*	tmp = current_read_module;
			switch (n)	{
				case 0:	current_read_module = &read_0D;	break;
				case 1:	current_read_module = &read_1D;	break;
				case 2:	current_read_module = &read_2D;	break;
				case 3:	current_read_module = &read_3D;	break;
			}
			if (!current_read_module)	{	current_read_module = tmp;	return false;	}
			else	return true;
			
		};
};




class	oStdStream
{
protected:
	std::ostream&	to;
	char		cr;
	int			nbCommentLines;
	const char*	comment;
	
	void	writeComment();
	
public:
	oStdStream( std::ostream& ostr, const char* com = nil, int nbcom = 1, char c = '\n' ):to(ostr)
		{	comment = com;	nbCommentLines = nbcom;	cr = c;		};
		
	void	SetCR( char c )							{	cr				= c;		};
	void	SetComment( const char* com )			{	comment			= com;		};
	void	SetCommentLineNb( int n )				{	nbCommentLines	= n;		};
	
	virtual void	write()		{	writeComment();	to.flush();	};
};



class	oStdColStream : public oStdStream
{

private:
	Boolean		hasNumData;
	Boolean		hasStrData;
	Boolean		useDecimalComma;						//	use comma instead of point
	size_t		nbcol, nbnumcol, nbstrcol, maxVal;
	size_t		nbtableline, nrec;
	
	ptr_vector		v_val;		//	[nbnumcol]		Attention, chaque colonne a ses propres dimensions
	ptr_vector		s_val;		//	[nbstrcol]		Attention, chaque colonne a ses propres dimensions
	
protected:
	string_vector	vTitles;
    
private:
	bool_vector		is_numval;
	int_vector		colmax;
	
	double_vector&	v_value( int i )	{	return *((double_vector*)(v_val[i]));	};
	string_vector&	s_value( int i )	{	return *((string_vector*)(s_val[i]));	};

	
protected:

//		accessing info
	virtual const char*	Title( size_t i )	{	return	( vTitles.length() >= i ? vTitles(i).c_str() : "" );	};
	
		//		column informations
	int		Minimum( size_t )				{	return	1;	};
	int		Maximum( size_t i )			{	return	( colmax.length() >= i ? colmax(i) : maxVal );		};
	Boolean	IsNumber( size_t i )			{	return	( is_numval.length() >= i ? is_numval(i) : true );	};
	
		//		cell informations
	virtual double	Value( size_t i, size_t j  )		{	return	( v_val.length() >= i ? v_value(i)(j) : 0 );			};
	virtual const char*	SValue( size_t i, size_t j  )	{	return	( s_val.length() >= i ?	s_value(i)(j).c_str() : "");	};	

protected:
	void	InitNULL();
	void		SetLineNumber();

//		writing
	virtual void writeTitle()
		{	for (size_t i=1; i<=vTitles.length(); i++)
			{	to << Title(i);
				if (i<vTitles.length())	to << '\t';		else	to << cr;
			};
		};

	virtual void writeColumns();
	virtual void WriteDouble( double v );
	
	virtual void WriteValue( int i, int j )		{	WriteDouble( Value( i, j ) );	};
	virtual void WriteStrValue( int i, int j )	{	to << SValue( i, j );			};
		
//		generic setting
	
	void	SetNbNumCol( int nb )								{	nbnumcol = nb;	nbcol = nbnumcol+nbstrcol;	hasNumData = (nbnumcol > 0);	};
	void	SetNbStrCol( int nb )								{	nbstrcol = nb;	nbcol = nbnumcol+nbstrcol;	hasStrData = (nbstrcol > 0);	};
	void	SetMax( int maxi )									{	maxVal = maxi;	SetLineNumber();					};
	
/*
private:
	int			*min, *max;		//	values[k][i] sera ecrit sur la ligne:	 min[j(k)] + (i - 1), avec i entre 1 et max-min+1
	char		(*titles)[COLUMN_NAME_LENGTH];
	Boolean*	isNum;
	double**	values;			//	[nbnumcol][ max[i]-min[i]+1 ]			Attention, chaque colonne a ses propres dimensions: de min[i] a max[i] !!!
	char***		svalues;		//	[nbcol-nbnumcol][ max[i]-min[i]+1 ]		Attention, chaque colonne a ses propres dimensions: de min[i] a max[i] !!!


	int			(*minFunc)			(int);			//	idem, in functional form
	int			(*maxFunc)			(int);
	char*		(*titleFunc)		(int);
	Boolean		(*isNumFunc)		(int);
	Boolean		(*isNotEmptyFunc)	(int,int);
	double		(*valueFunc)		(int,int);
	char* 		(*svalueFunc)		(int,int);

protected:
//		accessing info

//		column informations
	int			Minimum( int i )	{	return	( min	 ?	min[i]		:	( minFunc	?	minFunc(i)	:	1		)	);	};
	
	int			Maximum( int i )
		{	return	( colmax.length() > 0	?	colmax(i)	:
					( max	 				?	max[i]		:
					( maxFunc				?	maxFunc(i)	:	maxVal	)	)	);
		};
	Boolean		IsNumber( int i )
		{	return	( is_numval.length() > 0	?	is_numval(i)	:
					( isNum						?	isNum[i]		:
					( isNumFunc					?	isNumFunc(i)	:	true	)	)	);
		};
	virtual const char*	Title( int i )
		{	return	( vTitles.length() > 0	?	vTitles(i).c_str()	:
					( titles				?	titles[i]	:
					( titleFunc				?	titleFunc(i):	""		)	)	);
		};
	
//		cell informations
	virtual double		Value( int i, int j  )
		{	return	( v_val.length() > 0	?	v_value(i)(j)	:
					( values				?	values[i][j]	:
					( valueFunc				?	valueFunc(i,j)	: 0 ) ) );
		};
	virtual const char*	SValue( int i, int j  )
		{	return	( s_val.length() > 0	?	s_value(i)(j).c_str()	:
					( svalues				?	svalues[i][j]	:
					( svalueFunc			?	svalueFunc(i,j)	: "" ) ) );
		};	
		


private:
	int			nbtitlcol;
	
protected:
	void		SetNbTitleCol( int nb )		{	nbtitlcol = nb;	};

	Boolean	IsNotEmpty( int i, int j  )
		{	return	( isNotEmptyFunc  ?	isNotEmptyFunc(i,j) :	true	);	};

//		functional setting
	void	SetMinMax( int (*minF)(int), int (*maxF)(int) )		{	minFunc = minF;	maxFunc = maxF;	SetLineNumber();	};
	void	SetNumCols( Boolean (*isNumF)(int) )				{	isNumFunc	= isNumF;	};
	void	SetTitle( char* (*titleF)(int) )					{	titleFunc	= titleF;	};
	void	SetValues( int nb, double (*valueF)(int,int) )		{	valueFunc = valueF;		SetNbNumCol( nb );	};
	void	SetStrValues( int nb, char* (*svalueF)(int,int) )	{	svalueFunc = svalueF;	SetNbStrCol( nb );	};
	void	SetNotEmptyFunc( Boolean (*notEmpty)(int,int) )		{	isNotEmptyFunc	= notEmpty;	};
	
//		vector [] setting
	void	SetMinMax( int* mini, int* maxi )					{	min = mini;		max = maxi;		SetLineNumber();	};
	void	SetNumCols( Boolean* num )							{	isNum		= num;		};
	void	SetTitle( char (*titl)[] )							{	titles		= titl;		};
	void	SetValues( int nb, double** v )						{	values = v;				SetNbNumCol( nb );	};
	void	SetStrValues( int nb, char*** sv )					{	svalues = sv;			SetNbStrCol( nb );	};

protected:	

	oStdColStream( ostream& ostr, int nbnumc, int* mini, int* maxi, double** v, char (*titl)[] = nil,
		Boolean* num = nil, int nbstrc = 0, char*** sv = nil ):oStdStream(ostr)
	{	InitNULL();
		SetNumCols( num );
		SetTitle( titl );
		SetValues( nbnumc, v );
		SetStrValues( nbstrc, sv );
		SetMinMax( mini, maxi );
	};

	oStdColStream( ostream& ostr, int nbnumc, int (*minF)(int), int (*maxF)(int), double (*valueF)(int,int), char* (*titleF)(int) = nil,
		Boolean (*isNumF)(int) = nil, int nbstrc = 0, char* (*svalueF)(int,int) = nil ):oStdStream(ostr)
	{	InitNULL();
		SetNumCols( isNumF );
		SetTitle( titleF );
		SetValues( nbnumc, valueF );
		SetStrValues( nbstrc, svalueF );
		SetMinMax( minF, maxF );
	};
	
	oStdColStream( ostream& ostr, int nbnumc, int nbline, double** v, char (*titl)[] = nil,
		Boolean* num = nil, int nbstrc = 0, char*** sv = nil ):oStdStream(ostr)
	{	InitNULL();
		SetNumCols( num );
		SetTitle( titl );
		SetValues( nbnumc, v );
		SetStrValues( nbstrc, sv );
		SetMax( nbline );
	};
*/


public:
	oStdColStream( std::ostream& ostr, double_vector* x, double_vector* y, char* x_name, char* y_name )
		: oStdStream(ostr), v_val(2), s_val(0), vTitles(2), is_numval(2), colmax(2)
		{	InitNULL();
			Append( x, x_name );	Append( y, y_name );
		};
	
	oStdColStream( std::ostream& ostr, int nbnumc, int nbstrc, int ntitles )
		: oStdStream(ostr), v_val(nbnumc), s_val(nbstrc),
			vTitles(ntitles), is_numval(nbnumc+nbstrc), colmax(nbnumc+nbstrc)
		{	InitNULL();	};
		
	void	Append( double_vector* x, char* x_name = NULL )
		{	SetNbNumCol(nbnumcol+1);	v_val(nbnumcol) = (Ptr)x;
			is_numval(nbcol) = true;	colmax(nbcol) = x->length();	SetLineNumber();
			if (x_name && vTitles.length() > 0)	vTitles(nbcol) = x_name;
		};
	void	Append( string_vector* x, char* x_name = NULL )
		{	SetNbStrCol(nbstrcol+1);	s_val(nbstrcol) = (Ptr)x;
			is_numval(nbcol) = false;	colmax(nbcol) = x->length();	SetLineNumber();
			if (x_name && vTitles.length() > 0)	vTitles(nbcol) = x_name;
		};
		
	virtual ~oStdColStream()	{};
	
	virtual void	write();
	
};


class	oStdValStream : public oStdColStream
{
public:
	oStdValStream( std::ostream& ostr, double_vector* v, string_vector* sv )
		: oStdColStream(ostr,1,1,0)
	{	Append( sv );
		Append( v );
	};
};



class	oStdMatrixStream : public oStdColStream
{
private:
	double_matrix*	m_val;
protected:
	double_vector*	x_val;
	double_vector*	y_val;
	unsigned long	nx, ny;
		
protected:
	virtual void WriteValue( int i, int j )			//	i = fastest = columns; j = slowest = line
		{	if (i>1 && j>1)			WriteDouble( (*m_val)( i-1, j-1 ) );		//	x=i; y=j
			else if (j==1 && i>1)	WriteDouble( (*x_val)( i-1 ) );
			else if (j>1 && i==1)	WriteDouble( (*y_val)( j-1 ) );
		};
	oStdMatrixStream( std::ostream& ostr, int ntitles  )	: oStdColStream( ostr,0,0,ntitles )	{};
	

public:
	oStdMatrixStream( std::ostream& ostr, double_vector* x, double_vector* y, double_matrix* v, char* x_name, char* y_name, char* v_name )
	: oStdColStream( ostr,0,0,3 )
	{	vTitles(1) = v_name;
		vTitles(2) = x_name;
		vTitles(3) = y_name;
		SetMatrix( x, y, v );
	};
	void	SetMatrix( double_vector* x, double_vector* y, double_matrix* v )
	{	m_val = v;
		x_val = x;
		y_val = y;
		nx = MyMath::MinOf( (x_val->length()), (m_val->dim1()) );
		ny = MyMath::MinOf( (y_val->length()), (m_val->dim2()) );
		SetNbNumCol( nx+1 );
		SetMax( ny+1 );
	};
};



class	oStdTensorStream : public oStdMatrixStream
{
private:
	double_3tensor*	t_val;
protected:
	double_vector*	z_val;
	unsigned long	nz, cur_k;
	
protected:
	virtual void WriteValue( int i, int j )					//	i = fastest = columns; j = slowest = line
		{	if (i>1 && j>1)			WriteDouble( (*t_val)( i-1, j-1, cur_k ) );	//	x=i; y=j; z=k
			else if (j==1 && i>1)	WriteDouble( (*x_val)( i-1 ) );
			else if (j>1 && i==1)	WriteDouble( (*y_val)( j-1 ) );
		};	

public:
	oStdTensorStream( std::ostream& ostr, double_vector* x, double_vector* y, double_vector* z, double_3tensor* v, char* x_name, char* y_name, char* z_name, char* v_name )
	: oStdMatrixStream( ostr, 4 )
	{	vTitles(1) = v_name;
		vTitles(2) = x_name;
		vTitles(3) = y_name;
		vTitles(4) = z_name;
		SetTensor( x, y, z, v );
	};
	void	SetTensor( double_vector* x, double_vector* y, double_vector* z, double_3tensor* v )
	{	t_val = v;
		x_val = x;
		y_val = y;
		z_val = z;
		nx = MyMath::MinOf( (x_val->length()), (t_val->dim1()) );
		ny = MyMath::MinOf( (y_val->length()), (t_val->dim2()) );
		nz = MyMath::MinOf( (z_val->length()), (t_val->dim3()) );
		SetNbNumCol( nx+1 );
		SetMax( ny+1 );
	};
		
protected:
	virtual void writeColumns()
	{	for (cur_k = 1; cur_k <= nz; cur_k++)
		{	WriteDouble( (*z_val)( cur_k ) );
			to << cr;
			oStdMatrixStream::writeColumns();
		};
	};
};





class	InputError : public GenericError {
public:
	InputError( int i ):GenericError("Input error line ")	{	std::ostringstream s;	s << i;		txt += s.str();		};
};

class	OverflowError : public InputError {
public:
	OverflowError( int i ):InputError(i)					{	std::ostringstream s;	s << ": Overflow";	txt += s.str();	};
};

class	BadNumberError : public InputError {
public:
	BadNumberError( int i, const char* s ):InputError(i)	{	std::ostringstream t;	t << ": Bad number (" << s << ")";	txt += t.str();	};
	BadNumberError( int i, const std::string s ):InputError(i)	{	std::ostringstream t;	t << ": Bad number (" << s << ")";	txt += t.str();	};
};
